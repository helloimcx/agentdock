"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeMessageContent = normalizeMessageContent;
exports.toThreadMessages = toThreadMessages;
exports.toThreadSummary = toThreadSummary;
exports.toThreadDetail = toThreadDetail;
const workspace_thread_id_js_1 = require("./workspace-thread-id.js");
function normalizeMessageContent(content) {
    return String(content || '').replace(/\n/g, ' ').trim();
}
function toThreadMessages(history) {
    return history.map((message, index) => ({
        id: `${message.timestamp || index}-${message.role}-${index}`,
        role: message.role === 'user' ? 'user' : message.role === 'assistant' ? 'assistant' : 'system',
        content: message.content,
        timestamp: message.timestamp,
        kind: message.kind === 'progress' ? 'progress' : message.role === 'system' ? 'system' : 'final',
    }));
}
function toThreadSummary(workspaceId, session) {
    const id = (0, workspace_thread_id_js_1.encodeThreadId)(workspaceId, session.id);
    return {
        id,
        workspaceId,
        title: String(session.name || session.user_name || session.chat_name || session.id).trim(),
        live: Boolean(session.live || session.active),
        updatedAt: session.updated_at,
        createdAt: session.created_at,
        historyCount: session.history_count,
        excerpt: normalizeMessageContent(session.last_message?.content),
        participantName: session.user_name || session.chat_name,
        runId: session.live ? `run:${id}` : undefined,
        bridgeSessionKey: session.session_key,
        agentType: session.agent_type,
    };
}
function toThreadDetail(workspaceId, session, selectedKnowledgeBaseIds = []) {
    return {
        ...toThreadSummary(workspaceId, session),
        messages: toThreadMessages(session.history || []),
        selectedKnowledgeBaseIds,
    };
}
