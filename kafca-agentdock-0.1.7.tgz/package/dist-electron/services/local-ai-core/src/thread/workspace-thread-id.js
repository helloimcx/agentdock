"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.encodeThreadId = encodeThreadId;
exports.decodeThreadId = decodeThreadId;
function encodeThreadId(workspaceId, sessionId) {
    return `${encodeURIComponent(workspaceId)}::${encodeURIComponent(sessionId)}`;
}
function decodeThreadId(threadId) {
    const [workspacePart, sessionPart] = threadId.split('::');
    if (!workspacePart || !sessionPart) {
        throw new Error(`Invalid thread id: ${threadId}`);
    }
    return {
        workspaceId: decodeURIComponent(workspacePart),
        sessionId: decodeURIComponent(sessionPart),
    };
}
