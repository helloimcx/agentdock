"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_process_1 = __importDefault(require("node:process"));
const node_fs_1 = require("node:fs");
const node_path_1 = require("node:path");
const local_core_controller_js_1 = require("./local-core-controller.js");
const server_js_1 = require("./server.js");
async function main() {
    const userDataPath = node_process_1.default.env.AI_WORKSTATION_USER_DATA_DIR?.trim() || (0, node_path_1.join)(node_process_1.default.cwd(), '.agentdock-core');
    (0, node_fs_1.mkdirSync)(userDataPath, { recursive: true });
    const controller = new local_core_controller_js_1.LocalCoreController(userDataPath);
    controller.on('logs', (line) => {
        if (!line) {
            return;
        }
        node_process_1.default.stdout.write(`[local-ai-core] ${line}\n`);
    });
    controller.on('bridge', (event) => {
        node_process_1.default.stdout.write(`[local-ai-core bridge] ${JSON.stringify(event)}\n`);
    });
    await controller.init();
    const server = new server_js_1.LocalAiCoreServer(controller);
    await server.start();
    node_process_1.default.on('SIGINT', async () => {
        await server.stop();
        await controller.close();
        node_process_1.default.exit(0);
    });
    node_process_1.default.on('SIGTERM', async () => {
        await server.stop();
        await controller.close();
        node_process_1.default.exit(0);
    });
}
void main();
