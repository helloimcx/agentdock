"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalAiCoreServer = void 0;
const node_http_1 = require("node:http");
function json(res, statusCode, data, ok = true, error) {
    res.statusCode = statusCode;
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.end(JSON.stringify(ok ? { ok: true, data } : { ok: false, error }));
}
async function readJsonBody(req) {
    const body = await readRawBody(req);
    if (!body.length) {
        return {};
    }
    return JSON.parse(Buffer.from(body).toString('utf8'));
}
async function readRawBody(req) {
    const chunks = [];
    for await (const chunk of req) {
        chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
    }
    return Buffer.concat(chunks);
}
function setCorsHeaders(req, res) {
    const origin = String(req.headers.origin || '');
    if (origin === 'null' || origin.startsWith('http://127.0.0.1:') || origin.startsWith('http://localhost:')) {
        res.setHeader('Access-Control-Allow-Origin', origin);
        res.setHeader('Vary', 'Origin');
    }
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}
function createSseEvent(name, payload) {
    return `event: ${name}\ndata: ${JSON.stringify(payload)}\n\n`;
}
class LocalAiCoreServer {
    bindings;
    host;
    port;
    sseClients = new Set();
    heartbeatTimers = new Map();
    server = (0, node_http_1.createServer)((req, res) => {
        void this.handleRequest(req, res);
    });
    constructor(bindings, options = {}) {
        this.bindings = bindings;
        this.host = options.host || '127.0.0.1';
        this.port = options.port || 9831;
        this.bindings.on('runtime', (runtime) => {
            this.broadcast({ type: 'runtime.updated', runtime });
        });
        this.bindings.on('bridge', (bridge) => {
            this.broadcast({ type: 'stream.updated', stream: bridge });
            if (bridge.sessionKey) {
                const threadId = this.findThreadIdFromSessionKey(bridge.sessionKey);
                this.broadcast({
                    type: 'presence.updated',
                    threadId,
                    live: bridge.type !== 'typing_stop',
                    stream: bridge,
                });
            }
        });
        this.bindings.on('scheduler-job', (job) => {
            this.broadcast({ type: 'scheduler.job.updated', job });
        });
        this.bindings.on('scheduler-run', (run) => {
            this.broadcast({ type: 'scheduler.run.updated', run });
        });
    }
    async start() {
        await new Promise((resolve, reject) => {
            this.server.once('error', reject);
            this.server.listen(this.port, this.host, () => {
                this.server.removeListener('error', reject);
                resolve();
            });
        });
    }
    async stop() {
        for (const client of this.sseClients) {
            client.end();
        }
        this.sseClients.clear();
        for (const timer of this.heartbeatTimers.values()) {
            clearInterval(timer);
        }
        this.heartbeatTimers.clear();
        await new Promise((resolve, reject) => {
            this.server.close((error) => {
                if (error) {
                    reject(error);
                    return;
                }
                resolve();
            });
        });
    }
    async handleRequest(req, res) {
        setCorsHeaders(req, res);
        if (req.method === 'OPTIONS') {
            res.statusCode = 204;
            res.end();
            return;
        }
        const url = new URL(req.url || '/', `http://${this.host}:${this.port}`);
        const path = url.pathname;
        try {
            if (req.method === 'GET' && path === '/api/local/v1/health') {
                json(res, 200, { name: 'local-ai-core', version: '0.1.0' });
                return;
            }
            if (req.method === 'GET' && path === '/api/local/v1/runtime') {
                json(res, 200, await this.bindings.getRuntimeStatus());
                return;
            }
            if (req.method === 'POST' && path === '/api/local/v1/runtime/service/start') {
                json(res, 200, await this.bindings.startService());
                return;
            }
            if (req.method === 'POST' && path === '/api/local/v1/runtime/service/stop') {
                json(res, 200, await this.bindings.stopService());
                return;
            }
            if (req.method === 'POST' && path === '/api/local/v1/runtime/service/restart') {
                json(res, 200, await this.bindings.restartService());
                return;
            }
            if (req.method === 'GET' && path === '/api/local/v1/runtime/logs') {
                const limit = Number(url.searchParams.get('limit') || '200');
                json(res, 200, this.bindings.getLogs(limit));
                return;
            }
            if (req.method === 'GET' && path === '/api/local/v1/runtime/config') {
                json(res, 200, await this.bindings.readConfigFile());
                return;
            }
            if (req.method === 'POST' && path === '/api/local/v1/runtime/config/raw') {
                const body = await readJsonBody(req);
                json(res, 200, await this.bindings.saveRawConfigFile(String(body.raw || '')));
                return;
            }
            if (req.method === 'POST' && path === '/api/local/v1/runtime/config/structured') {
                const body = await readJsonBody(req);
                json(res, 200, await this.bindings.saveStructuredConfigFile((body.config || {})));
                return;
            }
            if (req.method === 'POST' && path === '/api/local/v1/runtime/settings') {
                const body = await readJsonBody(req);
                json(res, 200, await this.bindings.saveSettings(body));
                return;
            }
            if (req.method === 'GET' && path.startsWith('/api/local/v1/platforms/')) {
                const suffix = path.slice('/api/local/v1/platforms/'.length);
                const segments = suffix.split('/').filter(Boolean).map((segment) => decodeURIComponent(segment));
                const [platform = '', workspaceOrCollection = '', action = ''] = segments;
                if (!platform) {
                    json(res, 404, null, false, 'Platform not found');
                    return;
                }
                if (segments.length === 1) {
                    json(res, 200, { gateways: await this.bindings.listChannelGatewayStatuses(platform) });
                    return;
                }
                if (workspaceOrCollection === 'pairings' && segments.length === 2) {
                    const workspaceId = String(url.searchParams.get('workspace_id') || '');
                    json(res, 200, { pairings: await this.bindings.listChannelPendingPairings(platform, workspaceId || undefined) });
                    return;
                }
                if (workspaceOrCollection === 'users' && segments.length === 2) {
                    const workspaceId = String(url.searchParams.get('workspace_id') || '');
                    json(res, 200, { users: await this.bindings.listChannelAuthorizedUsers(platform, workspaceId || undefined) });
                    return;
                }
                if (segments.length === 2) {
                    json(res, 200, await this.bindings.getChannelGatewayStatus(platform, workspaceOrCollection));
                    return;
                }
                if (platform === 'weixin' && segments.length === 4 && action === 'qrcode' && segments[3] === 'status') {
                    const ticket = String(url.searchParams.get('ticket') || '');
                    if (!ticket) {
                        json(res, 400, null, false, 'Missing ticket parameter');
                        return;
                    }
                    json(res, 200, await this.bindings.checkWeixinQrCodeStatus(workspaceOrCollection, ticket));
                    return;
                }
            }
            if (req.method === 'POST' && path.startsWith('/api/local/v1/platforms/')) {
                const suffix = path.slice('/api/local/v1/platforms/'.length);
                const segments = suffix.split('/').filter(Boolean).map((segment) => decodeURIComponent(segment));
                const [platform = '', workspaceOrCollection = '', action = ''] = segments;
                if (!platform) {
                    json(res, 404, null, false, 'Platform not found');
                    return;
                }
                if (workspaceOrCollection === 'pairings' && action === 'approve') {
                    const body = await readJsonBody(req);
                    json(res, 200, await this.bindings.approveChannelPairing(platform, String(body.code || '')));
                    return;
                }
                if (workspaceOrCollection === 'pairings' && action === 'reject') {
                    const body = await readJsonBody(req);
                    json(res, 200, await this.bindings.rejectChannelPairing(platform, String(body.code || '')));
                    return;
                }
                if (action === 'test') {
                    json(res, 200, await this.bindings.testChannelConnection(platform, workspaceOrCollection));
                    return;
                }
                if (action === 'enable') {
                    json(res, 200, await this.bindings.enableChannelGateway(platform, workspaceOrCollection));
                    return;
                }
                if (action === 'disable') {
                    json(res, 200, await this.bindings.disableChannelGateway(platform, workspaceOrCollection));
                    return;
                }
                if (platform === 'weixin' && segments.length === 3 && workspaceOrCollection !== 'pairings' && action === 'qrcode') {
                    json(res, 200, await this.bindings.getWeixinQrCode(workspaceOrCollection));
                    return;
                }
            }
            if (req.method === 'GET' && path === '/api/local/v1/scheduler/jobs') {
                const workspaceId = String(url.searchParams.get('workspace_id') || '');
                json(res, 200, { jobs: await this.bindings.listScheduledJobs(workspaceId || undefined) });
                return;
            }
            if (req.method === 'POST' && path === '/api/local/v1/scheduler/jobs') {
                const body = await readJsonBody(req);
                json(res, 200, await this.bindings.createScheduledJob(body));
                return;
            }
            if (req.method === 'GET'
                && path.startsWith('/api/local/v1/scheduler/jobs/')
                && !path.endsWith('/runs')
                && !path.endsWith('/run')) {
                const jobId = decodeURIComponent(path.slice('/api/local/v1/scheduler/jobs/'.length));
                json(res, 200, await this.bindings.getScheduledJob(jobId));
                return;
            }
            if (req.method === 'GET' && path.startsWith('/api/local/v1/scheduler/jobs/') && path.endsWith('/runs')) {
                const jobId = decodeURIComponent(path.slice('/api/local/v1/scheduler/jobs/'.length, -'/runs'.length));
                json(res, 200, { runs: await this.bindings.listScheduledJobRuns(jobId) });
                return;
            }
            if (req.method === 'POST' && path.startsWith('/api/local/v1/scheduler/jobs/') && path.endsWith('/run')) {
                const jobId = decodeURIComponent(path.slice('/api/local/v1/scheduler/jobs/'.length, -'/run'.length));
                json(res, 200, await this.bindings.runScheduledJob(jobId));
                return;
            }
            if (req.method === 'PATCH' && path.startsWith('/api/local/v1/scheduler/jobs/')) {
                const jobId = decodeURIComponent(path.slice('/api/local/v1/scheduler/jobs/'.length));
                const body = await readJsonBody(req);
                json(res, 200, await this.bindings.updateScheduledJob(jobId, body));
                return;
            }
            if (req.method === 'DELETE' && path.startsWith('/api/local/v1/scheduler/jobs/')) {
                const jobId = decodeURIComponent(path.slice('/api/local/v1/scheduler/jobs/'.length));
                json(res, 200, await this.bindings.deleteScheduledJob(jobId));
                return;
            }
            if (req.method === 'GET' && path === '/api/local/v1/workspaces') {
                json(res, 200, { workspaces: await this.bindings.listWorkspaces() });
                return;
            }
            if (req.method === 'GET' && path === '/api/local/v1/threads') {
                const workspaceId = String(url.searchParams.get('workspace_id') || '');
                json(res, 200, { threads: workspaceId ? await this.bindings.listThreads(workspaceId) : [] });
                return;
            }
            if (req.method === 'POST' && path === '/api/local/v1/threads') {
                const body = await readJsonBody(req);
                json(res, 200, await this.bindings.createThread(String(body.workspaceId || ''), String(body.title || '') || undefined));
                return;
            }
            if (req.method === 'GET' && path.startsWith('/api/local/v1/threads/')) {
                const threadId = decodeURIComponent(path.slice('/api/local/v1/threads/'.length));
                json(res, 200, await this.bindings.getThread(threadId));
                return;
            }
            if (req.method === 'PATCH' && path.startsWith('/api/local/v1/threads/') && path.endsWith('/knowledge-bases')) {
                const threadId = decodeURIComponent(path.slice('/api/local/v1/threads/'.length, -'/knowledge-bases'.length));
                const body = await readJsonBody(req);
                const knowledgeBaseIds = Array.isArray(body.knowledgeBaseIds)
                    ? body.knowledgeBaseIds.map((value) => String(value || ''))
                    : [];
                json(res, 200, await this.bindings.updateThreadKnowledgeBases(threadId, knowledgeBaseIds));
                return;
            }
            if (req.method === 'PATCH' && path.startsWith('/api/local/v1/threads/')) {
                const threadId = decodeURIComponent(path.slice('/api/local/v1/threads/'.length));
                const body = await readJsonBody(req);
                json(res, 200, await this.bindings.renameThread(threadId, String(body.title || '')));
                return;
            }
            if (req.method === 'DELETE' && path.startsWith('/api/local/v1/threads/')) {
                const threadId = decodeURIComponent(path.slice('/api/local/v1/threads/'.length));
                json(res, 200, await this.bindings.deleteThread(threadId));
                return;
            }
            if (req.method === 'POST' && path.startsWith('/api/local/v1/threads/') && path.endsWith('/messages')) {
                const threadId = decodeURIComponent(path.slice('/api/local/v1/threads/'.length, -'/messages'.length));
                const body = await readJsonBody(req);
                json(res, 200, await this.bindings.sendThreadMessage(threadId, String(body.content || '')));
                return;
            }
            if (req.method === 'POST' && path.startsWith('/api/local/v1/threads/') && path.endsWith('/actions')) {
                const threadId = decodeURIComponent(path.slice('/api/local/v1/threads/'.length, -'/actions'.length));
                const body = await readJsonBody(req);
                json(res, 200, await this.bindings.sendThreadAction(threadId, String(body.content || '')));
                return;
            }
            if (req.method === 'POST' && path.startsWith('/api/local/v1/runs/') && path.endsWith('/interrupt')) {
                const runId = decodeURIComponent(path.slice('/api/local/v1/runs/'.length, -'/interrupt'.length));
                json(res, 200, await this.bindings.interruptRun(runId));
                return;
            }
            if (req.method === 'GET' && path === '/api/local/v1/knowledge/sources') {
                json(res, 200, { sources: await this.bindings.listKnowledgeSources() });
                return;
            }
            if (req.method === 'GET' && path === '/api/local/v1/knowledge/config') {
                json(res, 200, await this.bindings.getKnowledgeConfig());
                return;
            }
            if (req.method === 'POST' && path === '/api/local/v1/knowledge/config') {
                const body = await readJsonBody(req);
                json(res, 200, await this.bindings.updateKnowledgeConfig(body));
                return;
            }
            if (req.method === 'GET' && path === '/api/local/v1/knowledge/folders') {
                json(res, 200, { folders: await this.bindings.listKnowledgeFolders() });
                return;
            }
            if (req.method === 'POST' && path === '/api/local/v1/knowledge/folders') {
                const body = await readJsonBody(req);
                json(res, 200, await this.bindings.createKnowledgeFolder(body));
                return;
            }
            if (req.method === 'PATCH' && path.startsWith('/api/local/v1/knowledge/folders/')) {
                const folderId = decodeURIComponent(path.slice('/api/local/v1/knowledge/folders/'.length));
                const body = await readJsonBody(req);
                json(res, 200, await this.bindings.updateKnowledgeFolder(folderId, body));
                return;
            }
            if (req.method === 'DELETE' && path.startsWith('/api/local/v1/knowledge/folders/')) {
                const folderId = decodeURIComponent(path.slice('/api/local/v1/knowledge/folders/'.length));
                json(res, 200, await this.bindings.deleteKnowledgeFolder(folderId));
                return;
            }
            if (req.method === 'GET' && path === '/api/local/v1/knowledge/bases') {
                json(res, 200, { bases: await this.bindings.listKnowledgeBases() });
                return;
            }
            if (req.method === 'POST' && path === '/api/local/v1/knowledge/bases') {
                const body = await readJsonBody(req);
                json(res, 200, await this.bindings.createKnowledgeBase(body));
                return;
            }
            if (req.method === 'GET' && path.startsWith('/api/local/v1/knowledge/bases/') && !path.endsWith('/files') && !path.endsWith('/search')) {
                const knowledgeBaseId = decodeURIComponent(path.slice('/api/local/v1/knowledge/bases/'.length));
                json(res, 200, await this.bindings.getKnowledgeBase(knowledgeBaseId));
                return;
            }
            if (req.method === 'PATCH' && path.startsWith('/api/local/v1/knowledge/bases/')) {
                const knowledgeBaseId = decodeURIComponent(path.slice('/api/local/v1/knowledge/bases/'.length));
                const body = await readJsonBody(req);
                json(res, 200, await this.bindings.updateKnowledgeBase(knowledgeBaseId, body));
                return;
            }
            if (req.method === 'DELETE' && path.startsWith('/api/local/v1/knowledge/bases/') && !path.includes('/files/')) {
                const knowledgeBaseId = decodeURIComponent(path.slice('/api/local/v1/knowledge/bases/'.length));
                json(res, 200, await this.bindings.deleteKnowledgeBase(knowledgeBaseId));
                return;
            }
            if (req.method === 'GET' && path.startsWith('/api/local/v1/knowledge/bases/') && path.endsWith('/files')) {
                const knowledgeBaseId = decodeURIComponent(path.slice('/api/local/v1/knowledge/bases/'.length, -'/files'.length));
                json(res, 200, { files: await this.bindings.listKnowledgeBaseFiles(knowledgeBaseId) });
                return;
            }
            if (req.method === 'POST' && path.startsWith('/api/local/v1/knowledge/bases/') && path.endsWith('/files')) {
                const knowledgeBaseId = decodeURIComponent(path.slice('/api/local/v1/knowledge/bases/'.length, -'/files'.length));
                const contentType = String(req.headers['content-type'] || '').trim();
                if (!contentType) {
                    throw new Error('Upload content type is required.');
                }
                const body = await readRawBody(req);
                json(res, 200, { results: await this.bindings.uploadKnowledgeBaseFiles(knowledgeBaseId, { contentType, body }) });
                return;
            }
            if (req.method === 'DELETE' && path.includes('/api/local/v1/knowledge/bases/') && path.includes('/files/')) {
                const prefix = '/api/local/v1/knowledge/bases/';
                const fileMarker = '/files/';
                const knowledgeBaseId = decodeURIComponent(path.slice(prefix.length, path.indexOf(fileMarker)));
                const fileId = decodeURIComponent(path.slice(path.indexOf(fileMarker) + fileMarker.length));
                json(res, 200, await this.bindings.deleteKnowledgeBaseFile(knowledgeBaseId, fileId));
                return;
            }
            if (req.method === 'POST' && path.startsWith('/api/local/v1/knowledge/bases/') && path.endsWith('/search')) {
                const knowledgeBaseId = decodeURIComponent(path.slice('/api/local/v1/knowledge/bases/'.length, -'/search'.length));
                const body = await readJsonBody(req);
                json(res, 200, { results: await this.bindings.searchKnowledgeBase(knowledgeBaseId, body) });
                return;
            }
            if (req.method === 'GET' && path === '/api/local/v1/capabilities') {
                json(res, 200, await this.bindings.getCapabilities());
                return;
            }
            if (req.method === 'GET' && path === '/api/local/v1/capabilities/snapshot') {
                json(res, 200, await this.bindings.getCapabilitySnapshot());
                return;
            }
            if (req.method === 'GET' && path === '/api/local/v1/plugins/diagnostics') {
                json(res, 200, await this.bindings.getPluginDiagnostics());
                return;
            }
            if (req.method === 'POST' && path.startsWith('/api/local/v1/workspaces/') && path.endsWith('/streaming-probe')) {
                const workspaceId = decodeURIComponent(path.slice('/api/local/v1/workspaces/'.length, -'/streaming-probe'.length));
                json(res, 200, await this.bindings.probeWorkspaceStreaming(workspaceId));
                return;
            }
            if (req.method === 'GET' && path === '/api/local/v1/events') {
                this.attachSseClient(res);
                return;
            }
            json(res, 404, null, false, `Unknown route: ${path}`);
        }
        catch (error) {
            json(res, 500, null, false, error instanceof Error ? error.message : String(error));
        }
    }
    attachSseClient(res) {
        res.writeHead(200, {
            'Content-Type': 'text/event-stream',
            'Cache-Control': 'no-cache, no-transform',
            Connection: 'keep-alive',
        });
        res.write(': connected\n\n');
        this.sseClients.add(res);
        const heartbeat = setInterval(() => {
            res.write(': heartbeat\n\n');
        }, 15000);
        this.heartbeatTimers.set(res, heartbeat);
        res.on('close', () => {
            clearInterval(heartbeat);
            this.heartbeatTimers.delete(res);
            this.sseClients.delete(res);
        });
    }
    broadcast(event) {
        const payload = createSseEvent(event.type, event);
        for (const client of this.sseClients) {
            client.write(payload);
        }
    }
    findThreadIdFromSessionKey(sessionKey) {
        const parts = sessionKey.split(':');
        if (parts.length < 3) {
            return undefined;
        }
        return `${encodeURIComponent(parts[1] || '')}::${encodeURIComponent(parts[2] || '')}`;
    }
}
exports.LocalAiCoreServer = LocalAiCoreServer;
