"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.createLocalCoreRuntimeState = createLocalCoreRuntimeState;
const node_fs_1 = require("node:fs");
const node_path_1 = require("node:path");
const TOML = __importStar(require("@iarna/toml"));
const DEFAULT_CONFIG = `# Managed by Local AI Core
[[projects]]
name = "default"

[projects.agent]
type = "opencode"
`;
const LOG_FILE_NAME = 'local-core.log';
const LOG_FILE_MAX_BYTES = 2 * 1024 * 1024;
class FileBackedLocalCoreRuntimeState {
    userDataPath;
    onLog;
    runtimeDir;
    settingsPath;
    cliBinDir;
    logPath;
    settings;
    logs = [];
    constructor(userDataPath, onLog) {
        this.userDataPath = userDataPath;
        this.onLog = onLog;
        this.runtimeDir = (0, node_path_1.join)(userDataPath, 'runtime');
        this.settingsPath = (0, node_path_1.join)(this.runtimeDir, 'local-core-settings.json');
        this.logPath = (0, node_path_1.join)(this.runtimeDir, LOG_FILE_NAME);
        (0, node_fs_1.mkdirSync)(this.runtimeDir, { recursive: true });
        this.cliBinDir = this.ensureCliWrapper();
        this.settings = this.loadSettings();
        this.ensureConfigFile();
    }
    getSettings() {
        return this.settings;
    }
    async saveSettings(input) {
        this.settings = {
            ...this.settings,
            ...(input.defaultProject ? { defaultProject: input.defaultProject } : {}),
            ...(typeof input.autoStartService === 'boolean' ? { autoStartService: input.autoStartService } : {}),
            ...(input.configPath ? { configPath: input.configPath } : {}),
            plugins: input.plugins
                ? Object.fromEntries(Object.entries({
                    ...this.settings.plugins,
                    ...Object.fromEntries(Object.entries(input.plugins).map(([pluginId, value]) => [
                        pluginId,
                        {
                            ...this.settings.plugins[pluginId],
                            ...value,
                            config: {
                                ...(this.settings.plugins[pluginId]?.config || {}),
                                ...(value.config || {}),
                            },
                        },
                    ])),
                }))
                : this.settings.plugins,
            knowledge: input.knowledge
                ? {
                    ...this.settings.knowledge,
                    ...input.knowledge,
                }
                : this.settings.knowledge,
        };
        this.persistSettings();
        return this.settings;
    }
    getKnowledgeConfig() {
        return this.settings.knowledge;
    }
    async updateKnowledgeConfig(input) {
        this.settings = {
            ...this.settings,
            knowledge: {
                ...this.settings.knowledge,
                ...input,
            },
        };
        this.persistSettings();
        return this.settings.knowledge;
    }
    getLogs(limit = 200) {
        return this.logs.slice(-Math.max(limit, 1));
    }
    pushLog(message) {
        if (!message) {
            return;
        }
        this.logs.push(message);
        this.appendLogFile(message);
        this.onLog?.(message);
        if (this.logs.length > 400) {
            this.logs.splice(0, this.logs.length - 400);
        }
    }
    appendLogFile(message) {
        try {
            if ((0, node_fs_1.existsSync)(this.logPath) && (0, node_fs_1.statSync)(this.logPath).size > LOG_FILE_MAX_BYTES) {
                const rotatedPath = `${this.logPath}.1`;
                try {
                    (0, node_fs_1.renameSync)(this.logPath, rotatedPath);
                }
                catch {
                    // Keep runtime logging best-effort; stdout/UI logs still work.
                }
            }
            const line = `${new Date().toISOString()} ${message.replace(/\r?\n/g, '\\n')}\n`;
            (0, node_fs_1.appendFileSync)(this.logPath, line, 'utf-8');
        }
        catch {
            // File logging must never break Local AI Core runtime behavior.
        }
    }
    async readConfigFile() {
        const path = this.settings.configPath;
        if (!(0, node_fs_1.existsSync)(path)) {
            return { path, exists: false, raw: '', parsed: null };
        }
        const raw = (0, node_fs_1.readFileSync)(path, 'utf8');
        try {
            const parsed = TOML.parse(raw);
            return { path, exists: true, raw, parsed };
        }
        catch (error) {
            return {
                path,
                exists: true,
                raw,
                parsed: null,
                error: error instanceof Error ? error.message : String(error),
            };
        }
    }
    async saveRawConfigFile(raw) {
        (0, node_fs_1.mkdirSync)((0, node_path_1.dirname)(this.settings.configPath), { recursive: true });
        (0, node_fs_1.writeFileSync)(this.settings.configPath, raw, 'utf8');
        return this.readConfigFile();
    }
    async saveStructuredConfigFile(config) {
        (0, node_fs_1.mkdirSync)((0, node_path_1.dirname)(this.settings.configPath), { recursive: true });
        (0, node_fs_1.writeFileSync)(this.settings.configPath, TOML.stringify(config), 'utf8');
        return this.readConfigFile();
    }
    loadSettings() {
        const defaults = {
            configPath: (0, node_path_1.join)(this.runtimeDir, 'config.toml'),
            defaultProject: 'default',
            autoStartService: true,
            plugins: {},
            knowledge: {
                baseUrl: '',
                authMode: 'none',
                token: '',
                headerName: 'X-API-Key',
                defaultCollection: 'personal_knowledge',
            },
        };
        if (!(0, node_fs_1.existsSync)(this.settingsPath)) {
            return {
                binaryPath: '',
                configPath: defaults.configPath,
                autoStartService: defaults.autoStartService,
                defaultProject: defaults.defaultProject,
                managementPort: 0,
                managementToken: '',
                bridgePort: 0,
                bridgeToken: '',
                bridgePath: '',
                knowledge: defaults.knowledge,
                plugins: defaults.plugins,
            };
        }
        const raw = JSON.parse((0, node_fs_1.readFileSync)(this.settingsPath, 'utf8'));
        return {
            binaryPath: '',
            configPath: String(raw.configPath || defaults.configPath),
            autoStartService: typeof raw.autoStartService === 'boolean' ? raw.autoStartService : defaults.autoStartService,
            defaultProject: String(raw.defaultProject || defaults.defaultProject),
            managementPort: 0,
            managementToken: '',
            bridgePort: 0,
            bridgeToken: '',
            bridgePath: '',
            plugins: normalizePluginSettings(raw.plugins),
            knowledge: {
                ...defaults.knowledge,
                ...(raw.knowledge || {}),
            },
        };
    }
    persistSettings() {
        const payload = {
            configPath: this.settings.configPath,
            defaultProject: this.settings.defaultProject,
            autoStartService: this.settings.autoStartService,
            plugins: this.settings.plugins,
            knowledge: this.settings.knowledge,
        };
        (0, node_fs_1.mkdirSync)((0, node_path_1.dirname)(this.settingsPath), { recursive: true });
        (0, node_fs_1.writeFileSync)(this.settingsPath, `${JSON.stringify(payload, null, 2)}\n`, 'utf8');
    }
    ensureConfigFile() {
        if ((0, node_fs_1.existsSync)(this.settings.configPath)) {
            return;
        }
        (0, node_fs_1.mkdirSync)((0, node_path_1.dirname)(this.settings.configPath), { recursive: true });
        (0, node_fs_1.writeFileSync)(this.settings.configPath, DEFAULT_CONFIG, 'utf8');
    }
    ensureCliWrapper() {
        const binDir = (0, node_path_1.join)(this.runtimeDir, 'bin');
        (0, node_fs_1.mkdirSync)(binDir, { recursive: true });
        const cliEntry = (0, node_path_1.join)(__dirname, '..', 'cli', 'lac.js');
        const wrapperPath = (0, node_path_1.join)(binDir, 'lac');
        const script = [
            '#!/bin/sh',
            'export ELECTRON_RUN_AS_NODE=1',
            `exec "${process.execPath.replace(/"/g, '\\"')}" "${cliEntry.replace(/"/g, '\\"')}" "$@"`,
            '',
        ].join('\n');
        (0, node_fs_1.writeFileSync)(wrapperPath, script, 'utf8');
        (0, node_fs_1.chmodSync)(wrapperPath, 0o755);
        return binDir;
    }
}
function normalizePluginSettings(input) {
    if (!input || typeof input !== 'object') {
        return {};
    }
    const output = {};
    for (const [pluginId, value] of Object.entries(input)) {
        if (!value || typeof value !== 'object') {
            continue;
        }
        const record = value;
        output[pluginId] = {
            enabled: typeof record.enabled === 'boolean' ? record.enabled : true,
            config: record.config && typeof record.config === 'object'
                ? record.config
                : {},
        };
    }
    return output;
}
function createLocalCoreRuntimeState(options) {
    return new FileBackedLocalCoreRuntimeState(options.userDataPath, options.onLog);
}
