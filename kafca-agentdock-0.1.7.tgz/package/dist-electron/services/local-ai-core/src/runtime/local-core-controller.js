"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalCoreController = void 0;
const node_events_1 = require("node:events");
const desktop_js_1 = require("../../../../shared/desktop.js");
const bootstrap_js_1 = require("../kernel/bootstrap.js");
class LocalCoreController extends node_events_1.EventEmitter {
    userDataPath;
    state;
    workspaceRouter;
    knowledgeProvider;
    channelRuntime;
    weixinChannelRuntime;
    scheduler;
    kernel;
    runtime;
    busUnsubscribers = [];
    constructor(userDataPath, runtime) {
        super();
        this.userDataPath = userDataPath;
        this.runtime = runtime || (0, bootstrap_js_1.bootstrapLocalCoreRuntime)({
            userDataPath,
            localCoreBase: 'http://127.0.0.1:9831/api/local/v1',
            log: (message) => this.handleLog(message),
        });
        this.state = this.runtime.state;
        this.kernel = this.runtime.kernel;
        this.knowledgeProvider = this.runtime.knowledgeProvider;
        this.workspaceRouter = this.runtime.workspaceRouter;
        this.channelRuntime = this.runtime.channelRuntime;
        this.weixinChannelRuntime = this.runtime.weixinChannelRuntime;
        this.scheduler = this.runtime.scheduler;
        this.busUnsubscribers.push(this.kernel.context.bus.on('platform.bridge.updated', (event) => {
            this.emit('bridge', event);
        }), this.kernel.context.bus.on('scheduler.job.updated', (job) => {
            this.emit('scheduler-job', job);
        }), this.kernel.context.bus.on('scheduler.run.updated', (run) => {
            this.emit('scheduler-run', run);
        }), this.kernel.context.bus.on('runtime.state.changed', () => {
            void this.emitRuntime();
        }));
    }
    async init() {
        await this.runtime.start();
        await this.emitRuntime();
    }
    async close() {
        for (const unsubscribe of this.busUnsubscribers) {
            unsubscribe();
        }
        await this.runtime.stop();
    }
    async getRuntimeStatus() {
        const service = {
            status: 'running',
            startedAt: new Date().toISOString(),
        };
        return {
            mode: 'desktop',
            phase: 'api_ready',
            pendingRestart: false,
            service,
            roles: (0, desktop_js_1.deriveDesktopRuntimeRoles)(service),
            settings: this.state.getSettings(),
            configFile: await this.readConfigFile(),
            logs: this.getLogs(200),
            pluginDiagnostics: await this.getPluginDiagnostics(),
        };
    }
    async startService() {
        return { status: 'running' };
    }
    async stopService() {
        return { status: 'running' };
    }
    async restartService() {
        await this.channelRuntime.refreshBindings?.();
        await this.weixinChannelRuntime.refreshBindings?.();
        await this.emitRuntime();
        return { status: 'running' };
    }
    getLogs(limit = 200) {
        return this.state.getLogs(limit);
    }
    async readConfigFile() {
        return this.state.readConfigFile();
    }
    async saveRawConfigFile(raw) {
        const next = await this.state.saveRawConfigFile(raw);
        await this.channelRuntime.refreshBindings?.();
        await this.weixinChannelRuntime.refreshBindings?.();
        await this.emitRuntime();
        return next;
    }
    async saveStructuredConfigFile(config) {
        const next = await this.state.saveStructuredConfigFile(config);
        await this.channelRuntime.refreshBindings?.();
        await this.weixinChannelRuntime.refreshBindings?.();
        await this.emitRuntime();
        return next;
    }
    async saveSettings(input) {
        const settings = await this.state.saveSettings(input);
        await this.channelRuntime.refreshBindings?.();
        await this.weixinChannelRuntime.refreshBindings?.();
        await this.emitRuntime();
        return settings;
    }
    async listWorkspaces() {
        return this.workspaceRouter.listWorkspaces();
    }
    async listScheduledJobs(workspaceId) {
        return this.scheduler.listJobs(workspaceId);
    }
    async getScheduledJob(jobId) {
        const job = this.scheduler.getJob(jobId);
        if (!job) {
            throw new Error(`Scheduled job not found: ${jobId}`);
        }
        return job;
    }
    async createScheduledJob(input) {
        return this.scheduler.createJob(input);
    }
    async updateScheduledJob(jobId, input) {
        return this.scheduler.updateJob(jobId, input);
    }
    async deleteScheduledJob(jobId) {
        return this.scheduler.deleteJob(jobId);
    }
    async runScheduledJob(jobId) {
        return this.scheduler.runJobNow(jobId);
    }
    async listScheduledJobRuns(jobId) {
        return this.scheduler.listJobRuns(jobId);
    }
    async listThreads(workspaceId) {
        return this.workspaceRouter.listThreads(workspaceId);
    }
    async createThread(workspaceId, title) {
        return this.workspaceRouter.createThread(workspaceId, title);
    }
    async getThread(threadId) {
        return this.workspaceRouter.getThread(threadId);
    }
    async renameThread(threadId, title) {
        return this.workspaceRouter.renameThread(threadId, title);
    }
    async updateThreadKnowledgeBases(threadId, knowledgeBaseIds) {
        return this.workspaceRouter.updateThreadKnowledgeBases(threadId, knowledgeBaseIds);
    }
    async deleteThread(threadId) {
        return this.workspaceRouter.deleteThread(threadId);
    }
    async sendThreadMessage(threadId, content) {
        return this.workspaceRouter.sendThreadMessage(threadId, content);
    }
    async sendThreadAction(threadId, content) {
        return this.workspaceRouter.sendThreadAction(threadId, content);
    }
    async interruptRun(runId) {
        return this.workspaceRouter.interruptRun(runId);
    }
    async listKnowledgeSources() {
        return this.knowledgeProvider.listSources();
    }
    async getKnowledgeConfig() {
        return this.knowledgeProvider.getConfig();
    }
    async updateKnowledgeConfig(input) {
        return this.knowledgeProvider.updateConfig(input);
    }
    async listKnowledgeFolders() {
        return this.knowledgeProvider.listFolders();
    }
    async createKnowledgeFolder(input) {
        return this.knowledgeProvider.createFolder(input);
    }
    async updateKnowledgeFolder(id, input) {
        return this.knowledgeProvider.updateFolder(id, input);
    }
    async deleteKnowledgeFolder(id) {
        return this.knowledgeProvider.deleteFolder(id);
    }
    async listKnowledgeBases() {
        return this.knowledgeProvider.listKnowledgeBases();
    }
    async getKnowledgeBase(id) {
        return this.knowledgeProvider.getKnowledgeBase(id);
    }
    async createKnowledgeBase(input) {
        return this.knowledgeProvider.createKnowledgeBase(input);
    }
    async updateKnowledgeBase(id, input) {
        return this.knowledgeProvider.updateKnowledgeBase(id, input);
    }
    async deleteKnowledgeBase(id) {
        return this.knowledgeProvider.deleteKnowledgeBase(id);
    }
    async listKnowledgeBaseFiles(knowledgeBaseId) {
        return this.knowledgeProvider.listKnowledgeBaseFiles(knowledgeBaseId);
    }
    async uploadKnowledgeBaseFiles(knowledgeBaseId, request) {
        return this.knowledgeProvider.uploadKnowledgeBaseFiles(knowledgeBaseId, request);
    }
    async deleteKnowledgeBaseFile(knowledgeBaseId, fileId) {
        return this.knowledgeProvider.deleteKnowledgeBaseFile(knowledgeBaseId, fileId);
    }
    async searchKnowledgeBase(knowledgeBaseId, input) {
        return this.knowledgeProvider.searchKnowledgeBase(knowledgeBaseId, input);
    }
    async getCapabilities() {
        return this.kernel.getCapabilitySnapshot();
    }
    async getCapabilitySnapshot() {
        return this.kernel.getCapabilitySnapshot().snapshot;
    }
    async getPluginDiagnostics() {
        return this.kernel.diagnostics.snapshot();
    }
    async probeWorkspaceStreaming(workspaceId) {
        return this.workspaceRouter.probeWorkspaceStreaming(workspaceId);
    }
    async listChannelGatewayStatuses(platform) {
        if (!platform) {
            const [larkStatuses, weixinStatuses] = await Promise.all([
                this.channelRuntime.listStatuses(),
                this.weixinChannelRuntime.listStatuses(),
            ]);
            return [...larkStatuses, ...weixinStatuses];
        }
        return this.resolveChannelRuntime(platform).listStatuses();
    }
    async getChannelGatewayStatus(platform, workspaceId) {
        return this.resolveChannelRuntime(platform).getStatus(workspaceId);
    }
    async testChannelConnection(platform, workspaceId) {
        return this.resolveChannelRuntime(platform).testConnection(workspaceId);
    }
    async enableChannelGateway(platform, workspaceId) {
        return this.resolveChannelRuntime(platform).enable(workspaceId);
    }
    async disableChannelGateway(platform, workspaceId) {
        return this.resolveChannelRuntime(platform).disable(workspaceId);
    }
    async listChannelPendingPairings(platform, workspaceId) {
        return this.resolveChannelRuntime(platform).listPendingPairings(workspaceId);
    }
    async approveChannelPairing(platform, code) {
        return this.resolveChannelRuntime(platform).approvePairing(code);
    }
    async rejectChannelPairing(platform, code) {
        return this.resolveChannelRuntime(platform).rejectPairing(code);
    }
    async listChannelAuthorizedUsers(platform, workspaceId) {
        return this.resolveChannelRuntime(platform).listAuthorizedUsers(workspaceId);
    }
    async getWeixinQrCode(workspaceId) {
        const runtime = this.weixinChannelRuntime;
        return runtime.getQrCode(workspaceId);
    }
    async checkWeixinQrCodeStatus(workspaceId, ticket) {
        const runtime = this.weixinChannelRuntime;
        return runtime.checkQrCodeStatus(workspaceId, ticket);
    }
    async listLarkGatewayStatuses() {
        return this.listChannelGatewayStatuses('lark');
    }
    async getLarkGatewayStatus(workspaceId) {
        return this.getChannelGatewayStatus('lark', workspaceId);
    }
    async testLarkConnection(workspaceId) {
        return this.testChannelConnection('lark', workspaceId);
    }
    async enableLarkGateway(workspaceId) {
        return this.enableChannelGateway('lark', workspaceId);
    }
    async disableLarkGateway(workspaceId) {
        return this.disableChannelGateway('lark', workspaceId);
    }
    async listLarkPendingPairings(workspaceId) {
        return this.listChannelPendingPairings('lark', workspaceId);
    }
    async approveLarkPairing(code) {
        return this.approveChannelPairing('lark', code);
    }
    async rejectLarkPairing(code) {
        return this.rejectChannelPairing('lark', code);
    }
    async listLarkAuthorizedUsers(workspaceId) {
        return this.listChannelAuthorizedUsers('lark', workspaceId);
    }
    emitBridge(event) {
        this.emit('bridge', event);
    }
    async emitRuntime() {
        this.emit('runtime', await this.getRuntimeStatus());
    }
    handleLog(message) {
        this.emit('logs', message);
    }
    resolveChannelRuntime(platform) {
        if (platform === this.channelRuntime.platform) {
            return this.channelRuntime;
        }
        if (platform === this.weixinChannelRuntime.platform) {
            return this.weixinChannelRuntime;
        }
        throw new Error(`Unsupported channel platform: ${platform}`);
    }
    assertPlatform(platform) {
        this.resolveChannelRuntime(platform);
    }
}
exports.LocalCoreController = LocalCoreController;
