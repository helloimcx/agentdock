"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalCorePluginRegistry = void 0;
class LocalCorePluginRegistry {
    plugins = new Map();
    disabledPluginIds = new Set();
    registrationOrder = new Map();
    nextRegistrationOrder = 0;
    constructor(disabledPluginIds = []) {
        for (const pluginId of disabledPluginIds) {
            this.disabledPluginIds.add(pluginId);
        }
    }
    register(plugin) {
        if (this.plugins.has(plugin.manifest.id)) {
            throw new Error(`Plugin already registered: ${plugin.manifest.id}`);
        }
        this.plugins.set(plugin.manifest.id, plugin);
        this.registrationOrder.set(plugin.manifest.id, this.nextRegistrationOrder++);
    }
    get(pluginId) {
        return this.plugins.get(pluginId) || null;
    }
    list() {
        const sorted = [];
        const visiting = new Set();
        const visited = new Set();
        const visit = (plugin) => {
            const pluginId = plugin.manifest.id;
            if (visited.has(pluginId)) {
                return;
            }
            if (visiting.has(pluginId)) {
                throw new Error(`Plugin dependency cycle detected at: ${pluginId}`);
            }
            visiting.add(pluginId);
            for (const dependencyId of plugin.manifest.dependsOn || []) {
                const dependency = this.plugins.get(dependencyId);
                if (!dependency) {
                    throw new Error(`Plugin dependency missing: ${pluginId} depends on ${dependencyId}`);
                }
                visit(dependency);
            }
            visiting.delete(pluginId);
            visited.add(pluginId);
            sorted.push(plugin);
        };
        for (const plugin of [...this.plugins.values()].sort((a, b) => (this.registrationOrder.get(a.manifest.id) ?? 0) - (this.registrationOrder.get(b.manifest.id) ?? 0))) {
            visit(plugin);
        }
        return sorted;
    }
    isEnabled(pluginId) {
        return !this.disabledPluginIds.has(pluginId);
    }
    listEnabled() {
        return this.list().filter((plugin) => this.isEnabled(plugin.manifest.id));
    }
}
exports.LocalCorePluginRegistry = LocalCorePluginRegistry;
