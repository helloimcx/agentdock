"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalCoreDiagnostics = void 0;
class LocalCoreDiagnostics {
    registry;
    lifecycle;
    constructor(registry, lifecycle) {
        this.registry = registry;
        this.lifecycle = lifecycle;
    }
    async snapshot() {
        const plugins = this.registry.list();
        const health = await this.lifecycle.healthCheckAll();
        const healthByPlugin = new Map(health.map((entry) => [entry.pluginId, entry.health]));
        return {
            pluginCount: plugins.length,
            enabledPluginCount: plugins.filter((plugin) => this.registry.isEnabled(plugin.manifest.id)).length,
            plugins: plugins.map((plugin) => ({
                pluginId: plugin.manifest.id,
                enabled: this.registry.isEnabled(plugin.manifest.id),
                manifest: plugin.manifest,
                health: healthByPlugin.get(plugin.manifest.id) || { status: 'healthy' },
            })),
        };
    }
}
exports.LocalCoreDiagnostics = LocalCoreDiagnostics;
