"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalCoreLifecycleManager = void 0;
class LocalCoreLifecycleManager {
    registry;
    context;
    initialized = false;
    started = false;
    constructor(registry, context) {
        this.registry = registry;
        this.context = context;
    }
    async initAll() {
        if (this.initialized) {
            return;
        }
        for (const plugin of this.registry.listEnabled()) {
            try {
                await plugin.init?.(this.context);
            }
            catch (error) {
                this.context.logger.log(`[plugin:${plugin.manifest.id}] init failed: ${error instanceof Error ? error.message : String(error)}`);
            }
        }
        this.initialized = true;
    }
    async startAll() {
        if (this.started) {
            return;
        }
        await this.initAll();
        for (const plugin of this.registry.listEnabled()) {
            try {
                await plugin.start?.();
            }
            catch (error) {
                this.context.logger.log(`[plugin:${plugin.manifest.id}] start failed: ${error instanceof Error ? error.message : String(error)}`);
            }
        }
        this.started = true;
    }
    async stopAll() {
        if (!this.initialized) {
            return;
        }
        const plugins = this.registry.listEnabled().slice().reverse();
        for (const plugin of plugins) {
            try {
                await plugin.stop?.();
            }
            catch (error) {
                this.context.logger.log(`[plugin:${plugin.manifest.id}] stop failed: ${error instanceof Error ? error.message : String(error)}`);
            }
        }
        this.started = false;
    }
    async healthCheckAll() {
        const results = [];
        for (const plugin of this.registry.list()) {
            if (!this.registry.isEnabled(plugin.manifest.id)) {
                results.push({
                    pluginId: plugin.manifest.id,
                    health: { status: 'degraded', summary: 'Plugin is disabled by runtime settings.' },
                });
                continue;
            }
            let health;
            try {
                health = await plugin.healthCheck?.() || { status: 'healthy' };
            }
            catch (error) {
                health = {
                    status: 'failed',
                    summary: error instanceof Error ? error.message : String(error),
                };
            }
            results.push({
                pluginId: plugin.manifest.id,
                health,
            });
        }
        return results;
    }
}
exports.LocalCoreLifecycleManager = LocalCoreLifecycleManager;
