"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalCoreCapabilityRegistry = void 0;
class LocalCoreCapabilityRegistry {
    agents = new Map();
    channels = new Map();
    knowledge = new Map();
    schedulers = new Map();
    ui = new Map();
    registerAgent(capability) {
        this.agents.set(capability.id, capability);
    }
    registerChannel(capability) {
        this.channels.set(capability.id, capability);
    }
    registerKnowledge(capability) {
        this.knowledge.set(capability.id, capability);
    }
    registerScheduler(capability) {
        this.schedulers.set(capability.id, capability);
    }
    registerUi(capability) {
        this.ui.set(capability.id, capability);
    }
    registerContributions(contributions) {
        for (const capability of contributions.agents || []) {
            this.registerAgent(capability);
        }
        for (const capability of contributions.channels || []) {
            this.registerChannel(capability);
        }
        for (const capability of contributions.knowledge || []) {
            this.registerKnowledge(capability);
        }
        for (const capability of contributions.schedulers || []) {
            this.registerScheduler(capability);
        }
        for (const capability of contributions.ui || []) {
            this.registerUi(capability);
        }
    }
    listAgents() {
        return [...this.agents.values()];
    }
    listChannels() {
        return [...this.channels.values()];
    }
    listKnowledge() {
        return [...this.knowledge.values()];
    }
    listSchedulers() {
        return [...this.schedulers.values()];
    }
    listUi() {
        return [...this.ui.values()];
    }
    snapshot() {
        return {
            agents: this.listAgents(),
            channels: this.listChannels(),
            knowledge: this.listKnowledge(),
            schedulers: this.listSchedulers(),
            ui: this.listUi(),
        };
    }
}
exports.LocalCoreCapabilityRegistry = LocalCoreCapabilityRegistry;
