"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalCoreEventBus = void 0;
class LocalCoreEventBus {
    listeners = new Map();
    emit(event) {
        const listeners = this.listeners.get(event.type);
        if (!listeners) {
            return;
        }
        for (const listener of listeners) {
            listener(event.payload);
        }
    }
    on(type, listener) {
        const listeners = this.listeners.get(type) || new Set();
        listeners.add(listener);
        this.listeners.set(type, listeners);
        return () => {
            listeners.delete(listener);
            if (!listeners.size) {
                this.listeners.delete(type);
            }
        };
    }
}
exports.LocalCoreEventBus = LocalCoreEventBus;
