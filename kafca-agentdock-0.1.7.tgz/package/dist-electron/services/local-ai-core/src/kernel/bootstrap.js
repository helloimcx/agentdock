"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bootstrapLocalCoreKernel = bootstrapLocalCoreKernel;
exports.bootstrapLocalCoreRuntime = bootstrapLocalCoreRuntime;
const local_core_acp_store_js_1 = require("../acp/local-core-acp-store.js");
const capability_registry_js_1 = require("./capability-registry.js");
const diagnostics_js_1 = require("./diagnostics.js");
const event_bus_js_1 = require("./event-bus.js");
const lifecycle_manager_js_1 = require("./lifecycle-manager.js");
const plugin_registry_js_1 = require("./plugin-registry.js");
const agent_localcore_acp_plugin_js_1 = require("../plugins/builtin/agent-localcore-acp-plugin.js");
const channel_lark_plugin_js_1 = require("../plugins/builtin/channel-lark-plugin.js");
const channel_weixin_plugin_js_1 = require("../plugins/builtin/channel-weixin-plugin.js");
const knowledge_ai_vector_plugin_js_1 = require("../plugins/builtin/knowledge-ai-vector-plugin.js");
const knowledge_noop_plugin_js_1 = require("../plugins/builtin/knowledge-noop-plugin.js");
const scheduler_cron_plugin_js_1 = require("../plugins/builtin/scheduler-cron-plugin.js");
const scheduler_lark_plugin_js_1 = require("../plugins/builtin/scheduler-lark-plugin.js");
const scheduler_weixin_plugin_js_1 = require("../plugins/builtin/scheduler-weixin-plugin.js");
const workspace_router_js_1 = require("../router/workspace-router.js");
const local_core_runtime_state_js_1 = require("../runtime/local-core-runtime-state.js");
const scheduler_service_js_1 = require("../scheduler/scheduler-service.js");
function bootstrapLocalCoreKernel(options) {
    const capabilities = new capability_registry_js_1.LocalCoreCapabilityRegistry();
    const plugins = new plugin_registry_js_1.LocalCorePluginRegistry(options?.disabledPluginIds);
    const context = {
        bus: new event_bus_js_1.LocalCoreEventBus(),
        capabilities,
        logger: {
            log(message) {
                options?.log?.(message);
            },
        },
    };
    const lifecycle = new lifecycle_manager_js_1.LocalCoreLifecycleManager(plugins, context);
    const diagnostics = new diagnostics_js_1.LocalCoreDiagnostics(plugins, lifecycle);
    const builtIns = [
        ...['codex', 'cursor', 'gemini', 'qoder', 'iflow'].map((agentType) => (0, agent_localcore_acp_plugin_js_1.createBuiltinStaticAgentCapabilityPlugin)(agentType)),
        (0, agent_localcore_acp_plugin_js_1.createBuiltinLocalCoreAcpAgentPlugin)(),
        (0, scheduler_cron_plugin_js_1.createBuiltinCronSchedulerPlugin)(),
    ];
    for (const plugin of builtIns) {
        plugins.register(plugin);
        options?.log?.(`[plugin:${plugin.manifest.id}] registered`);
        if (plugin.capabilities && plugins.isEnabled(plugin.manifest.id)) {
            logCapabilityContributions(plugin, options?.log);
            capabilities.registerContributions(plugin.capabilities);
        }
        else if (!plugins.isEnabled(plugin.manifest.id)) {
            options?.log?.(`[plugin:${plugin.manifest.id}] disabled by runtime settings`);
        }
    }
    return {
        context,
        plugins,
        capabilities,
        lifecycle,
        diagnostics,
        getCapabilitySnapshot() {
            const snapshot = capabilities.snapshot();
            return {
                adapters: {
                    channels: snapshot.channels.map((capability) => capability.platform),
                    agents: snapshot.agents.map((capability) => capability.agentType),
                    knowledge: snapshot.knowledge.some((capability) => capability.enabled !== false),
                    knowledgeProviders: [...new Set(snapshot.knowledge
                            .filter((capability) => capability.enabled !== false)
                            .map((capability) => capability.sourceType))],
                },
                scheduler: {
                    enabled: snapshot.schedulers.some((capability) => capability.enabled !== false),
                    triggerTypes: [...new Set(snapshot.schedulers.flatMap((capability) => capability.triggerTypes))],
                    deliveryTargets: [...new Set(snapshot.schedulers.flatMap((capability) => capability.deliveryTargets || capability.deliveryPlatforms || []))],
                    platforms: [...new Set(snapshot.schedulers.flatMap((capability) => capability.deliveryTargets || capability.deliveryPlatforms || []))],
                },
                snapshot,
            };
        },
    };
}
function registerPlugin(kernel, plugin) {
    kernel.plugins.register(plugin);
    kernel.context.logger.log(`[plugin:${plugin.manifest.id}] registered`);
    if (plugin.capabilities && kernel.plugins.isEnabled(plugin.manifest.id)) {
        logCapabilityContributions(plugin, kernel.context.logger.log);
        kernel.capabilities.registerContributions(plugin.capabilities);
    }
    else if (!kernel.plugins.isEnabled(plugin.manifest.id)) {
        kernel.context.logger.log(`[plugin:${plugin.manifest.id}] disabled by runtime settings`);
    }
}
function logCapabilityContributions(plugin, log) {
    if (!log || !plugin.capabilities) {
        return;
    }
    const capabilityIds = [
        ...(plugin.capabilities.agents || []).map((capability) => capability.id),
        ...(plugin.capabilities.channels || []).map((capability) => capability.id),
        ...(plugin.capabilities.knowledge || []).map((capability) => capability.id),
        ...(plugin.capabilities.schedulers || []).map((capability) => capability.id),
        ...(plugin.capabilities.ui || []).map((capability) => capability.id),
    ];
    for (const capabilityId of capabilityIds) {
        log(`[plugin:${plugin.manifest.id}][capability:${capabilityId}] registered`);
    }
}
function resolveKnowledgeRuntime(plugin, context) {
    if (!plugin.createRuntime) {
        throw new Error(`Knowledge plugin ${plugin.manifest.id} does not provide a runtime factory.`);
    }
    const runtime = plugin.createRuntime(context);
    if (runtime instanceof Promise) {
        throw new Error(`Knowledge plugin ${plugin.manifest.id} returned an async runtime factory during synchronous bootstrap.`);
    }
    return runtime;
}
function resolveChannelRuntime(plugin, context) {
    if (!plugin.createRuntime) {
        throw new Error(`Channel plugin ${plugin.manifest.id} does not provide a runtime factory.`);
    }
    const runtime = plugin.createRuntime(context);
    if (runtime instanceof Promise) {
        throw new Error(`Channel plugin ${plugin.manifest.id} returned an async runtime factory during synchronous bootstrap.`);
    }
    return runtime;
}
function resolveAgentRuntime(plugin, context) {
    if (!plugin.createRuntime) {
        throw new Error(`Agent plugin ${plugin.manifest.id} does not provide a runtime factory.`);
    }
    const runtime = plugin.createRuntime(context);
    if (runtime instanceof Promise) {
        throw new Error(`Agent plugin ${plugin.manifest.id} returned an async runtime factory during synchronous bootstrap.`);
    }
    return runtime;
}
function resolveSchedulerRuntime(plugin, context) {
    if (!plugin.createRuntime) {
        throw new Error(`Scheduler plugin ${plugin.manifest.id} does not provide a runtime factory.`);
    }
    const runtime = plugin.createRuntime(context);
    if (runtime instanceof Promise) {
        throw new Error(`Scheduler plugin ${plugin.manifest.id} returned an async runtime factory during synchronous bootstrap.`);
    }
    return runtime;
}
function bootstrapLocalCoreRuntime(options) {
    const state = (0, local_core_runtime_state_js_1.createLocalCoreRuntimeState)({
        userDataPath: options.userDataPath,
        onLog: options.log,
    });
    const disabledPluginIds = Object.entries(state.getSettings().plugins)
        .filter(([, settings]) => settings.enabled === false)
        .map(([pluginId]) => pluginId);
    const kernel = bootstrapLocalCoreKernel({
        log: options.log,
        disabledPluginIds,
    });
    const store = new local_core_acp_store_js_1.LocalCoreAcpStore(options.userDataPath);
    const localCoreAgentPlugin = kernel.plugins.get('builtin.agent-localcore-acp');
    if (!localCoreAgentPlugin) {
        throw new Error('Missing built-in LocalCore ACP agent plugin.');
    }
    const agentPlugins = [
        localCoreAgentPlugin,
        (0, agent_localcore_acp_plugin_js_1.createBuiltinOpencodeAgentPlugin)(),
        (0, agent_localcore_acp_plugin_js_1.createBuiltinClaudeCodeAgentPlugin)(),
    ];
    let workspaceRouter;
    let weixinChannelRuntime;
    const channelPlugin = (0, channel_lark_plugin_js_1.createBuiltinLarkChannelPlugin)({
        store,
        readConfig: async () => (await state.readConfigFile()).parsed,
        getWorkspaceRouter: () => workspaceRouter,
        log: options.log,
    });
    const weixinChannelPlugin = (0, channel_weixin_plugin_js_1.createBuiltinWeixinChannelPlugin)({
        store,
        readConfig: async () => (await state.readConfigFile()).parsed,
        getWorkspaceRouter: () => workspaceRouter,
        log: options.log,
    });
    const knowledgePlugin = options.enableKnowledge === false
        ? (0, knowledge_noop_plugin_js_1.createBuiltinNoopKnowledgePlugin)()
        : (0, knowledge_ai_vector_plugin_js_1.createBuiltinAiVectorKnowledgePlugin)({
            userDataPath: options.userDataPath,
            getConfig: () => state.getKnowledgeConfig(),
            setConfig: (input) => state.updateKnowledgeConfig(input),
        });
    const schedulerPlugins = [
        (0, scheduler_lark_plugin_js_1.createBuiltinLarkSchedulerPlugin)({
            store,
            getWorkspaceRouter: () => workspaceRouter,
            getChannelRuntime: () => channelRuntime,
            log: options.log,
        }),
        (0, scheduler_weixin_plugin_js_1.createBuiltinWeixinSchedulerPlugin)({
            store,
            getWorkspaceRouter: () => workspaceRouter,
            getChannelRuntime: () => weixinChannelRuntime,
            log: options.log,
        }),
    ];
    for (const plugin of agentPlugins.filter((plugin) => plugin !== localCoreAgentPlugin)) {
        registerPlugin(kernel, plugin);
    }
    registerPlugin(kernel, channelPlugin);
    registerPlugin(kernel, weixinChannelPlugin);
    registerPlugin(kernel, knowledgePlugin);
    for (const plugin of schedulerPlugins) {
        registerPlugin(kernel, plugin);
    }
    const agentRuntimes = agentPlugins
        .filter((plugin) => kernel.plugins.isEnabled(plugin.manifest.id))
        .map((plugin) => resolveAgentRuntime(plugin, kernel.context).runtime);
    const channelRuntime = resolveChannelRuntime(channelPlugin, kernel.context).channel;
    weixinChannelRuntime = resolveChannelRuntime(weixinChannelPlugin, kernel.context).channel;
    const knowledgeRuntime = kernel.plugins.isEnabled(knowledgePlugin.manifest.id)
        ? resolveKnowledgeRuntime(knowledgePlugin, kernel.context)
        : resolveKnowledgeRuntime((0, knowledge_noop_plugin_js_1.createBuiltinNoopKnowledgePlugin)(), kernel.context);
    const cronSchedulerPlugin = (0, scheduler_cron_plugin_js_1.createBuiltinCronSchedulerPlugin)();
    const schedulerRuntimes = [
        ...(kernel.plugins.isEnabled(cronSchedulerPlugin.manifest.id)
            ? [resolveSchedulerRuntime(cronSchedulerPlugin, kernel.context)]
            : []),
        ...schedulerPlugins
            .filter((plugin) => kernel.plugins.isEnabled(plugin.manifest.id))
            .map((plugin) => resolveSchedulerRuntime(plugin, kernel.context)),
    ];
    const schedulerTriggers = schedulerRuntimes.flatMap((runtime) => runtime.triggers || []);
    const schedulerExecutors = schedulerRuntimes.flatMap((runtime) => runtime.executors || []);
    const knowledgeProvider = knowledgeRuntime.provider;
    const knowledgeAttachments = knowledgeRuntime.attachments;
    workspaceRouter = (0, workspace_router_js_1.createWorkspaceRouter)({
        store,
        cliBinDir: state.cliBinDir,
        localCoreBase: options.localCoreBase,
        readConfigState: () => state.readConfigFile(),
        getCapabilities: () => kernel.getCapabilitySnapshot(),
        getAgentRuntimes: () => agentRuntimes,
        eventBus: kernel.context.bus,
        knowledgeProvider,
        knowledgeAttachments,
        log: options.log,
    });
    const scheduler = new scheduler_service_js_1.SchedulerService({
        store,
        triggers: schedulerTriggers,
        executors: schedulerExecutors,
        eventBus: kernel.context.bus,
        log: options.log,
    });
    workspaceRouter.setSchedulerBridge({
        createJob: async ({ workspaceId, platform, route, name, schedule, scheduleDescription, message }) => scheduler.createJob({
            workspaceId,
            platform,
            route,
            triggerType: 'cron',
            cronExpr: schedule,
            promptTemplate: message,
            description: `${name} · ${scheduleDescription}`,
            enabled: true,
        }),
        listJobsForThread: async (threadId) => scheduler
            .listJobs()
            .filter((job) => job.route.threadId === threadId),
        deleteJob: async (jobId) => {
            scheduler.deleteJob(jobId);
        },
    });
    return {
        kernel,
        state,
        store,
        agentRuntimes,
        channelRuntime,
        weixinChannelRuntime,
        knowledgeProvider,
        knowledgeAttachments,
        workspaceRouter,
        scheduler,
        async start() {
            await kernel.lifecycle.startAll();
            await scheduler.start();
        },
        async stop() {
            await scheduler.stop();
            await kernel.lifecycle.stopAll();
            workspaceRouter.close();
        },
    };
}
