"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalCoreAcpBackend = void 0;
const node_crypto_1 = require("node:crypto");
const desktop_js_1 = require("../../../../shared/desktop.js");
const local_core_acp_transport_js_1 = require("./local-core-acp-transport.js");
const local_core_acp_turn_coordinator_js_1 = require("./local-core-acp-turn-coordinator.js");
const local_core_acp_session_coordinator_js_1 = require("./local-core-acp-session-coordinator.js");
const local_core_acp_response_processor_js_1 = require("./local-core-acp-response-processor.js");
const ACP_PROMPT_TIMEOUT_MS = 15 * 60 * 1000;
class LocalCoreAcpBackend {
    options;
    transport;
    turnCoordinator;
    sessionCoordinator;
    responseProcessor;
    constructor(options) {
        this.options = options;
        this.transport = new local_core_acp_transport_js_1.LocalCoreAcpTransport({
            log: options.log,
            onAgentRequest: (session, payload) => this.handleAgentRequest(session, payload),
            onAgentNotification: (session, payload) => this.handleAgentNotification(session, payload),
            onSessionClosed: (session, error) => this.handleTransportSessionClosed(session, error),
        });
        this.turnCoordinator = new local_core_acp_turn_coordinator_js_1.LocalCoreAcpTurnCoordinator({
            emitBridge: (event) => this.emitBridgeEvent(event),
            appendMessage: (threadId, role, content, kind) => {
                this.options.store.appendMessage(threadId, role, content, kind);
            },
            updateRunStatus: (runId, threadId, status) => {
                this.options.store.updateRun(runId, threadId, status);
            },
            sendRaw: (session, payload) => this.transport.sendRaw(session, payload),
        });
        this.sessionCoordinator = new local_core_acp_session_coordinator_js_1.LocalCoreAcpSessionCoordinator({
            store: options.store,
            transport: this.transport,
            runThreadMap: options.runThreadMap,
            cliBinDir: options.cliBinDir,
            localCoreBase: options.localCoreBase,
            emitBridge: (event) => this.emitBridgeEvent(event),
            log: options.log,
        });
        this.responseProcessor = new local_core_acp_response_processor_js_1.LocalCoreAcpResponseProcessor({
            getScheduledDeliveryBinding: (threadId) => {
                const binding = this.options.store.getPlatformThreadBindingByThreadId(threadId);
                if (!binding) {
                    return null;
                }
                return {
                    workspaceId: binding.workspace_id,
                    platform: binding.platform,
                    route: {
                        type: binding.platform === 'lark' ? 'channel.chat' : binding.platform,
                        channelId: binding.chat_id,
                        participantId: binding.platform_user_id,
                        threadId,
                    },
                };
            },
            scheduler: options.scheduler,
        });
    }
    close() {
        this.sessionCoordinator.closeAll();
    }
    async listThreads(workspaceId) {
        return this.options.store.listThreadSummaries(workspaceId);
    }
    async createThread(workspaceId, title, agentType = desktop_js_1.LOCALCORE_ACP_AGENT_TYPE) {
        return this.options.store.createThread(workspaceId, title, agentType);
    }
    async getThread(threadId) {
        const detail = this.options.store.getThread(threadId, []);
        return {
            ...detail,
            pendingPermissionRequest: this.turnCoordinator.getPendingPermissionRequest(this.sessionCoordinator.getSession(threadId), detail),
        };
    }
    async renameThread(threadId, title) {
        this.options.store.renameThread(threadId, title);
        return this.getThread(threadId);
    }
    async deleteThread(threadId) {
        this.sessionCoordinator.closeThreadSession(threadId);
        this.options.store.deleteThread(threadId);
        return { deleted: true };
    }
    async sendThreadMessage(threadId, content, config) {
        if (!config) {
            throw new Error('localcore-acp message send requires a workspace config.');
        }
        const row = this.options.store.getThreadRow(threadId);
        if (!row) {
            throw new Error(`Thread not found: ${threadId}`);
        }
        this.options.store.appendMessage(threadId, 'user', content, 'final');
        this.options.eventBus.emit({
            type: 'thread.message.accepted',
            payload: {
                threadId,
                workspaceId: row.workspace_id,
                role: 'user',
                content,
                kind: 'final',
                source: 'user',
            },
        });
        const runId = `run:${threadId}:${Date.now()}`;
        this.options.runThreadMap.set(runId, threadId);
        this.options.store.updateRun(runId, threadId, 'running');
        this.options.eventBus.emit({
            type: 'run.started',
            payload: {
                runId,
                threadId,
                workspaceId: row.workspace_id,
                prompt: content,
                sessionKey: row.bridge_session_key,
            },
        });
        void this.runPrompt(threadId, runId, row.bridge_session_key, config, content).catch((error) => {
            this.options.log?.(`localcore-acp prompt failed for ${threadId}: ${error instanceof Error ? error.message : String(error)}`);
        });
        return { runId };
    }
    async sendThreadAction(threadId, content, config) {
        const session = this.sessionCoordinator.getSession(threadId);
        if (!session?.currentRunId) {
            return this.sendThreadMessage(threadId, content, config);
        }
        const pendingPermission = session.pendingPermissionByRun.get(session.currentRunId);
        if (!pendingPermission) {
            return this.sendThreadMessage(threadId, content, config);
        }
        const action = String(content || '').trim().toLowerCase();
        const matched = pendingPermission.options.find((option) => option.normalizedAction === action || option.optionId === action);
        if (!matched) {
            throw new Error(`Unknown permission option: ${content}`);
        }
        const accepted = this.transport.sendRaw(session, {
            jsonrpc: '2.0',
            id: pendingPermission.requestId,
            result: {
                outcome: {
                    outcome: 'selected',
                    optionId: matched.optionId,
                },
            },
        });
        if (!accepted) {
            throw new Error(session.closeReason || 'ACP session is not writable');
        }
        session.pendingPermissionByRun.delete(session.currentRunId);
        this.emitBridgeEvent({
            type: 'typing_start',
            sessionKey: session.bridgeSessionKey,
            replyCtx: session.currentRunId,
        });
        return { runId: session.currentRunId };
    }
    async interruptRun(runId) {
        return this.sessionCoordinator.interruptRun(runId);
    }
    async runPrompt(threadId, runId, bridgeSessionKey, config, content) {
        const row = this.options.store.getThreadRow(threadId);
        if (!row) {
            throw new Error(`Thread not found: ${threadId}`);
        }
        this.emitBridgeEvent({
            type: 'typing_start',
            sessionKey: bridgeSessionKey,
            replyCtx: runId,
        });
        let session = null;
        try {
            session = await this.sessionCoordinator.ensureSession(threadId, bridgeSessionKey, config);
            session.currentRunId = runId;
            session.currentTurn = {
                runId,
                replyCtx: runId,
                previewHandle: (0, node_crypto_1.randomUUID)(),
                assistantText: '',
                typingStarted: true,
                previewStarted: false,
                pendingToolCallTitle: undefined,
                permission: null,
            };
            const promptPromise = this.transport.request(session, 'session/prompt', {
                sessionId: session.sessionId,
                messageId: (0, node_crypto_1.randomUUID)(),
                prompt: [
                    {
                        type: 'text',
                        text: content,
                    },
                ],
            }, ACP_PROMPT_TIMEOUT_MS);
            session.promptPromise = promptPromise;
            const result = await promptPromise;
            const currentTurn = session.currentTurn;
            if (!currentTurn || currentTurn.runId !== runId) {
                return;
            }
            this.turnCoordinator.flushPendingToolCall(session);
            if (currentTurn.assistantText) {
                const processed = await this.responseProcessor.processAssistantResponse(threadId, currentTurn.assistantText);
                if (processed.displayContent) {
                    this.options.store.appendMessage(threadId, 'assistant', processed.displayContent, 'final');
                    this.options.eventBus.emit({
                        type: 'thread.message.accepted',
                        payload: {
                            threadId,
                            workspaceId: row.workspace_id,
                            role: 'assistant',
                            content: processed.displayContent,
                            kind: 'final',
                            source: 'agent',
                        },
                    });
                    this.emitBridgeEvent({
                        type: 'reply',
                        sessionKey: bridgeSessionKey,
                        replyCtx: runId,
                        content: processed.displayContent,
                    });
                }
                for (const systemResponse of processed.systemResponses) {
                    this.options.store.appendMessage(threadId, 'system', systemResponse, 'system');
                    this.options.eventBus.emit({
                        type: 'thread.message.accepted',
                        payload: {
                            threadId,
                            workspaceId: row.workspace_id,
                            role: 'system',
                            content: systemResponse,
                            kind: 'system',
                            source: 'system',
                        },
                    });
                }
            }
            else if (String(content || '').trim().startsWith('/')) {
                const slashReply = this.responseProcessor.deriveSlashCommandReply(content, result);
                if (slashReply) {
                    this.options.store.appendMessage(threadId, 'assistant', slashReply, 'final');
                    this.options.eventBus.emit({
                        type: 'thread.message.accepted',
                        payload: {
                            threadId,
                            workspaceId: row.workspace_id,
                            role: 'assistant',
                            content: slashReply,
                            kind: 'final',
                            source: 'agent',
                        },
                    });
                    this.emitBridgeEvent({
                        type: 'reply',
                        sessionKey: bridgeSessionKey,
                        replyCtx: runId,
                        content: slashReply,
                    });
                }
            }
            else if (result?.stopReason === 'cancelled') {
                this.emitBridgeEvent({
                    type: 'reply',
                    sessionKey: bridgeSessionKey,
                    replyCtx: runId,
                    content: 'Request cancelled.',
                });
            }
            const nextStatus = result?.stopReason === 'cancelled' ? 'interrupted' : 'completed';
            this.options.store.updateRun(runId, threadId, nextStatus);
            this.options.eventBus.emit({
                type: 'run.completed',
                payload: {
                    runId,
                    threadId,
                    workspaceId: row.workspace_id,
                    stopReason: result?.stopReason,
                },
            });
            this.emitBridgeEvent({
                type: 'typing_stop',
                sessionKey: bridgeSessionKey,
                replyCtx: runId,
            });
        }
        catch (error) {
            const errorContent = `Agent error: ${error instanceof Error ? error.message : String(error)}`;
            this.options.store.updateRun(runId, threadId, 'failed');
            this.options.store.appendMessage(threadId, 'assistant', errorContent, 'final');
            this.options.eventBus.emit({
                type: 'thread.message.accepted',
                payload: {
                    threadId,
                    workspaceId: row.workspace_id,
                    role: 'assistant',
                    content: errorContent,
                    kind: 'final',
                    source: 'agent',
                },
            });
            this.options.eventBus.emit({
                type: 'run.failed',
                payload: {
                    runId,
                    threadId,
                    workspaceId: row.workspace_id,
                    error: error instanceof Error ? error.message : String(error),
                },
            });
            this.emitBridgeEvent({
                type: 'reply',
                sessionKey: bridgeSessionKey,
                replyCtx: runId,
                content: errorContent,
            });
            this.emitBridgeEvent({
                type: 'typing_stop',
                sessionKey: bridgeSessionKey,
                replyCtx: runId,
            });
        }
        finally {
            if (session?.currentRunId === runId) {
                session.currentRunId = null;
            }
            if (session?.currentTurn?.runId === runId) {
                session.currentTurn = null;
            }
            if (session) {
                session.promptPromise = null;
            }
        }
    }
    handleAgentRequest(session, payload) {
        this.turnCoordinator.handleAgentRequest(session, payload);
    }
    handleAgentNotification(session, payload) {
        this.turnCoordinator.handleAgentNotification(session, payload);
    }
    handleTransportSessionClosed(session, error) {
        this.sessionCoordinator.handleTransportSessionClosed(session, error);
    }
    emitBridgeEvent(event) {
        if (event.replyCtx) {
            const threadId = this.options.runThreadMap.get(event.replyCtx);
            if (threadId) {
                const thread = this.options.store.getThreadRow(threadId);
                if (thread) {
                    this.options.eventBus.emit({
                        type: 'run.progress',
                        payload: {
                            runId: event.replyCtx,
                            threadId,
                            workspaceId: thread.workspace_id,
                            stream: event,
                        },
                    });
                }
            }
        }
        this.options.emitBridge(event);
    }
}
exports.LocalCoreAcpBackend = LocalCoreAcpBackend;
