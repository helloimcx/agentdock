"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalCoreAcpSessionCoordinator = void 0;
const node_path_1 = require("node:path");
class LocalCoreAcpSessionCoordinator {
    options;
    sessions = new Map();
    constructor(options) {
        this.options = options;
    }
    getSession(threadId) {
        return this.sessions.get(threadId);
    }
    closeAll() {
        for (const session of this.sessions.values()) {
            this.options.transport.closeSession(session);
        }
        this.sessions.clear();
    }
    closeThreadSession(threadId) {
        const session = this.sessions.get(threadId);
        if (!session) {
            return;
        }
        this.options.transport.closeSession(session);
        this.sessions.delete(threadId);
    }
    async ensureSession(threadId, bridgeSessionKey, config) {
        const existing = this.sessions.get(threadId);
        if (existing && !existing.closed && existing.sessionId) {
            return existing;
        }
        if (existing) {
            this.closeThreadSession(threadId);
        }
        const baseEnv = {
            ...process.env,
            ...config.env,
        };
        const session = this.options.transport.spawnSession({
            threadId,
            bridgeSessionKey,
            config,
            runtimeEnv: this.buildAgentRuntimeEnv(threadId, String(baseEnv.PATH || '')),
        });
        this.sessions.set(threadId, session);
        await this.options.transport.initializeSession(session);
        const row = this.options.store.getThreadRow(threadId);
        if (row?.acp_session_id && row.acp_supports_load && session.supportsLoad) {
            try {
                session.loadReplayMode = true;
                await this.options.transport.request(session, 'session/load', {
                    sessionId: row.acp_session_id,
                    cwd: config.workDir,
                    mcpServers: [],
                }, 30000);
                session.sessionId = row.acp_session_id;
            }
            catch (error) {
                this.options.log?.(`ACP loadSession failed for ${threadId}; creating a fresh session instead: ${error instanceof Error ? error.message : String(error)}`);
            }
            finally {
                session.loadReplayMode = false;
            }
        }
        if (!session.sessionId) {
            try {
                const created = await this.options.transport.request(session, 'session/new', {
                    cwd: config.workDir,
                    mcpServers: [],
                }, 30000);
                session.sessionId = String(created.sessionId || created.session_id || created.id || created.session?.sessionId || created.session?.session_id || created.session?.id || '').trim();
                if (!session.sessionId) {
                    throw new Error('ACP session/new did not return a sessionId');
                }
                this.options.store.updateThreadSession(threadId, session.sessionId, session.supportsLoad);
            }
            catch (error) {
                this.closeThreadSession(threadId);
                throw error;
            }
        }
        return session;
    }
    async interruptRun(runId) {
        const threadId = this.options.runThreadMap.get(runId);
        if (!threadId) {
            return { interrupted: false };
        }
        const session = this.sessions.get(threadId);
        if (!session) {
            this.options.store.updateRun(runId, threadId, 'interrupted');
            return { interrupted: false };
        }
        if (!session.sessionId) {
            this.options.store.updateRun(runId, threadId, 'interrupted');
            this.closeThreadSession(threadId);
            return { interrupted: false };
        }
        const pendingPermission = session.pendingPermissionByRun.get(runId);
        if (pendingPermission) {
            this.options.transport.sendRaw(session, {
                jsonrpc: '2.0',
                id: pendingPermission.requestId,
                result: {
                    outcome: {
                        outcome: 'cancelled',
                    },
                },
            });
            session.pendingPermissionByRun.delete(runId);
        }
        const cancelled = this.options.transport.sendRaw(session, {
            jsonrpc: '2.0',
            method: 'session/cancel',
            params: {
                sessionId: session.sessionId,
            },
        });
        if (!cancelled) {
            this.options.store.updateRun(runId, threadId, 'interrupted');
            return { interrupted: false };
        }
        this.options.store.updateRun(runId, threadId, 'interrupted');
        return { interrupted: true };
    }
    handleTransportSessionClosed(session, error) {
        if (session.closed) {
            return;
        }
        const activeRunId = session.currentRunId;
        this.options.transport.closeSessionWithError(session, error);
        if (activeRunId) {
            this.options.store.updateRun(activeRunId, session.threadId, 'failed');
            this.options.emitBridge({
                type: 'typing_stop',
                sessionKey: session.bridgeSessionKey,
                replyCtx: activeRunId,
            });
            session.pendingPermissionByRun.delete(activeRunId);
        }
        if (this.sessions.get(session.threadId) === session) {
            this.sessions.delete(session.threadId);
        }
    }
    buildAgentRuntimeEnv(threadId, existingPath) {
        const row = this.options.store.getThreadRow(threadId);
        if (!row) {
            return {};
        }
        const binding = this.options.store.getPlatformThreadBindingByThreadId(threadId);
        const env = {
            LOCAL_AI_CORE_BASE: this.options.localCoreBase || 'http://127.0.0.1:9831/api/local/v1',
            LOCAL_AI_WORKSPACE_ID: row.workspace_id,
            LOCAL_AI_THREAD_ID: threadId,
        };
        if (binding) {
            env.LOCAL_AI_PLATFORM = binding.platform;
            env.LOCAL_AI_ROUTE_TYPE = 'lark_chat';
            env.LOCAL_AI_CHAT_ID = binding.chat_id;
            env.LOCAL_AI_PLATFORM_USER_ID = binding.platform_user_id;
        }
        if (this.options.cliBinDir) {
            env.PATH = existingPath
                ? `${this.options.cliBinDir}${node_path_1.delimiter}${existingPath}`
                : this.options.cliBinDir;
        }
        return env;
    }
}
exports.LocalCoreAcpSessionCoordinator = LocalCoreAcpSessionCoordinator;
