"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizePermissionAction = normalizePermissionAction;
exports.formatToolCallContent = formatToolCallContent;
exports.toPermissionButtonRows = toPermissionButtonRows;
function normalizePermissionAction(kind) {
    const normalized = String(kind || '').trim().toLowerCase();
    if (normalized === 'allow_always') {
        return 'allow all';
    }
    if (normalized.startsWith('allow')) {
        return 'allow';
    }
    if (normalized.startsWith('reject')) {
        return 'deny';
    }
    return '';
}
function formatToolCallContent(toolCall) {
    if (!toolCall || typeof toolCall !== 'object') {
        return 'Permission required before continuing.';
    }
    const title = typeof toolCall.title === 'string' ? toolCall.title.trim() : '';
    const content = Array.isArray(toolCall.content)
        ? toolCall.content
            .map((entry) => {
            if (!entry || typeof entry !== 'object') {
                return '';
            }
            if (typeof entry.text === 'string') {
                return String(entry.text).trim();
            }
            const nested = entry.content;
            return nested?.type === 'text' ? String(nested.text || '').trim() : '';
        })
            .filter(Boolean)
            .join('\n')
        : '';
    return [title, content].filter(Boolean).join('\n\n') || 'Permission required before continuing.';
}
function toPermissionButtonRows(options, normalizeButton) {
    return [options.map((option) => {
            const data = option.normalizedAction
                ? `perm:${option.normalizedAction.replace(/\s+/g, '_')}`
                : option.optionId;
            const normalized = normalizeButton({
                text: option.normalizedAction || option.name,
                data,
            });
            return normalized || { text: option.name, data: option.optionId };
        })];
}
