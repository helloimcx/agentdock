"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalCoreAcpTurnCoordinator = void 0;
const desktop_js_1 = require("../../../../shared/desktop.js");
const workspace_acp_permissions_js_1 = require("./workspace-acp-permissions.js");
class LocalCoreAcpTurnCoordinator {
    options;
    constructor(options) {
        this.options = options;
    }
    flushPendingToolCall(session) {
        const currentTurn = session.currentTurn;
        const currentRunId = session.currentRunId;
        const title = currentTurn?.pendingToolCallTitle?.trim();
        if (!currentTurn || !currentRunId || !title) {
            return;
        }
        currentTurn.pendingToolCallTitle = undefined;
        this.emitProgress(session, currentRunId, `🔧 ${title}`);
    }
    getPendingPermissionRequest(session, detail) {
        const runId = session?.currentRunId;
        if (!session || !runId) {
            return null;
        }
        const pendingPermission = session.pendingPermissionByRun.get(runId);
        if (!pendingPermission) {
            return null;
        }
        const latestAssistantMessage = [...detail.messages].reverse().find((message) => message.role === 'assistant');
        return {
            id: latestAssistantMessage?.id || `${runId}-buttons`,
            content: latestAssistantMessage?.content || 'Permission required before continuing.',
            actions: (0, workspace_acp_permissions_js_1.toPermissionButtonRows)(pendingPermission.options, desktop_js_1.normalizeDesktopBridgeButtonOption),
            actionReplyCtx: runId,
            actionPending: false,
            actionStatus: undefined,
            actionMode: 'permission',
            actionInteractive: true,
        };
    }
    handleAgentRequest(session, payload) {
        if (payload.method !== 'session/request_permission') {
            this.options.sendRaw(session, {
                jsonrpc: '2.0',
                id: payload.id,
                error: {
                    code: -32601,
                    message: `Unsupported ACP client method: ${String(payload.method || '')}`,
                },
            });
            return;
        }
        const currentRunId = session.currentRunId;
        if (!currentRunId) {
            this.options.sendRaw(session, {
                jsonrpc: '2.0',
                id: payload.id,
                result: {
                    outcome: {
                        outcome: 'cancelled',
                    },
                },
            });
            return;
        }
        const options = Array.isArray(payload.params?.options)
            ? payload.params.options
                .map((option) => ({
                optionId: String(option?.optionId || '').trim(),
                name: String(option?.name || option?.optionId || '').trim(),
                kind: String(option?.kind || '').trim(),
                normalizedAction: (0, workspace_acp_permissions_js_1.normalizePermissionAction)(option?.kind),
            }))
                .filter((option) => option.optionId)
            : [];
        const toolTitle = (0, workspace_acp_permissions_js_1.formatToolCallContent)(payload.params?.toolCall);
        const isSchedulerAdd = isSchedulerAddCommand(toolTitle);
        if (isSchedulerAdd && session.schedulerJobCreatedByRun.get(currentRunId)) {
            this.options.sendRaw(session, {
                jsonrpc: '2.0',
                id: payload.id,
                result: {
                    outcome: {
                        outcome: 'cancelled',
                    },
                },
            });
            const content = '已限制本次对话只创建一个定时任务，额外的 scheduler add 请求已自动取消。';
            this.options.appendMessage(session.threadId, 'assistant', content, 'progress');
            this.options.emitBridge({
                type: 'reply',
                sessionKey: session.bridgeSessionKey,
                replyCtx: currentRunId,
                content,
            });
            return;
        }
        const buttonRows = (0, workspace_acp_permissions_js_1.toPermissionButtonRows)(options, desktop_js_1.normalizeDesktopBridgeButtonOption);
        const permissionRequest = {
            requestId: payload.id,
            toolTitle,
            isSchedulerAdd,
            options,
        };
        session.pendingPermissionByRun.set(currentRunId, permissionRequest);
        if (session.currentTurn) {
            session.currentTurn.permission = permissionRequest;
        }
        this.options.updateRunStatus(currentRunId, session.threadId, 'awaiting_input');
        const permissionPrompt = [
            '等待工具确认',
            '',
            toolTitle,
            '',
            '请选择一个选项继续执行。',
            '',
            '若按钮没有显示，请直接回复：allow all / allow / deny',
        ].join('\n');
        this.options.appendMessage(session.threadId, 'assistant', permissionPrompt, 'progress');
        this.options.emitBridge({
            type: 'buttons',
            sessionKey: session.bridgeSessionKey,
            replyCtx: currentRunId,
            content: permissionPrompt,
            buttonRows,
        });
    }
    handleAgentNotification(session, payload) {
        if (session.loadReplayMode || payload.method !== 'session/update') {
            return;
        }
        const update = payload.params?.update;
        const currentTurn = session.currentTurn;
        const currentRunId = session.currentRunId;
        if (!update || !currentTurn || !currentRunId) {
            return;
        }
        switch (String(update.sessionUpdate || '')) {
            case 'agent_message_chunk': {
                this.flushPendingToolCall(session);
                if (update.content?.type !== 'text') {
                    return;
                }
                currentTurn.assistantText += String(update.content.text || '');
                if (!currentTurn.previewStarted) {
                    currentTurn.previewStarted = true;
                    this.options.emitBridge({
                        type: 'preview_start',
                        sessionKey: session.bridgeSessionKey,
                        replyCtx: currentRunId,
                        previewHandle: currentTurn.previewHandle,
                        content: currentTurn.assistantText,
                    });
                    return;
                }
                this.options.emitBridge({
                    type: 'update_message',
                    sessionKey: session.bridgeSessionKey,
                    replyCtx: currentRunId,
                    previewHandle: currentTurn.previewHandle,
                    content: currentTurn.assistantText,
                });
                return;
            }
            case 'tool_call': {
                const title = String(update.title || 'Running tool').trim();
                this.flushPendingToolCall(session);
                currentTurn.pendingToolCallTitle = title;
                return;
            }
            case 'tool_call_update': {
                const title = String(update.title || 'Tool update').trim();
                const status = String(update.status || '').trim();
                const content = this.extractToolUpdateContent(update.content);
                if (isSchedulerAddCommand(title) && /Created scheduler job\b/.test(content)) {
                    session.schedulerJobCreatedByRun.set(currentRunId, true);
                }
                const toolName = currentTurn.pendingToolCallTitle?.trim();
                if (this.isEmptyRunningToolUpdate(title, status, content)) {
                    currentTurn.pendingToolCallTitle = undefined;
                    return;
                }
                currentTurn.pendingToolCallTitle = undefined;
                this.emitProgress(session, currentRunId, this.formatToolProgressMessage(toolName, title, status, content));
                return;
            }
            case 'plan': {
                this.flushPendingToolCall(session);
                const entries = Array.isArray(update.entries) ? update.entries : [];
                if (entries.length === 0) {
                    return;
                }
                const summary = entries
                    .map((entry) => String(entry?.content || '').trim())
                    .filter(Boolean)
                    .join(' | ');
                const content = `💭 ${summary}`;
                this.options.appendMessage(session.threadId, 'assistant', content, 'progress');
                this.options.emitBridge({
                    type: 'reply',
                    sessionKey: session.bridgeSessionKey,
                    replyCtx: currentRunId,
                    content,
                });
                return;
            }
            default:
                return;
        }
    }
    emitProgress(session, currentRunId, content) {
        this.options.appendMessage(session.threadId, 'assistant', content, 'progress');
        this.options.emitBridge({
            type: 'reply',
            sessionKey: session.bridgeSessionKey,
            replyCtx: currentRunId,
            content,
        });
    }
    extractToolUpdateContent(content) {
        return Array.isArray(content)
            ? content
                .map((entry) => entry?.type === 'content' && entry?.content?.type === 'text'
                ? String(entry.content.text || '')
                : '')
                .filter(Boolean)
                .join('\n')
            : '';
    }
    formatToolProgressMessage(toolName, title, status, content) {
        const detail = [title, status, content].filter(Boolean).join(' - ');
        return toolName ? `🔧 ${toolName}: ${detail || 'Tool update'}` : `🔧 ${detail || 'Tool update'}`;
    }
    isEmptyRunningToolUpdate(title, status, content) {
        return !content.trim() &&
            /^running$/i.test(status) &&
            (!title.trim() || /^tool update$/i.test(title));
    }
}
exports.LocalCoreAcpTurnCoordinator = LocalCoreAcpTurnCoordinator;
function isSchedulerAddCommand(value) {
    return /\blac\s+scheduler\s+add\b/.test(String(value || ''));
}
