"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalCoreAcpTransport = void 0;
const node_child_process_1 = require("node:child_process");
class LocalCoreAcpTransport {
    options;
    constructor(options) {
        this.options = options;
    }
    spawnSession(input) {
        const baseEnv = {
            ...process.env,
            ...input.config.env,
        };
        const child = (0, node_child_process_1.spawn)(input.config.command, input.config.args, {
            cwd: input.config.workDir,
            env: {
                ...baseEnv,
                ...input.runtimeEnv,
            },
            stdio: ['pipe', 'pipe', 'pipe'],
        });
        const session = {
            child,
            requestId: 0,
            stdoutBuffer: '',
            pending: new Map(),
            sessionId: '',
            supportsLoad: false,
            workspaceId: input.config.workspaceId,
            threadId: input.threadId,
            bridgeSessionKey: input.bridgeSessionKey,
            currentRunId: null,
            currentTurn: null,
            loadReplayMode: false,
            pendingPermissionByRun: new Map(),
            schedulerJobCreatedByRun: new Map(),
            closed: false,
            closeReason: null,
            promptPromise: null,
        };
        child.stdout.setEncoding('utf8');
        child.stdout.on('data', (chunk) => this.handleStdout(session, chunk));
        child.stderr.setEncoding('utf8');
        child.stderr.on('data', (chunk) => {
            this.options.log?.(`[localcore-acp:${input.threadId}] ${chunk.trimEnd()}`);
        });
        child.stdin.on('error', (error) => {
            this.handlePipeFailure(session, error);
        });
        child.on('exit', (code, signal) => {
            this.options.onSessionClosed(session, new Error(`ACP agent exited with code ${code ?? 'unknown'}${signal ? ` (${signal})` : ''}`));
        });
        return session;
    }
    async initializeSession(session) {
        const initResult = await this.request(session, 'initialize', {
            protocolVersion: 1,
            clientCapabilities: {
                fs: {
                    readTextFile: false,
                    writeTextFile: false,
                },
                terminal: false,
            },
            clientInfo: {
                name: 'agentdock',
                title: 'AgentDock',
                version: '0.1.0',
            },
        }, 30000);
        session.supportsLoad = Boolean(initResult?.agentCapabilities?.loadSession);
    }
    request(session, method, params, timeoutMs = 30000) {
        session.requestId += 1;
        const id = session.requestId;
        return new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
                session.pending.delete(id);
                reject(new Error(`Timed out waiting for ACP ${method} after ${timeoutMs}ms`));
            }, timeoutMs);
            session.pending.set(id, {
                resolve: (value) => {
                    clearTimeout(timeout);
                    resolve(value);
                },
                reject: (error) => {
                    clearTimeout(timeout);
                    reject(error);
                },
            });
            if (!this.sendRaw(session, {
                jsonrpc: '2.0',
                id,
                method,
                params,
            })) {
                session.pending.delete(id);
                reject(new Error(session.closeReason || 'ACP session is not writable'));
            }
        });
    }
    sendRaw(session, payload) {
        if (session.closed || !session.child.stdin.writable) {
            return false;
        }
        try {
            session.child.stdin.write(`${JSON.stringify(payload)}\n`, (error) => {
                if (error) {
                    this.handlePipeFailure(session, error);
                }
            });
            return true;
        }
        catch (error) {
            this.handlePipeFailure(session, error);
            return false;
        }
    }
    closeSession(session, reason = 'ACP session closed') {
        if (session.closed) {
            return;
        }
        session.closed = true;
        session.closeReason = reason;
        if (!session.child.killed) {
            session.child.kill('SIGTERM');
        }
    }
    closeSessionWithError(session, error) {
        if (session.closed) {
            return;
        }
        session.closed = true;
        session.closeReason = error.message;
        for (const pending of session.pending.values()) {
            pending.reject(error);
        }
        session.pending.clear();
        if (!session.child.killed) {
            session.child.kill('SIGTERM');
        }
    }
    handleStdout(session, chunk) {
        session.stdoutBuffer += chunk;
        while (session.stdoutBuffer.includes('\n')) {
            const newlineIndex = session.stdoutBuffer.indexOf('\n');
            const line = session.stdoutBuffer.slice(0, newlineIndex).trim();
            session.stdoutBuffer = session.stdoutBuffer.slice(newlineIndex + 1);
            if (!line) {
                continue;
            }
            let payload;
            try {
                payload = JSON.parse(line);
            }
            catch (error) {
                this.options.log?.(`ACP stdout parse failed: ${error instanceof Error ? error.message : String(error)}`);
                continue;
            }
            if (payload.method && payload.id !== undefined) {
                this.options.onAgentRequest(session, payload);
                continue;
            }
            if (payload.method) {
                this.options.onAgentNotification(session, payload);
                continue;
            }
            if (payload.id !== undefined) {
                const pending = session.pending.get(payload.id);
                if (!pending) {
                    continue;
                }
                session.pending.delete(payload.id);
                if (payload.error) {
                    pending.reject(new Error(payload.error.message || `ACP request failed: ${payload.id}`));
                }
                else {
                    pending.resolve(payload.result);
                }
            }
        }
    }
    handlePipeFailure(session, error) {
        const message = error instanceof Error ? error.message : String(error);
        this.options.log?.(`[localcore-acp:${session.threadId}] stdin failure: ${message}`);
        this.options.onSessionClosed(session, new Error(message));
    }
}
exports.LocalCoreAcpTransport = LocalCoreAcpTransport;
