"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SchedulerRunLifecycle = void 0;
class SchedulerRunLifecycle {
    options;
    constructor(options) {
        this.options = options;
    }
    markSkipped(job, triggeredAt, error) {
        const skipped = this.options.store.createScheduledJobRun(job.id, 'skipped', {
            triggeredAt,
            error,
        });
        this.options.emitRun(skipped);
        this.emitCurrentJob(job.id);
        return skipped;
    }
    markQueued(job, triggeredAt) {
        const run = this.options.store.createScheduledJobRun(job.id, 'queued', { triggeredAt });
        this.options.emitRun(run);
        return run;
    }
    markRunning(runId) {
        const started = this.options.store.updateScheduledJobRun(runId, {
            status: 'running',
            startedAt: new Date().toISOString(),
        });
        this.options.emitRun(started);
        return started;
    }
    markSucceeded(job, runId, result, disableOnceJob) {
        const completed = this.options.store.updateScheduledJobRun(runId, {
            status: 'succeeded',
            finishedAt: new Date().toISOString(),
            threadId: result.threadId,
            runId: result.runId,
            platformMessageId: result.platformMessageId,
            error: '',
        });
        if (disableOnceJob) {
            this.options.store.updateScheduledJobStatus(job.id, { enabled: false });
        }
        this.options.emitRun(completed);
        this.emitCurrentJob(job.id);
        return completed;
    }
    markFailed(jobId, runId, error) {
        const failed = this.options.store.updateScheduledJobRun(runId, {
            status: 'failed',
            finishedAt: new Date().toISOString(),
            error,
        });
        this.options.emitRun(failed);
        this.emitCurrentJob(jobId);
        return failed;
    }
    emitCurrentJob(jobId) {
        const job = this.options.store.getScheduledJob(jobId);
        if (job) {
            this.options.emitJob(job);
        }
    }
}
exports.SchedulerRunLifecycle = SchedulerRunLifecycle;
