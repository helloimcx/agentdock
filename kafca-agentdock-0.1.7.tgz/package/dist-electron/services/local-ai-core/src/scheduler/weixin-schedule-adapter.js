"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WeixinScheduleAdapter = void 0;
const scheduled_conversation_executor_js_1 = require("./scheduled-conversation-executor.js");
const weixin_execution_policies_js_1 = require("./weixin-execution-policies.js");
class WeixinScheduleAdapter {
    options;
    executor;
    deliveryTargets = ['weixin'];
    constructor(options) {
        this.options = options;
        this.executor = new scheduled_conversation_executor_js_1.ScheduledConversationExecutor({
            store: options.store,
            workspaceRouter: options.getWorkspaceRouter(),
        });
    }
    supports(job) {
        return job.platform === 'weixin' && (job.route.type === 'channel.chat' || job.route.type === 'weixin_chat');
    }
    async execute(context) {
        const { job } = context;
        const executionPolicy = (0, weixin_execution_policies_js_1.createWeixinExecutionPolicy)(job, {
            store: this.options.store,
            workspaceRouter: this.options.getWorkspaceRouter(),
            getChannelRuntime: this.options.getChannelRuntime,
        }, (nextJob) => this.resolveThread(nextJob));
        const execution = await this.executor.execute(job, job.promptTemplate, executionPolicy);
        let platformMessageId = '';
        if (execution.replyText) {
            const channelRuntime = this.options.getChannelRuntime();
            if (!channelRuntime.sendScheduledMessage) {
                throw new Error('WeChat channel runtime does not support scheduled delivery.');
            }
            platformMessageId = await channelRuntime.sendScheduledMessage(job.workspaceId, job.route, execution.replyText);
            if (!platformMessageId) {
                throw new Error('WeChat gateway did not return a message id for scheduled delivery.');
            }
        }
        return {
            threadId: execution.threadId,
            runId: execution.runId,
            replyText: execution.replyText,
            platformMessageId: platformMessageId || undefined,
        };
    }
    async resolveThread(job) {
        const workspaceRouter = this.options.getWorkspaceRouter();
        const route = job.route;
        if (route.threadId) {
            await workspaceRouter.getThread(route.threadId);
            return route.threadId;
        }
        const channelId = route.channelId;
        const participantId = route.participantId || '';
        const binding = this.options.store.getPlatformThreadBinding(job.workspaceId, channelId, participantId, 'weixin');
        if (binding?.thread_id) {
            return binding.thread_id;
        }
        const thread = await workspaceRouter.createThread(job.workspaceId, job.description || `Scheduled ${job.platform} task`);
        const now = new Date().toISOString();
        this.options.store.upsertPlatformThreadBinding({
            workspace_id: job.workspaceId,
            platform: 'weixin',
            chat_id: channelId,
            platform_user_id: participantId,
            thread_id: thread.id,
            last_platform_message_id: null,
            created_at: now,
            updated_at: now,
        });
        const authorized = this.options.store.getAuthorizedUser(job.workspaceId, participantId, 'weixin');
        if (authorized) {
            this.options.store.updateAuthorizedUserThread(job.workspaceId, participantId, thread.id, 'weixin');
        }
        return thread.id;
    }
}
exports.WeixinScheduleAdapter = WeixinScheduleAdapter;
