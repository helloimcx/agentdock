"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createWeixinExecutionPolicy = createWeixinExecutionPolicy;
function createWeixinExecutionPolicy(job, options, resolveSameThread) {
    if (job.executionMode === 'side-thread') {
        return new WeixinSideThreadExecutionPolicy(options);
    }
    return new WeixinSameThreadExecutionPolicy(options, resolveSameThread);
}
class WeixinSameThreadExecutionPolicy {
    options;
    resolveSameThread;
    constructor(options, resolveSameThread) {
        this.options = options;
        this.resolveSameThread = resolveSameThread;
    }
    async resolveTarget(job) {
        return {
            kind: 'thread',
            threadId: await this.resolveSameThread(job),
            workspaceId: job.workspaceId,
            platform: job.platform,
            route: job.route,
        };
    }
    beforeExecute(target) {
        this.options.getChannelRuntime().muteThreadBridge?.(target.threadId);
    }
    afterExecute(target) {
        this.options.getChannelRuntime().unmuteThreadBridge?.(target.threadId);
    }
}
class WeixinSideThreadExecutionPolicy {
    options;
    constructor(options) {
        this.options = options;
    }
    async resolveTarget(job) {
        const title = `[Scheduled] ${job.description || job.id}`;
        const existing = (await this.options.workspaceRouter.listThreads(job.workspaceId))
            .find((thread) => thread.title === title);
        if (existing) {
            return {
                kind: 'thread',
                threadId: existing.id,
                workspaceId: job.workspaceId,
                platform: job.platform,
                route: job.route,
            };
        }
        const created = await this.options.workspaceRouter.createThread(job.workspaceId, title);
        return {
            kind: 'thread',
            threadId: created.id,
            workspaceId: job.workspaceId,
            platform: job.platform,
            route: job.route,
        };
    }
    beforeExecute(target) {
        this.options.getChannelRuntime().muteThreadBridge?.(target.threadId);
    }
    afterExecute(target) {
        this.options.getChannelRuntime().unmuteThreadBridge?.(target.threadId);
    }
}
