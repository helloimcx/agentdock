"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SchedulerService = void 0;
const node_events_1 = require("node:events");
const scheduler_run_lifecycle_js_1 = require("./scheduler-run-lifecycle.js");
class SchedulerService extends node_events_1.EventEmitter {
    options;
    timer = null;
    pollInFlight = false;
    runningJobs = new Set();
    runLifecycle;
    constructor(options) {
        super();
        this.options = options;
        this.runLifecycle = new scheduler_run_lifecycle_js_1.SchedulerRunLifecycle({
            store: options.store,
            emitRun: (run) => this.emit('run', run),
            emitJob: (job) => this.emit('job', job),
        });
    }
    async start() {
        await this.tick();
        this.timer = setInterval(() => {
            void this.tick();
        }, 1000);
    }
    async stop() {
        if (this.timer) {
            clearInterval(this.timer);
            this.timer = null;
        }
    }
    listJobs(workspaceId) {
        return this.options.store.listScheduledJobs(workspaceId);
    }
    getJob(jobId) {
        return this.options.store.getScheduledJob(jobId);
    }
    createJob(input) {
        const job = this.options.store.createScheduledJob(input);
        this.emit('job', job);
        this.options.eventBus.emit({ type: 'scheduler.job.updated', payload: job });
        return job;
    }
    updateJob(jobId, input) {
        const job = this.options.store.updateScheduledJob(jobId, input);
        this.emit('job', job);
        this.options.eventBus.emit({ type: 'scheduler.job.updated', payload: job });
        return job;
    }
    deleteJob(jobId) {
        return this.options.store.deleteScheduledJob(jobId);
    }
    listJobRuns(jobId) {
        return this.options.store.listScheduledJobRuns(jobId);
    }
    async runJobNow(jobId) {
        const job = this.options.store.getScheduledJob(jobId);
        if (!job) {
            throw new Error(`Scheduled job not found: ${jobId}`);
        }
        return this.executeJob(job, new Date().toISOString(), true);
    }
    async tick() {
        if (this.pollInFlight) {
            return;
        }
        this.pollInFlight = true;
        try {
            const now = new Date();
            const jobs = this.options.store.listScheduledJobs().filter((job) => job.enabled);
            for (const job of jobs) {
                if (!this.isDue(job, now)) {
                    continue;
                }
                await this.executeJob(job, now.toISOString(), false);
            }
        }
        finally {
            this.pollInFlight = false;
        }
    }
    isDue(job, now) {
        const trigger = this.options.triggers.find((candidate) => candidate.supports(job));
        if (!trigger) {
            return false;
        }
        return trigger.isDue(job, now);
    }
    async executeJob(job, triggeredAt, manual) {
        if (this.runningJobs.has(job.id)) {
            const skipped = this.runLifecycle.markSkipped(job, triggeredAt, 'Skipped because the previous run is still active.');
            this.options.eventBus.emit({ type: 'scheduler.run.updated', payload: skipped });
            return skipped;
        }
        this.runningJobs.add(job.id);
        const run = this.runLifecycle.markQueued(job, triggeredAt);
        this.options.eventBus.emit({ type: 'scheduler.run.updated', payload: run });
        try {
            const executor = this.options.executors.find((candidate) => candidate.supports(job));
            if (!executor) {
                throw new Error(`No scheduler executor is available for delivery target "${job.platform}"`);
            }
            this.runLifecycle.markRunning(run.id);
            const running = this.options.store.getScheduledJobRun(run.id);
            if (running) {
                this.options.eventBus.emit({ type: 'scheduler.run.updated', payload: running });
            }
            const result = await executor.execute({ job, triggeredAt });
            const succeeded = this.runLifecycle.markSucceeded(job, run.id, result, !manual && job.triggerType === 'once');
            this.options.eventBus.emit({ type: 'scheduler.run.updated', payload: succeeded });
            const nextJob = this.options.store.getScheduledJob(job.id);
            if (nextJob) {
                this.options.eventBus.emit({ type: 'scheduler.job.updated', payload: nextJob });
            }
            return succeeded;
        }
        catch (error) {
            const failed = this.runLifecycle.markFailed(job.id, run.id, error instanceof Error ? error.message : String(error));
            this.options.eventBus.emit({ type: 'scheduler.run.updated', payload: failed });
            const nextJob = this.options.store.getScheduledJob(job.id);
            if (nextJob) {
                this.options.eventBus.emit({ type: 'scheduler.job.updated', payload: nextJob });
            }
            this.options.log?.(`scheduler job failed ${job.id}: ${failed.error || 'unknown error'}`);
            return failed;
        }
        finally {
            this.runningJobs.delete(job.id);
        }
    }
}
exports.SchedulerService = SchedulerService;
