"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizePlatformTypes = normalizePlatformTypes;
exports.isLocalCoreNativeAcpProject = isLocalCoreNativeAcpProject;
exports.toLocalCoreProjectConfig = toLocalCoreProjectConfig;
const node_module_1 = require("node:module");
const node_path_1 = require("node:path");
const desktop_js_1 = require("../../../../shared/desktop.js");
function normalizePlatformTypes(project) {
    return Array.isArray(project?.platforms)
        ? project.platforms.map((platform) => (0, desktop_js_1.normalizeDesktopPlatformType)(platform?.type)).filter(Boolean)
        : [];
}
function isLocalCoreNativeAcpProject(project) {
    const agentType = String(project?.agent?.type || '').trim().toLowerCase();
    return !agentType
        || agentType === 'acp'
        || agentType === desktop_js_1.LOCALCORE_ACP_AGENT_TYPE;
}
function resolveOpencodeModel(project, providers) {
    const agentType = String(project.agent?.type || '').trim().toLowerCase();
    const rawModel = String(project.agent?.options?.model || '').trim();
    const normalizedModel = (0, desktop_js_1.normalizeDesktopAgentModel)(agentType, rawModel);
    if (agentType !== 'opencode') {
        return normalizedModel;
    }
    const configuredProviderModel = getFirstProviderModelRef(providers);
    if (configuredProviderModel &&
        (!rawModel || normalizedModel === desktop_js_1.DEFAULT_DESKTOP_OPENCODE_MODEL)) {
        return configuredProviderModel;
    }
    return normalizedModel;
}
function getFirstProviderModelRef(providers) {
    for (const provider of providers) {
        const providerId = normalizeOpencodeProviderId(provider.name);
        const modelId = getProviderDefaultModelId(provider);
        if (providerId && modelId) {
            return `${providerId}/${modelId}`;
        }
    }
    return '';
}
function getProviderDefaultModelId(provider) {
    const directModel = String(provider.model || '').trim();
    if (directModel) {
        return directModel;
    }
    const firstModel = Array.isArray(provider.models)
        ? provider.models.find((entry) => String(entry?.model || '').trim())
        : null;
    return String(firstModel?.model || '').trim();
}
function buildOpencodeInlineConfig(model, providers) {
    const config = {
        $schema: 'https://opencode.ai/config.json',
    };
    const env = {};
    if (model) {
        config.model = model;
    }
    const providerConfig = {};
    for (const provider of providers) {
        const providerId = normalizeOpencodeProviderId(provider.name);
        if (!providerId) {
            continue;
        }
        const entry = {
            name: String(provider.name || providerId),
        };
        if (shouldUseOpenAiCompatibleProvider(providerId)) {
            entry.npm = '@ai-sdk/openai-compatible';
        }
        const options = {};
        const baseUrl = String(provider.base_url || '').trim();
        if (baseUrl) {
            options.baseURL = baseUrl;
        }
        const apiKey = String(provider.api_key || '').trim();
        if (apiKey) {
            const envName = opencodeProviderApiKeyEnvName(providerId);
            env[envName] = apiKey;
            options.apiKey = `{env:${envName}}`;
        }
        if (Object.keys(options).length > 0) {
            entry.options = options;
        }
        const models = buildOpencodeProviderModels(provider);
        if (Object.keys(models).length > 0) {
            entry.models = models;
        }
        providerConfig[providerId] = entry;
    }
    if (Object.keys(providerConfig).length > 0) {
        config.provider = providerConfig;
    }
    return {
        config,
        env,
    };
}
function buildOpencodeProviderModels(provider) {
    const models = {};
    const addModel = (model, alias) => {
        const modelId = String(model || '').trim();
        if (!modelId || models[modelId]) {
            return;
        }
        models[modelId] = {
            name: String(alias || modelId).trim() || modelId,
        };
    };
    addModel(provider.model);
    for (const model of Array.isArray(provider.models) ? provider.models : []) {
        addModel(model?.model, model?.alias);
    }
    return models;
}
function collectProviderEnv(providers) {
    const env = {};
    for (const provider of providers) {
        if (!provider.env || typeof provider.env !== 'object') {
            continue;
        }
        for (const [key, value] of Object.entries(provider.env)) {
            const envKey = key.trim();
            if (envKey) {
                env[envKey] = String(value ?? '');
            }
        }
    }
    return env;
}
function normalizeOpencodeProviderId(value) {
    return String(value || '')
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9._-]+/g, '-')
        .replace(/^-+|-+$/g, '');
}
function opencodeProviderApiKeyEnvName(providerId) {
    const suffix = providerId.toUpperCase().replace(/[^A-Z0-9]+/g, '_').replace(/^_+|_+$/g, '');
    return `AI_WORKSTATION_OPENCODE_${suffix || 'PROVIDER'}_API_KEY`;
}
function shouldUseOpenAiCompatibleProvider(providerId) {
    const builtInNonCompatibleProviders = new Set([
        'anthropic',
        'google',
        'gemini',
    ]);
    return !builtInNonCompatibleProviders.has(providerId);
}
function resolveBundledClaudeCodeCommand() {
    const require = (0, node_module_1.createRequire)(__filename);
    const packageJsonPath = require.resolve(`${desktop_js_1.DESKTOP_CLAUDECODE_ACP_PACKAGE}/package.json`);
    const packageJson = require(packageJsonPath);
    const binField = packageJson.bin;
    const relativeBinPath = typeof binField === 'string'
        ? binField
        : binField?.['claude-agent-acp'];
    if (!relativeBinPath) {
        throw new Error(`Bundled package "${desktop_js_1.DESKTOP_CLAUDECODE_ACP_PACKAGE}" does not declare the claude-agent-acp bin.`);
    }
    return {
        command: process.execPath,
        args: [(0, node_path_1.resolve)((0, node_path_1.dirname)(packageJsonPath), relativeBinPath)],
    };
}
function toLocalCoreProjectConfig(configState, project) {
    const rawWorkDir = String(project.agent?.options?.work_dir || '.').trim() || '.';
    const configDir = (0, node_path_1.dirname)(configState.path);
    const workDir = (0, node_path_1.isAbsolute)(rawWorkDir) ? rawWorkDir : (0, node_path_1.resolve)(configDir, rawWorkDir);
    const rawArgs = project.agent?.options?.args;
    const args = Array.isArray(rawArgs)
        ? rawArgs.map((value) => String(value || '')).filter(Boolean)
        : [];
    const rawEnv = project.agent?.options?.env;
    const env = rawEnv && typeof rawEnv === 'object'
        ? Object.fromEntries(Object.entries(rawEnv)
            .filter(([key]) => key)
            .map(([key, value]) => [key, String(value ?? '')]))
        : {};
    const agentType = String(project.agent?.type || '').trim().toLowerCase();
    const providers = Array.isArray(project.agent?.providers) ? project.agent.providers : [];
    const model = resolveOpencodeModel(project, providers);
    const providerEnv = collectProviderEnv(providers);
    const opencodeInlineConfig = agentType === 'opencode'
        ? buildOpencodeInlineConfig(model, providers)
        : null;
    const inferredOpencodeEnv = agentType === 'opencode'
        ? {
            ...(opencodeInlineConfig?.env || {}),
            OPENCODE_CONFIG_CONTENT: JSON.stringify(opencodeInlineConfig?.config || { $schema: 'https://opencode.ai/config.json' }),
        }
        : {};
    const inferredClaudeCodeEnv = agentType === 'claudecode' && model
        ? {
            ANTHROPIC_MODEL: model,
        }
        : {};
    const bundledClaudeCode = agentType === 'claudecode'
        ? resolveBundledClaudeCodeCommand()
        : null;
    const inferredCommand = agentType === 'opencode'
        ? 'opencode'
        : bundledClaudeCode?.command || '';
    const command = String(project.agent?.options?.command || inferredCommand).trim();
    if (!command) {
        throw new Error(`Workspace "${project.name}" requires [projects.agent.options].command for Local AI Core ACP execution.`);
    }
    const defaultArgs = agentType === 'opencode'
        ? ['acp']
        : agentType === 'claudecode'
            ? [...(bundledClaudeCode?.args || [])]
            : [];
    return {
        workspaceId: project.name,
        agentType,
        workDir,
        command,
        args: args.length > 0 ? args : defaultArgs,
        env: {
            ...providerEnv,
            ...inferredOpencodeEnv,
            ...inferredClaudeCodeEnv,
            ...env,
        },
        model,
    };
}
