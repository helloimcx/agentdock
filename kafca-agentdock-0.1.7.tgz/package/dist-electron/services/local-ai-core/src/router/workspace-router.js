"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WorkspaceRouter = exports.encodeThreadId = exports.decodeThreadId = void 0;
exports.createWorkspaceRouter = createWorkspaceRouter;
const local_core_acp_backend_js_1 = require("../acp/local-core-acp-backend.js");
const workspace_thread_id_js_1 = require("../thread/workspace-thread-id.js");
const workspace_route_config_js_1 = require("./workspace-route-config.js");
var workspace_thread_id_js_2 = require("../thread/workspace-thread-id.js");
Object.defineProperty(exports, "decodeThreadId", { enumerable: true, get: function () { return workspace_thread_id_js_2.decodeThreadId; } });
Object.defineProperty(exports, "encodeThreadId", { enumerable: true, get: function () { return workspace_thread_id_js_2.encodeThreadId; } });
class WorkspaceRouter {
    options;
    store;
    localCoreAcp;
    runThreadMap = new Map();
    bridgeSubscribers = new Set();
    schedulerBridge = null;
    constructor(options) {
        this.options = options;
        this.store = options.store;
        this.localCoreAcp = new local_core_acp_backend_js_1.LocalCoreAcpBackend({
            store: this.store,
            runThreadMap: this.runThreadMap,
            cliBinDir: options.cliBinDir,
            localCoreBase: options.localCoreBase,
            emitBridge: (event) => this.emitBridgeEvent(event),
            eventBus: options.eventBus,
            scheduler: {
                createJob: async (input) => {
                    if (!this.schedulerBridge) {
                        throw new Error('Scheduler bridge is unavailable.');
                    }
                    return this.schedulerBridge.createJob(input);
                },
                listJobsForThread: async (threadId) => {
                    if (!this.schedulerBridge) {
                        throw new Error('Scheduler bridge is unavailable.');
                    }
                    return this.schedulerBridge.listJobsForThread(threadId);
                },
                deleteJob: async (jobId) => {
                    if (!this.schedulerBridge) {
                        throw new Error('Scheduler bridge is unavailable.');
                    }
                    return this.schedulerBridge.deleteJob(jobId);
                },
            },
            log: options.log,
        });
    }
    close() {
        this.localCoreAcp.close();
        this.bridgeSubscribers.clear();
        this.store.close();
    }
    getThreadSessionKey(threadId) {
        const row = this.store.getThreadRow(threadId);
        return row?.bridge_session_key || '';
    }
    setSchedulerBridge(bridge) {
        this.schedulerBridge = bridge;
    }
    async listWorkspaces() {
        const localProjects = await this.listLocalCoreProjects();
        const workspaceMap = new Map();
        for (const project of localProjects) {
            const route = this.resolveProjectRoute(await this.options.readConfigState(), project);
            if (!route) {
                continue;
            }
            workspaceMap.set(project.name, {
                id: project.name,
                name: project.name,
                agentType: route.agentType,
                platforms: (0, workspace_route_config_js_1.normalizePlatformTypes)(project),
                sessionsCount: this.store.countThreads(project.name),
                heartbeatEnabled: false,
            });
        }
        return [...workspaceMap.values()].sort((a, b) => a.name.localeCompare(b.name));
    }
    async listThreads(workspaceId) {
        await this.getWorkspaceRoute(workspaceId);
        return this.localCoreAcp.listThreads(workspaceId);
    }
    async createThread(workspaceId, title) {
        const route = await this.getWorkspaceRoute(workspaceId);
        return this.withKnowledge(await this.localCoreAcp.createThread(workspaceId, title || `New thread ${new Date().toLocaleTimeString()}`, route.agentType));
    }
    async getThread(threadId) {
        const { workspaceId } = (0, workspace_thread_id_js_1.decodeThreadId)(threadId);
        await this.getWorkspaceRoute(workspaceId);
        return this.withKnowledge(await this.localCoreAcp.getThread(threadId));
    }
    async renameThread(threadId, title) {
        const { workspaceId } = (0, workspace_thread_id_js_1.decodeThreadId)(threadId);
        await this.getWorkspaceRoute(workspaceId);
        return this.withKnowledge(await this.localCoreAcp.renameThread(threadId, title));
    }
    async updateThreadKnowledgeBases(threadId, knowledgeBaseIds) {
        return {
            knowledgeBaseIds: await this.options.knowledgeAttachments.updateThreadKnowledgeBaseIds(threadId, knowledgeBaseIds),
        };
    }
    async deleteThread(threadId) {
        const { workspaceId } = (0, workspace_thread_id_js_1.decodeThreadId)(threadId);
        await this.getWorkspaceRoute(workspaceId);
        await this.localCoreAcp.deleteThread(threadId);
        await this.options.knowledgeAttachments.deleteThreadKnowledgeBaseLinks(threadId);
        return { deleted: true };
    }
    async sendThreadMessage(threadId, content) {
        const { workspaceId } = (0, workspace_thread_id_js_1.decodeThreadId)(threadId);
        const route = await this.getWorkspaceRoute(workspaceId);
        return this.localCoreAcp.sendThreadMessage(threadId, content, route.config);
    }
    async sendThreadAction(threadId, content) {
        const { workspaceId } = (0, workspace_thread_id_js_1.decodeThreadId)(threadId);
        const route = await this.getWorkspaceRoute(workspaceId);
        return this.localCoreAcp.sendThreadAction(threadId, content, route.config);
    }
    async interruptRun(runId) {
        const threadId = this.runThreadMap.get(runId);
        if (!threadId) {
            return { interrupted: false };
        }
        const { workspaceId } = (0, workspace_thread_id_js_1.decodeThreadId)(threadId);
        await this.getWorkspaceRoute(workspaceId);
        return this.localCoreAcp.interruptRun(runId);
    }
    getCapabilities() {
        return this.options.getCapabilities();
    }
    async probeWorkspaceStreaming(workspaceId) {
        const route = await this.getWorkspaceRoute(workspaceId);
        if (!route.supportsStreamingProbe) {
            throw new Error(`Workspace "${workspaceId}" does not expose a streaming probe.`);
        }
        return this.probeLocalCoreAcpWorkspace(workspaceId, route);
    }
    async withKnowledge(detail) {
        return {
            ...detail,
            selectedKnowledgeBaseIds: await this.options.knowledgeAttachments.listThreadKnowledgeBaseIds(detail.id),
        };
    }
    emitBridgeEvent(event) {
        this.options.eventBus.emit({
            type: 'platform.bridge.updated',
            payload: event,
        });
        this.notifyBridgeSubscribers(event);
    }
    notifyBridgeSubscribers(event) {
        for (const listener of this.bridgeSubscribers) {
            listener(event);
        }
    }
    subscribeBridge(listener) {
        this.bridgeSubscribers.add(listener);
        return () => {
            this.bridgeSubscribers.delete(listener);
        };
    }
    subscribeBridgeEvents(listener) {
        return this.subscribeBridge(listener);
    }
    createProbeCollector() {
        return {
            startedAt: new Date().toISOString(),
            events: [],
            sawTypingStart: false,
            sawTypingStop: false,
            sawReply: false,
            sawPreviewLike: false,
            firstPreviewAt: null,
            firstReplyAt: null,
            updateMessageCount: 0,
            cumulativeUpdates: true,
            lastPreviewContent: '',
        };
    }
    recordProbeEvent(collector, event) {
        const at = Date.now();
        const content = String(event.content || '');
        collector.events.push({
            type: event.type,
            at: new Date(at).toISOString(),
            contentLength: content.length,
            previewHandle: event.previewHandle,
        });
        switch (event.type) {
            case 'typing_start':
                collector.sawTypingStart = true;
                break;
            case 'typing_stop':
                collector.sawTypingStop = true;
                break;
            case 'preview_start':
                collector.sawPreviewLike = true;
                collector.firstPreviewAt ??= at;
                collector.lastPreviewContent = content;
                break;
            case 'update_message':
                collector.sawPreviewLike = true;
                collector.firstPreviewAt ??= at;
                collector.updateMessageCount += 1;
                if (collector.lastPreviewContent &&
                    content &&
                    !content.startsWith(collector.lastPreviewContent)) {
                    collector.cumulativeUpdates = false;
                }
                collector.lastPreviewContent = content;
                break;
            case 'reply':
                collector.sawReply = true;
                collector.firstReplyAt ??= at;
                break;
            default:
                break;
        }
    }
    finalizeProbeResult(workspaceId, agentType, transport, prompt, collector, options = {}) {
        const completedAt = new Date().toISOString();
        const durationMs = Math.max(0, Date.parse(completedAt) - Date.parse(collector.startedAt));
        const previewBeforeFinal = collector.sawPreviewLike && (collector.firstReplyAt == null ||
            (collector.firstPreviewAt != null && collector.firstPreviewAt <= collector.firstReplyAt));
        const finalEvent = options.error
            ? 'error'
            : options.timedOut
                ? 'timeout'
                : collector.sawReply
                    ? 'reply'
                    : collector.sawTypingStop
                        ? 'typing_stop'
                        : 'none';
        const hungPreview = collector.sawPreviewLike && !collector.sawTypingStop;
        const passed = Boolean(collector.sawTypingStart &&
            collector.sawTypingStop &&
            previewBeforeFinal &&
            collector.updateMessageCount >= 2 &&
            collector.cumulativeUpdates &&
            !hungPreview &&
            !options.error &&
            !options.timedOut);
        return {
            workspaceId,
            agentType,
            transport,
            prompt,
            passed,
            startedAt: collector.startedAt,
            completedAt,
            durationMs,
            threadId: options.threadId,
            sessionKey: options.sessionKey,
            error: options.error,
            criteria: {
                sawTypingStart: collector.sawTypingStart,
                sawTypingStop: collector.sawTypingStop,
                previewBeforeFinal,
                updateMessageCount: collector.updateMessageCount,
                cumulativeUpdates: collector.cumulativeUpdates,
                finalEvent,
                hungPreview,
            },
            events: collector.events,
        };
    }
    waitForProbeSequence(sessionKey, timeoutMs, collector) {
        let active = true;
        let unsubscribe = () => { };
        const promise = new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
                active = false;
                unsubscribe();
                reject(new Error(`Timed out waiting for ACP streaming events after ${timeoutMs}ms`));
            }, timeoutMs);
            unsubscribe = this.subscribeBridge((event) => {
                if (!active) {
                    return;
                }
                if (event.sessionKey !== sessionKey) {
                    return;
                }
                this.recordProbeEvent(collector, event);
                if (event.type === 'typing_stop') {
                    active = false;
                    clearTimeout(timeout);
                    unsubscribe();
                    resolve();
                }
            });
        });
        return {
            promise,
            cancel: () => {
                if (!active) {
                    return;
                }
                active = false;
                unsubscribe();
            },
        };
    }
    buildProbePrompt() {
        return 'Reply with exactly three short plain-text lines: alpha, beta, gamma. Do not call tools or ask questions.';
    }
    async probeLocalCoreAcpWorkspace(workspaceId, route) {
        const prompt = this.buildProbePrompt();
        const thread = await this.localCoreAcp.createThread(workspaceId, `[probe] ${new Date().toISOString()}`, route.agentType);
        const collector = this.createProbeCollector();
        const sequence = this.waitForProbeSequence(thread.bridgeSessionKey || '', 20000, collector);
        try {
            const sent = await this.localCoreAcp.sendThreadMessage(thread.id, prompt, route.config);
            await sequence.promise;
            await this.localCoreAcp.interruptRun(sent.runId).catch(() => ({ interrupted: false }));
            return this.finalizeProbeResult(workspaceId, route.agentType, 'localcore-acp', prompt, collector, {
                threadId: thread.id,
                sessionKey: thread.bridgeSessionKey,
            });
        }
        catch (error) {
            sequence.cancel();
            return this.finalizeProbeResult(workspaceId, route.agentType, 'localcore-acp', prompt, collector, {
                threadId: thread.id,
                sessionKey: thread.bridgeSessionKey,
                error: error instanceof Error ? error.message : String(error),
                timedOut: error instanceof Error && error.message.includes('Timed out'),
            });
        }
        finally {
            await this.localCoreAcp.deleteThread(thread.id).catch(() => ({ deleted: false }));
        }
    }
    async getWorkspaceRoute(workspaceId) {
        const configState = await this.options.readConfigState();
        const projects = Array.isArray(configState.parsed?.projects) ? configState.parsed.projects : [];
        const matched = projects.find((project) => String(project?.name || '').trim() === workspaceId);
        const route = matched ? this.resolveProjectRoute(configState, matched) : null;
        if (!matched || !route) {
            throw new Error(`Workspace "${workspaceId}" is not configured as a Local AI Core ACP workspace.`);
        }
        return route;
    }
    async listLocalCoreProjects() {
        const configState = await this.options.readConfigState();
        const projects = Array.isArray(configState.parsed?.projects) ? configState.parsed.projects : [];
        return projects.filter((project) => this.resolveProjectRoute(configState, project));
    }
    resolveProjectRoute(configState, project) {
        for (const runtime of this.options.getAgentRuntimes?.() || []) {
            if (!runtime.matchesProject(project)) {
                continue;
            }
            const route = runtime.createRoute(configState, project);
            if (route) {
                return {
                    ...route,
                    runtime,
                };
            }
        }
        if ((0, workspace_route_config_js_1.isLocalCoreNativeAcpProject)(project)) {
            const agentType = String(project.agent?.type || '').trim().toLowerCase() || 'localcore-acp';
            return {
                kind: 'localcore-acp',
                agentType,
                transport: 'localcore-acp',
                config: {
                    ...(0, workspace_route_config_js_1.toLocalCoreProjectConfig)(configState, project),
                    agentType,
                },
                supportsStreamingProbe: true,
                runtime: {
                    agentType,
                    transport: 'localcore-acp',
                    matchesProject: () => true,
                    createRoute: () => null,
                },
            };
        }
        return null;
    }
}
exports.WorkspaceRouter = WorkspaceRouter;
function createWorkspaceRouter(options) {
    return new WorkspaceRouter(options);
}
