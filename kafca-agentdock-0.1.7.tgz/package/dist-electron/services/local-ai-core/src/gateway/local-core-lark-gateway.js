"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalCoreLarkGateway = void 0;
const node_events_1 = require("node:events");
const node_crypto_1 = require("node:crypto");
const desktop_js_1 = require("../../../../shared/desktop.js");
const PAIRING_EXPIRY_MS = 10 * 60 * 1000;
class LocalCoreLarkGateway extends node_events_1.EventEmitter {
    options;
    // Lark card action callbacks are unreliable in current WS-only setup (code 200340).
    // Keep permission approval on explicit text commands: allow all / allow / deny.
    enableCardActions = false;
    // Keep permission state in a dedicated card to avoid mixing order in the main reply card.
    mirrorPermissionStateInMainCard = false;
    runtime = new Map();
    threadRouting = new Map();
    outboundEventChains = new Map();
    outboundTurns = new Map();
    mutedThreadBridgeCounts = new Map();
    larkModulePromise = null;
    platform = 'lark';
    routeType = 'channel.chat';
    constructor(options) {
        super();
        this.options = options;
    }
    async refreshBindings() {
        const config = await this.options.readConfig();
        const bindings = this.collectBindings(config);
        const nextWorkspaceIds = new Set(bindings.map((binding) => binding.workspaceId));
        for (const workspaceId of [...this.runtime.keys()]) {
            if (!nextWorkspaceIds.has(workspaceId)) {
                await this.stopWorkspace(workspaceId);
            }
        }
        for (const binding of bindings) {
            const current = this.runtime.get(binding.workspaceId);
            if (!binding.enabled) {
                if (current) {
                    await this.stopWorkspace(binding.workspaceId);
                }
                else {
                    this.runtime.set(binding.workspaceId, {
                        workspaceId: binding.workspaceId,
                        enabled: false,
                        status: 'disabled',
                        connected: false,
                        appId: binding.appId,
                    });
                }
                continue;
            }
            if (current?.status === 'running' && current.appId === binding.appId) {
                continue;
            }
            await this.startWorkspace(binding);
        }
        this.notifyRuntimeStateChanged();
    }
    async testConnection(workspaceId) {
        const binding = await this.getBinding(workspaceId);
        const result = await this.createSdkClientResult(binding);
        return {
            ...result,
            platform: 'lark',
            workspaceId,
        };
    }
    async enable(workspaceId) {
        const binding = await this.getBinding(workspaceId);
        await this.startWorkspace(binding);
        return this.getStatus(workspaceId);
    }
    async disable(workspaceId) {
        await this.stopWorkspace(workspaceId);
        return this.getStatus(workspaceId);
    }
    async sendScheduledCard(workspaceId, chatId, text) {
        return this.sendImmediateCard(workspaceId, chatId, text);
    }
    async sendScheduledMessage(workspaceId, route, text) {
        return this.sendScheduledCard(workspaceId, route.channelId, text);
    }
    muteThreadBridge(threadId) {
        const current = this.mutedThreadBridgeCounts.get(threadId) || 0;
        this.mutedThreadBridgeCounts.set(threadId, current + 1);
    }
    unmuteThreadBridge(threadId) {
        const current = this.mutedThreadBridgeCounts.get(threadId) || 0;
        if (current <= 1) {
            this.mutedThreadBridgeCounts.delete(threadId);
            return;
        }
        this.mutedThreadBridgeCounts.set(threadId, current - 1);
    }
    getStatus(workspaceId) {
        this.options.store.expirePendingPairings();
        const binding = this.runtime.get(workspaceId);
        const pairings = this.options.store.listPendingPairings(workspaceId)
            .filter((row) => row.platform === 'lark' && row.expires_at >= new Date().toISOString());
        const users = this.options.store.listAuthorizedUsers(workspaceId, 'lark');
        return {
            workspaceId,
            platform: 'lark',
            enabled: Boolean(binding?.enabled),
            connected: Boolean(binding?.connected),
            status: binding?.status || 'disabled',
            appId: binding?.appId || '',
            lastError: binding?.lastError,
            connectedAt: binding?.connectedAt,
            pendingPairings: pairings.length,
            authorizedUsers: users.length,
        };
    }
    listStatuses() {
        return [...this.runtime.keys()].sort().map((workspaceId) => this.getStatus(workspaceId));
    }
    listPendingPairings(workspaceId) {
        this.options.store.expirePendingPairings();
        return this.options.store
            .listPairingRequests(workspaceId, 'lark')
            .filter((item) => item.status === 'pending' && item.expiresAt >= new Date().toISOString());
    }
    listAuthorizedUsers(workspaceId) {
        return this.options.store.listAuthorizedUsers(workspaceId, 'lark');
    }
    async start() {
        await this.refreshBindings();
    }
    async stop() {
        this.close();
    }
    approvePairing(code) {
        this.options.store.expirePendingPairings();
        const pairing = this.options.store.getPairingRequest(code);
        if (!pairing) {
            throw new Error(`Pairing code not found: ${code}`);
        }
        if (pairing.platform !== 'lark') {
            throw new Error(`Pairing code ${code} is not a Lark pairing`);
        }
        if (pairing.status !== 'pending') {
            throw new Error(`Pairing code ${code} is already ${pairing.status}`);
        }
        if (pairing.expires_at < new Date().toISOString()) {
            this.options.store.updatePairingStatus(code, 'expired');
            throw new Error(`Pairing code ${code} has expired`);
        }
        const existing = this.options.store.getAuthorizedUser(pairing.workspace_id, pairing.platform_user_id);
        const userId = existing?.id || `lark-user-${(0, node_crypto_1.randomUUID)()}`;
        const authorizedAt = new Date().toISOString();
        this.options.store.createAuthorizedUser({
            id: userId,
            workspace_id: pairing.workspace_id,
            platform_user_id: pairing.platform_user_id,
            chat_id: pairing.chat_id,
            display_name: pairing.display_name,
            thread_id: existing?.thread_id || null,
            authorized_at: authorizedAt,
        });
        this.options.store.updatePairingStatus(code, 'approved');
        this.notifyRuntimeStateChanged();
        const user = this.options.store.listAuthorizedUsers(pairing.workspace_id, 'lark').find((entry) => entry.id === userId);
        if (!user) {
            throw new Error('Authorized user lookup failed after approval');
        }
        return user;
    }
    rejectPairing(code) {
        const pairing = this.options.store.getPairingRequest(code);
        if (!pairing) {
            throw new Error(`Pairing code not found: ${code}`);
        }
        this.options.store.updatePairingStatus(code, 'rejected');
        this.notifyRuntimeStateChanged();
        return { rejected: true };
    }
    async onBridgeEvent(event) {
        if (!event.sessionKey) {
            this.options.log?.(`localcore-lark bridge event ignored without sessionKey: ${event.type}`);
            return;
        }
        const sessionKey = event.sessionKey;
        const route = this.threadRouting.get(sessionKey);
        if (!route) {
            this.options.log?.(`localcore-lark bridge route miss for sessionKey=${sessionKey} type=${event.type}`);
            return;
        }
        const state = this.runtime.get(route.workspaceId);
        if (!state?.client || !state.connected) {
            this.options.log?.(`localcore-lark bridge event ignored because workspace is not connected: ${route.workspaceId}`);
            return;
        }
        const initialBinding = this.options.store.getPlatformThreadBinding(route.workspaceId, route.chatId, route.platformUserId);
        if (!initialBinding) {
            this.options.log?.(`localcore-lark bridge binding miss for workspace=${route.workspaceId} chat=${route.chatId} user=${route.platformUserId}`);
            return;
        }
        if (event.type !== 'preview_start'
            && event.type !== 'update_message'
            && event.type !== 'reply'
            && event.type !== 'buttons'
            && event.type !== 'typing_start'
            && event.type !== 'typing_stop'
            && event.type !== 'status') {
            this.options.log?.(`localcore-lark bridge event ignored type=${event.type}`);
            return;
        }
        const previous = this.outboundEventChains.get(sessionKey) || Promise.resolve();
        const current = previous
            .catch(() => undefined)
            .then(async () => {
            const binding = this.options.store.getPlatformThreadBinding(route.workspaceId, route.chatId, route.platformUserId);
            if (!binding) {
                this.options.log?.(`localcore-lark bridge binding disappeared for sessionKey=${sessionKey}`);
                return;
            }
            if (this.mutedThreadBridgeCounts.has(binding.thread_id)) {
                this.options.log?.(`localcore-lark bridge muted for thread=${binding.thread_id} type=${event.type}`);
                return;
            }
            const turn = this.getOrCreateTurnState(sessionKey, binding.last_platform_message_id || undefined);
            if (event.replyCtx) {
                turn.replyCtx = event.replyCtx;
            }
            try {
                if (event.type === 'typing_start') {
                    turn.messageId = undefined;
                }
                if (event.type === 'typing_start' && (turn.permissionMessageId || turn.awaitingPermission)) {
                    if (turn.permissionMessageId) {
                        await this.patchTextCard(state, turn.permissionMessageId, '**工具确认已处理**\n\n继续生成中...', [], sessionKey, binding.thread_id);
                    }
                    turn.permissionMessageId = undefined;
                    turn.awaitingPermission = false;
                    // Start a fresh assistant message after permission approval so the
                    // final answer appears after the confirmation flow in chat order.
                    turn.messageId = undefined;
                    this.options.store.clearPlatformThreadMessageId(route.workspaceId, route.chatId, route.platformUserId);
                }
                if (event.type === 'buttons') {
                    const permissionCard = this.renderPermissionCard(turn, event);
                    if (permissionCard.text || permissionCard.buttonRows.length > 0) {
                        if (!turn.permissionMessageId) {
                            const createdId = await this.sendTextAsCard(state, route.chatId, permissionCard.text, permissionCard.buttonRows, sessionKey, binding.thread_id);
                            if (createdId) {
                                turn.permissionMessageId = createdId;
                                this.options.log?.(`localcore-lark sent permission card ${createdId} for sessionKey=${sessionKey}`);
                            }
                        }
                        else {
                            await this.patchTextCard(state, turn.permissionMessageId, permissionCard.text, permissionCard.buttonRows, sessionKey, binding.thread_id);
                            this.options.log?.(`localcore-lark patched permission card ${turn.permissionMessageId} for sessionKey=${sessionKey}`);
                        }
                    }
                    this.consumeBridgeEvent(turn, event);
                    return;
                }
                this.consumeBridgeEvent(turn, event);
                const rendered = this.renderTurnCard(turn);
                if (!rendered.text && rendered.buttonRows.length === 0) {
                    this.options.log?.(`localcore-lark bridge event produced empty render for sessionKey=${sessionKey} type=${event.type}`);
                    return;
                }
                const shouldThrottle = event.type === 'update_message' &&
                    turn.messageId &&
                    Date.now() - turn.lastPatchedAt < 900;
                this.options.log?.(`localcore-lark bridge event type=${event.type} sessionKey=${sessionKey} hasMessageId=${Boolean(turn.messageId)} throttle=${shouldThrottle}`);
                if (shouldThrottle) {
                    return;
                }
                if (!turn.messageId) {
                    const createdId = await this.sendTextAsCard(state, route.chatId, rendered.text, rendered.buttonRows, sessionKey, binding.thread_id);
                    if (createdId) {
                        turn.messageId = createdId;
                        this.options.store.updatePlatformThreadMessageId(route.workspaceId, route.chatId, route.platformUserId, createdId);
                        this.options.log?.(`localcore-lark sent new card message ${createdId} for sessionKey=${sessionKey}`);
                    }
                    return;
                }
                await this.patchTextCard(state, turn.messageId, rendered.text, rendered.buttonRows, sessionKey, binding.thread_id);
                turn.lastPatchedAt = Date.now();
                this.options.log?.(`localcore-lark patched card message ${turn.messageId} for sessionKey=${sessionKey}`);
            }
            catch (error) {
                this.options.log?.(`localcore-lark bridge send failed for sessionKey=${sessionKey}: ${error instanceof Error ? error.message : String(error)}`);
            }
        })
            .finally(() => {
            if (this.outboundEventChains.get(sessionKey) === current) {
                this.outboundEventChains.delete(sessionKey);
            }
        });
        this.outboundEventChains.set(sessionKey, current);
        await current;
    }
    async handleInboundMessage(input) {
        this.options.eventBus.emit({
            type: 'platform.message.received',
            payload: {
                platform: this.platform,
                workspaceId: input.workspaceId,
                participantId: input.platformUserId,
                channelId: input.chatId,
                displayName: input.displayName,
                text: input.text,
                messageId: input.messageId,
            },
        });
        this.options.store.expirePendingPairings();
        const binding = await this.getBinding(input.workspaceId);
        let authorized = this.options.store.getAuthorizedUser(input.workspaceId, input.platformUserId);
        if (!authorized) {
            if (binding.autoApprove) {
                const authorizedAt = new Date().toISOString();
                this.options.store.createAuthorizedUser({
                    id: `lark-user-${(0, node_crypto_1.randomUUID)()}`,
                    workspace_id: input.workspaceId,
                    platform_user_id: input.platformUserId,
                    chat_id: input.chatId,
                    display_name: input.displayName,
                    thread_id: null,
                    authorized_at: authorizedAt,
                });
                authorized = this.options.store.getAuthorizedUser(input.workspaceId, input.platformUserId);
                this.options.log?.(`localcore-lark auto-approved user for ${input.workspaceId}: ${input.platformUserId}`);
                this.notifyRuntimeStateChanged();
            }
        }
        if (!authorized) {
            const existingPending = this.options.store.listPendingPairings(input.workspaceId).find((item) => item.platform === 'lark' && item.platform_user_id === input.platformUserId && item.chat_id === input.chatId && item.status === 'pending');
            let pairingCode = existingPending?.code || '';
            if (!existingPending) {
                const now = new Date();
                pairingCode = this.generatePairingCode();
                this.options.store.createPairingRequest({
                    code: pairingCode,
                    workspace_id: input.workspaceId,
                    platform_user_id: input.platformUserId,
                    chat_id: input.chatId,
                    display_name: input.displayName,
                    requested_at: now.toISOString(),
                    expires_at: new Date(now.getTime() + PAIRING_EXPIRY_MS).toISOString(),
                    status: 'pending',
                });
                this.notifyRuntimeStateChanged();
            }
            await this.sendImmediateCard(input.workspaceId, input.chatId, this.renderPendingPairingCard(pairingCode));
            return { paired: false };
        }
        const router = this.options.getWorkspaceRouter();
        const threadBinding = this.options.store.getPlatformThreadBinding(input.workspaceId, input.chatId, input.platformUserId);
        let threadId = threadBinding?.thread_id || authorized.thread_id || '';
        if (!threadId) {
            const thread = await router.createThread(input.workspaceId, input.displayName || `Lark ${input.chatId}`);
            threadId = thread.id;
            this.options.store.updateAuthorizedUserThread(input.workspaceId, input.platformUserId, threadId);
            const now = new Date().toISOString();
            this.options.store.upsertPlatformThreadBinding({
                workspace_id: input.workspaceId,
                chat_id: input.chatId,
                platform_user_id: input.platformUserId,
                thread_id: threadId,
                last_platform_message_id: null,
                created_at: now,
                updated_at: now,
            });
        }
        const sessionKey = this.options.getWorkspaceRouter().getThreadSessionKey(threadId);
        const normalizedText = String(input.text || '').trim().toLowerCase();
        const permissionThreadId = (normalizedText === 'allow' || normalizedText === 'allow all' || normalizedText === 'deny')
            ? this.findAwaitingPermissionThreadId(input.workspaceId, input.chatId, input.platformUserId)
            : '';
        if (permissionThreadId && permissionThreadId !== threadId) {
            threadId = permissionThreadId;
        }
        const effectiveSessionKey = this.options.getWorkspaceRouter().getThreadSessionKey(threadId);
        this.threadRouting.set(effectiveSessionKey, {
            workspaceId: input.workspaceId,
            platformUserId: input.platformUserId,
            chatId: input.chatId,
            threadId,
        });
        const acknowledgement = this.createTurnState(effectiveSessionKey, input.messageId);
        await this.addAcknowledgementReaction(input.workspaceId, input.messageId, acknowledgement);
        const slashCommand = this.parseSlashCommand(input.text);
        if (slashCommand?.name === 'new') {
            const title = slashCommand.args.join(' ').trim() || `${input.displayName || 'Lark'} ${new Date().toLocaleTimeString()}`;
            const nextThread = await router.createThread(input.workspaceId, title);
            const now = new Date().toISOString();
            this.options.store.updateAuthorizedUserThread(input.workspaceId, input.platformUserId, nextThread.id);
            this.options.store.upsertPlatformThreadBinding({
                workspace_id: input.workspaceId,
                chat_id: input.chatId,
                platform_user_id: input.platformUserId,
                thread_id: nextThread.id,
                last_platform_message_id: null,
                created_at: now,
                updated_at: now,
            });
            this.threadRouting.set(this.options.getWorkspaceRouter().getThreadSessionKey(nextThread.id), {
                workspaceId: input.workspaceId,
                platformUserId: input.platformUserId,
                chatId: input.chatId,
                threadId: nextThread.id,
            });
            await this.sendImmediateCard(input.workspaceId, input.chatId, '**已开始新会话**');
            return { paired: true, threadId: nextThread.id };
        }
        const latestRun = this.options.store.getLatestRunForThread(threadId);
        if ((normalizedText === 'allow' || normalizedText === 'allow all' || normalizedText === 'deny')
            && latestRun?.status === 'awaiting_input') {
            await router.sendThreadAction(threadId, input.text);
            return { paired: true, threadId };
        }
        this.options.store.clearPlatformThreadMessageId(input.workspaceId, input.chatId, input.platformUserId);
        await router.sendThreadMessage(threadId, (0, desktop_js_1.wrapUserMessageWithSchedulerProtocol)(input.text));
        return { paired: true, threadId };
    }
    close() {
        return Promise.all([...this.runtime.keys()].map((workspaceId) => this.stopWorkspace(workspaceId))).then(() => undefined);
    }
    async getBinding(workspaceId) {
        const config = await this.options.readConfig();
        const binding = this.collectBindings(config).find((entry) => entry.workspaceId === workspaceId);
        if (!binding) {
            throw new Error(`No Lark binding configured for workspace "${workspaceId}"`);
        }
        return binding;
    }
    async createSdkClientResult(binding) {
        try {
            const mod = await this.getLarkModule();
            const client = new mod.Client({
                appId: binding.appId,
                appSecret: binding.appSecret,
                appType: mod.AppType.SelfBuild,
                domain: mod.Domain.Feishu,
            });
            await client.auth.v3.appAccessToken.internal({ data: { app_id: binding.appId, app_secret: binding.appSecret } });
            return {
                success: true,
                platform: 'lark',
                workspaceId: binding.workspaceId,
                appId: binding.appId,
            };
        }
        catch (error) {
            return {
                success: false,
                platform: 'lark',
                workspaceId: binding.workspaceId,
                appId: binding.appId,
                error: error instanceof Error ? error.message : String(error),
            };
        }
    }
    async startWorkspace(binding) {
        await this.stopWorkspace(binding.workspaceId);
        const status = {
            workspaceId: binding.workspaceId,
            enabled: true,
            status: 'starting',
            connected: false,
            appId: binding.appId,
        };
        this.runtime.set(binding.workspaceId, status);
        this.notifyRuntimeStateChanged();
        try {
            const mod = await this.getLarkModule();
            status.client = new mod.Client({
                appId: binding.appId,
                appSecret: binding.appSecret,
                appType: mod.AppType.SelfBuild,
                domain: mod.Domain.Feishu,
            });
            status.eventDispatcher = new mod.EventDispatcher({
                encryptKey: binding.encryptKey || '',
                verificationToken: binding.verificationToken || '',
                loggerLevel: mod.LoggerLevel.info,
            });
            status.eventDispatcher.register({
                'im.message.receive_v1': async (data) => {
                    this.options.log?.(`localcore-lark received im.message.receive_v1 for ${binding.workspaceId}`);
                    await this.handleMessageEvent(binding.workspaceId, data);
                },
                'card.action.trigger': async (data) => {
                    this.options.log?.(`localcore-lark received card.action.trigger for ${binding.workspaceId}`);
                    void this.handleCardActionEvent(binding.workspaceId, data);
                    return {};
                },
            });
            status.wsClient = new mod.WSClient({
                appId: binding.appId,
                appSecret: binding.appSecret,
                domain: mod.Domain.Feishu,
                loggerLevel: mod.LoggerLevel.info,
            });
            await status.wsClient.start({
                eventDispatcher: status.eventDispatcher,
            });
            status.status = 'running';
            status.connected = true;
            status.connectedAt = new Date().toISOString();
            status.lastError = undefined;
        }
        catch (error) {
            status.status = 'error';
            status.connected = false;
            status.lastError = error instanceof Error ? error.message : String(error);
            this.options.log?.(`localcore-lark start failed for ${binding.workspaceId}: ${status.lastError}`);
        }
        this.notifyRuntimeStateChanged();
    }
    async stopWorkspace(workspaceId) {
        const state = this.runtime.get(workspaceId);
        if (!state) {
            return;
        }
        try {
            await state.wsClient?.stop?.();
        }
        catch {
            // Best effort: current SDK versions may not implement stop().
        }
        this.runtime.set(workspaceId, {
            workspaceId,
            enabled: false,
            status: 'stopped',
            connected: false,
            appId: state.appId,
        });
        this.notifyRuntimeStateChanged();
    }
    notifyRuntimeStateChanged() {
        this.options.eventBus.emit({
            type: 'runtime.state.changed',
            payload: {
                reason: 'channel-bindings',
            },
        });
    }
    async handleMessageEvent(workspaceId, data) {
        const payload = (data?.event && typeof data.event === 'object')
            ? data.event
            : data;
        const message = payload?.message;
        const sender = payload?.sender;
        if (!message || !sender) {
            this.options.log?.(`localcore-lark ignored event without message/sender for ${workspaceId}: ${JSON.stringify(Object.keys(data || {}))}`);
            return;
        }
        let parsedContent = {};
        try {
            parsedContent = JSON.parse(String(message.content || '{}'));
        }
        catch {
            parsedContent = {};
        }
        const text = String(parsedContent.text || '').trim();
        if (!text) {
            this.options.log?.(`localcore-lark ignored non-text message for ${workspaceId}: ${String(message.message_type || 'unknown')}`);
            return;
        }
        const platformUserId = String(sender.sender_id?.user_id || sender.sender_id?.open_id || '').trim();
        const chatId = String(message.chat_id || platformUserId).trim();
        if (!platformUserId || !chatId) {
            this.options.log?.(`localcore-lark ignored message without sender/chat for ${workspaceId}`);
            return;
        }
        this.options.log?.(`localcore-lark inbound message for ${workspaceId}: chat=${chatId} user=${platformUserId} text=${JSON.stringify(text.slice(0, 120))}`);
        await this.handleInboundMessage({
            workspaceId,
            platformUserId,
            chatId,
            displayName: String(payload?.sender?.sender_id?.user_id ||
                payload?.sender?.sender_id?.open_id ||
                `Lark ${platformUserId.slice(-6)}`),
            text,
            messageId: String(message.message_id || (0, node_crypto_1.randomUUID)()),
        });
    }
    collectBindings(config) {
        const projects = Array.isArray(config?.projects) ? config.projects : [];
        return projects.flatMap((project) => {
            const platforms = Array.isArray(project.platforms) ? project.platforms : [];
            return platforms
                .map((platform) => ({
                platformType: (0, desktop_js_1.normalizeDesktopPlatformType)(platform?.type),
                options: platform?.options && typeof platform.options === 'object'
                    ? platform.options
                    : {},
            }))
                .filter((platform) => platform.platformType === 'lark')
                .map((platform) => ({
                workspaceId: project.name,
                appId: String(platform.options.app_id || '').trim(),
                appSecret: String(platform.options.app_secret || '').trim(),
                encryptKey: String(platform.options.encrypt_key || '').trim(),
                verificationToken: String(platform.options.verification_token || '').trim(),
                autoApprove: String(platform.options.auto_approve || '').trim().toLowerCase() === 'true'
                    || platform.options.auto_approve === true,
                enabled: Boolean(String(platform.options.app_id || '').trim() && String(platform.options.app_secret || '').trim()),
                project,
            }));
        });
    }
    async getLarkModule() {
        if (!this.larkModulePromise) {
            this.larkModulePromise = Promise.resolve().then(() => __importStar(require('@larksuiteoapi/node-sdk')));
        }
        return this.larkModulePromise;
    }
    buildInteractiveCard(text, buttonRows = [], sessionKey, threadId) {
        const elements = [];
        if (text) {
            elements.push({ tag: 'markdown', content: text });
        }
        for (const row of buttonRows) {
            const actions = row
                .filter((button) => button.text && button.data)
                .map((button, index) => ({
                tag: 'button',
                text: {
                    tag: 'plain_text',
                    content: button.text,
                },
                type: index === 0 ? 'primary' : 'default',
                value: {
                    action: 'permission_response',
                    response: button.data,
                    session_key: sessionKey || '',
                    thread_id: threadId || '',
                },
            }));
            if (actions.length) {
                elements.push({
                    tag: 'action',
                    actions,
                });
            }
        }
        return {
            config: { wide_screen_mode: true },
            elements,
        };
    }
    async sendTextAsCard(state, chatId, text, buttonRows = [], sessionKey, threadId) {
        const receiveIdType = chatId.startsWith('oc_') ? 'chat_id' : chatId.startsWith('ou_') ? 'open_id' : 'user_id';
        const response = await state.client.im.message.create({
            params: {
                receive_id_type: receiveIdType,
            },
            data: {
                receive_id: chatId,
                msg_type: 'interactive',
                content: JSON.stringify(this.buildInteractiveCard(text, buttonRows, sessionKey, threadId)),
            },
        });
        return String(response?.data?.message_id || '').trim();
    }
    async patchTextCard(state, messageId, text, buttonRows = [], sessionKey, threadId) {
        await state.client.im.message.patch({
            path: {
                message_id: messageId,
            },
            data: {
                content: JSON.stringify(this.buildInteractiveCard(text, buttonRows, sessionKey, threadId)),
            },
        });
    }
    generatePairingCode() {
        return String((0, node_crypto_1.randomInt)(100000, 1000000));
    }
    findAwaitingPermissionThreadId(workspaceId, chatId, platformUserId) {
        for (const [sessionKey, route] of this.threadRouting.entries()) {
            if (route.workspaceId !== workspaceId
                || route.chatId !== chatId
                || route.platformUserId !== platformUserId) {
                continue;
            }
            const turn = this.outboundTurns.get(sessionKey);
            if (turn?.awaitingPermission && route.threadId) {
                return route.threadId;
            }
        }
        return '';
    }
    parseSlashCommand(text) {
        const normalized = String(text || '').trim();
        if (!normalized.startsWith('/')) {
            return null;
        }
        const [name = '', ...args] = normalized.slice(1).split(/\s+/);
        if (!name) {
            return null;
        }
        return {
            name: name.trim().toLowerCase(),
            args,
        };
    }
    createTurnState(sessionKey, sourceMessageId) {
        const turn = {
            sessionKey,
            sourceMessageId,
            awaitingPermission: false,
            processing: false,
            previewText: '',
            finalText: '',
            thinkingSteps: [],
            toolCalls: [],
            statusLines: [],
            buttonRows: [],
            lastPatchedAt: 0,
        };
        this.outboundTurns.set(sessionKey, turn);
        return turn;
    }
    getOrCreateTurnState(sessionKey, messageId) {
        const existing = this.outboundTurns.get(sessionKey);
        if (existing) {
            if (messageId && !existing.messageId) {
                existing.messageId = messageId;
            }
            return existing;
        }
        const turn = this.createTurnState(sessionKey);
        if (messageId) {
            turn.messageId = messageId;
        }
        return turn;
    }
    consumeBridgeEvent(turn, event) {
        const content = String(event.content || '').trim();
        if (event.type === 'typing_start') {
            // Always start a fresh card for each generation phase.
            // This keeps Feishu message order aligned with user-visible timeline.
            turn.messageId = undefined;
            turn.processing = true;
            turn.permissionMessageId = undefined;
            turn.previewText = '';
            turn.finalText = '';
            turn.thinkingSteps = [];
            turn.toolCalls = [];
            turn.buttonRows = [];
            turn.statusLines = [];
            return;
        }
        if (event.type === 'typing_stop') {
            turn.processing = false;
            return;
        }
        if (event.type === 'preview_start' || event.type === 'update_message') {
            turn.previewText = content;
            return;
        }
        if (event.type === 'status') {
            if (content) {
                this.pushUnique(turn.statusLines, content);
            }
            return;
        }
        if (event.type === 'buttons') {
            turn.awaitingPermission = true;
            turn.buttonRows = this.enableCardActions && Array.isArray(event.buttonRows)
                ? event.buttonRows
                    .map((row) => Array.isArray(row)
                    ? row
                        .filter((button) => Boolean(button?.text && button?.data))
                        .map((button) => ({ text: button.text, data: button.data }))
                    : [])
                    .filter((row) => row.length > 0)
                : [];
            if (this.mirrorPermissionStateInMainCard && content) {
                this.pushUnique(turn.statusLines, `等待确认: ${content}`);
            }
            return;
        }
        if (!content) {
            return;
        }
        if (content.startsWith('💭 ')) {
            this.pushUnique(turn.thinkingSteps, content.slice(3).trim());
            return;
        }
        if (content.startsWith('🔧 ')) {
            this.pushUnique(turn.toolCalls, content.slice(3).trim());
            return;
        }
        if (content.startsWith('⏳ ') || content.startsWith('📤 ')) {
            this.pushUnique(turn.statusLines, content.slice(3).trim());
            return;
        }
        turn.finalText = content;
        turn.previewText = content;
    }
    renderTurnCard(turn) {
        const sections = [];
        if (turn.finalText) {
            sections.push(turn.finalText);
        }
        else if (turn.previewText) {
            sections.push(turn.previewText);
        }
        else if (turn.processing && turn.toolCalls.length > 0) {
            sections.push(`**处理中**\n${this.formatCompactToolLines(turn.toolCalls).join('\n')}`);
        }
        else if (turn.processing) {
            sections.push('**处理中**\n正在思考...');
        }
        return {
            text: sections.join('\n\n').trim(),
            buttonRows: turn.buttonRows,
        };
    }
    renderPermissionCard(turn, event) {
        const summary = this.buildPermissionSummary(turn, String(event.content || '').trim());
        const sections = [
            '**需要工具确认**',
            summary.command ? `\`${summary.command}\`` : '',
            summary.reason || '',
            '回复：`allow` / `allow all` / `deny`',
        ].filter(Boolean);
        const buttonRows = this.enableCardActions && Array.isArray(event.buttonRows)
            ? event.buttonRows
                .map((row) => Array.isArray(row)
                ? row
                    .filter((button) => Boolean(button?.text && button?.data))
                    .map((button) => ({ text: button.text, data: button.data }))
                : [])
                .filter((row) => row.length > 0)
            : [];
        return {
            text: sections.join('\n\n').trim(),
            buttonRows,
        };
    }
    renderPendingPairingCard(code) {
        const lines = [
            '**已收到消息**',
            '当前账号还未授权接入这个工作区。',
            '请在桌面端完成审批后再次发送消息。',
        ];
        if (code) {
            lines.push(`配对码：\`${code}\``);
        }
        return lines.join('\n\n');
    }
    async handleCardActionEvent(workspaceId, data) {
        try {
            const payload = (data?.event && typeof data.event === 'object')
                ? data.event
                : data;
            const value = payload?.action?.value;
            if (!value || value.action !== 'permission_response') {
                return;
            }
            const response = String(value.response || '').trim();
            const threadId = String(value.thread_id || '').trim();
            if (!response || !threadId) {
                return;
            }
            const router = this.options.getWorkspaceRouter();
            await router.sendThreadAction(threadId, response);
            this.options.log?.(`localcore-lark processed card action for ${workspaceId}: ${response}`);
        }
        catch (error) {
            this.options.log?.(`localcore-lark card action failed for ${workspaceId}: ${error instanceof Error ? error.message : String(error)}`);
        }
    }
    pushUnique(target, value) {
        const normalized = value.trim();
        if (!normalized) {
            return;
        }
        if (target[target.length - 1] === normalized) {
            return;
        }
        target.push(normalized);
        if (target.length > 6) {
            target.splice(0, target.length - 6);
        }
    }
    buildPermissionSummary(turn, rawContent) {
        const lastTool = turn.toolCalls[turn.toolCalls.length - 1] || '';
        const [commandPart = '', reasonPart = ''] = lastTool.split(/\s+-\s+/, 2);
        const compactContent = rawContent
            .replace(/\s+/g, ' ')
            .replace(/请选择一个选项继续执行。?/g, '')
            .replace(/若按钮没有显示，请直接回复：?\s*allow all \/ allow \/ deny/gi, '')
            .replace(/等待工具确认/gi, '')
            .trim();
        return {
            command: commandPart.trim(),
            reason: reasonPart.trim() || compactContent,
        };
    }
    formatCompactToolLines(toolCalls) {
        return toolCalls.slice(-2).map((line) => {
            const compact = line.replace(/\s+/g, ' ').trim();
            return compact.startsWith('Terminal') ? '• Terminal' : `• ${compact}`;
        });
    }
    async sendImmediateCard(workspaceId, chatId, text) {
        const state = this.runtime.get(workspaceId);
        if (!state?.client || !state.connected) {
            this.options.log?.(`localcore-lark immediate card skipped because workspace is not connected: ${workspaceId}`);
            return '';
        }
        try {
            return await this.sendTextAsCard(state, chatId, text);
        }
        catch (error) {
            this.options.log?.(`localcore-lark immediate card failed for ${workspaceId}: ${error instanceof Error ? error.message : String(error)}`);
            return '';
        }
    }
    async addAcknowledgementReaction(workspaceId, messageId, turn) {
        const state = this.runtime.get(workspaceId);
        if (!state?.client || !state.connected || !messageId) {
            return;
        }
        try {
            const response = await state.client.im.messageReaction.create({
                path: {
                    message_id: messageId,
                },
                data: {
                    reaction_type: {
                        emoji_type: 'DONE',
                    },
                },
            });
            turn.acknowledgementReactionId = String(response?.data?.reaction_id || '').trim() || undefined;
            this.options.log?.(`localcore-lark acknowledgement reaction added for message=${messageId}`);
        }
        catch (error) {
            this.options.log?.(`localcore-lark acknowledgement reaction failed for message=${messageId}: ${error instanceof Error ? error.message : String(error)}`);
        }
    }
}
exports.LocalCoreLarkGateway = LocalCoreLarkGateway;
