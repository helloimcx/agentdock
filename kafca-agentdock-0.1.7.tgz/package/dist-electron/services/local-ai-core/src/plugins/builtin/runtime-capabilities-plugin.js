"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runtimeCapabilitiesPlugin = void 0;
const desktop_js_1 = require("../../../../../shared/desktop.js");
exports.runtimeCapabilitiesPlugin = {
    manifest: {
        id: 'builtin.runtime-capabilities',
        kind: 'composite',
        version: '0.1.0',
        provides: [
            'agent:opencode',
            'agent:codex',
            'agent:claudecode',
            'agent:cursor',
            'agent:gemini',
            'agent:qoder',
            'agent:iflow',
            `agent:${desktop_js_1.LOCALCORE_ACP_AGENT_TYPE}`,
            'channel:localcore-lark',
            `channel:${desktop_js_1.LOCALCORE_ACP_AGENT_TYPE}`,
            'knowledge:ai-vector',
            'scheduler:cron',
        ],
    },
    capabilities: {
        agents: desktop_js_1.DESKTOP_AGENT_TYPE_OPTIONS.map((agentType) => ({
            id: `agent.${agentType}`,
            agentType,
            displayName: agentType,
        })),
        channels: [
            {
                id: 'channel.localcore-lark',
                platform: 'lark',
                routeType: 'lark_chat',
                displayName: 'LocalCore Lark',
            },
            {
                id: `channel.${desktop_js_1.LOCALCORE_ACP_AGENT_TYPE}`,
                platform: desktop_js_1.LOCALCORE_ACP_AGENT_TYPE,
                displayName: 'LocalCore ACP',
            },
        ],
        knowledge: [
            {
                id: 'knowledge.ai-vector',
                sourceType: 'ai-vector',
                enabled: true,
                displayName: 'AI Vector Knowledge',
            },
        ],
        schedulers: [
            {
                id: 'scheduler.cron',
                triggerTypes: ['cron', 'once'],
                deliveryPlatforms: ['lark'],
                enabled: true,
                displayName: 'Cron Scheduler',
            },
        ],
    },
};
