"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createBuiltinAiVectorKnowledgePlugin = createBuiltinAiVectorKnowledgePlugin;
const index_js_1 = require("../../../../../packages/knowledge-api/src/index.js");
function createBuiltinAiVectorKnowledgePlugin(options) {
    return (0, index_js_1.createAiVectorKnowledgePlugin)(options);
}
