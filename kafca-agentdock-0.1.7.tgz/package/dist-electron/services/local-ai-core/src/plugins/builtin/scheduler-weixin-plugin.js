"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createBuiltinWeixinSchedulerPlugin = createBuiltinWeixinSchedulerPlugin;
const weixin_schedule_adapter_js_1 = require("../../scheduler/weixin-schedule-adapter.js");
function createBuiltinWeixinSchedulerPlugin(options) {
    return {
        manifest: {
            id: 'builtin.scheduler-weixin',
            kind: 'scheduler',
            version: '0.1.0',
            dependsOn: ['builtin.channel-weixin'],
            provides: ['scheduler.delivery.weixin'],
        },
        capabilities: {
            schedulers: [
                {
                    id: 'scheduler.delivery.weixin',
                    triggerTypes: [],
                    deliveryTargets: ['weixin'],
                    enabled: true,
                    displayName: 'WeChat Scheduled Delivery',
                },
            ],
        },
        createRuntime() {
            return {
                executors: [
                    new weixin_schedule_adapter_js_1.WeixinScheduleAdapter({
                        store: options.store,
                        getWorkspaceRouter: options.getWorkspaceRouter,
                        getChannelRuntime: options.getChannelRuntime,
                        log: options.log,
                    }),
                ],
            };
        },
    };
}
