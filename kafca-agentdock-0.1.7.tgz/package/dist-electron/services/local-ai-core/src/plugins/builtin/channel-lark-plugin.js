"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createBuiltinLarkChannelPlugin = createBuiltinLarkChannelPlugin;
const local_core_lark_gateway_js_1 = require("../../gateway/local-core-lark-gateway.js");
function createBuiltinLarkChannelPlugin(options) {
    let runtime = null;
    let unsubscribeBridgeEvents = null;
    return {
        manifest: {
            id: 'builtin.channel-lark',
            kind: 'channel',
            version: '0.1.0',
            provides: [
                'channel:lark',
            ],
            configSchema: {
                fields: [
                    { key: 'appId', type: 'string', label: 'App ID' },
                    { key: 'appSecret', type: 'string', label: 'App Secret' },
                ],
            },
        },
        capabilities: {
            channels: [
                {
                    id: 'channel.lark',
                    platform: 'lark',
                    routeType: 'channel.chat',
                    displayName: 'LocalCore Lark',
                },
            ],
        },
        createRuntime(ctx) {
            if (!runtime) {
                runtime = {
                    channel: new local_core_lark_gateway_js_1.LocalCoreLarkGateway({
                        store: options.store,
                        readConfig: options.readConfig,
                        getWorkspaceRouter: options.getWorkspaceRouter,
                        eventBus: ctx.bus,
                        log: options.log,
                    }),
                };
                unsubscribeBridgeEvents = ctx.bus.on('platform.bridge.updated', (event) => {
                    void runtime?.channel.onBridgeEvent?.(event);
                });
            }
            return runtime;
        },
        async start() {
            await runtime?.channel.refreshBindings?.();
        },
        async stop() {
            unsubscribeBridgeEvents?.();
            unsubscribeBridgeEvents = null;
            runtime?.channel.close?.();
        },
    };
}
