"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createBuiltinWeixinChannelPlugin = createBuiltinWeixinChannelPlugin;
const local_core_weixin_gateway_js_1 = require("../../gateway/local-core-weixin-gateway.js");
function createBuiltinWeixinChannelPlugin(options) {
    let runtime = null;
    let unsubscribeBridgeEvents = null;
    return {
        manifest: {
            id: 'builtin.channel-weixin',
            kind: 'channel',
            version: '0.1.0',
            provides: [
                'channel:weixin',
            ],
            configSchema: {
                fields: [],
            },
        },
        capabilities: {
            channels: [
                {
                    id: 'channel.weixin',
                    platform: 'weixin',
                    routeType: 'channel.chat',
                    displayName: 'LocalCore WeChat',
                },
            ],
        },
        createRuntime(ctx) {
            if (!runtime) {
                runtime = {
                    channel: new local_core_weixin_gateway_js_1.LocalCoreWeixinGateway({
                        store: options.store,
                        readConfig: options.readConfig,
                        getWorkspaceRouter: options.getWorkspaceRouter,
                        eventBus: ctx.bus,
                        log: options.log,
                    }),
                };
                unsubscribeBridgeEvents = ctx.bus.on('platform.bridge.updated', (event) => {
                    void runtime?.channel.onBridgeEvent?.(event);
                });
            }
            return runtime;
        },
        async start() {
            await runtime?.channel.refreshBindings?.();
        },
        async stop() {
            unsubscribeBridgeEvents?.();
            unsubscribeBridgeEvents = null;
            runtime?.channel.close?.();
        },
    };
}
