"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createBuiltinLarkSchedulerPlugin = createBuiltinLarkSchedulerPlugin;
const lark_schedule_adapter_js_1 = require("../../scheduler/lark-schedule-adapter.js");
function createBuiltinLarkSchedulerPlugin(options) {
    return {
        manifest: {
            id: 'builtin.scheduler-lark',
            kind: 'scheduler',
            version: '0.1.0',
            dependsOn: ['builtin.channel-lark'],
            provides: ['scheduler.delivery.lark'],
        },
        capabilities: {
            schedulers: [
                {
                    id: 'scheduler.delivery.lark',
                    triggerTypes: [],
                    deliveryTargets: ['lark'],
                    enabled: true,
                    displayName: 'Lark Scheduled Delivery',
                },
            ],
        },
        createRuntime() {
            return {
                executors: [
                    new lark_schedule_adapter_js_1.LarkScheduleAdapter({
                        store: options.store,
                        getWorkspaceRouter: options.getWorkspaceRouter,
                        getChannelRuntime: options.getChannelRuntime,
                        log: options.log,
                    }),
                ],
            };
        },
    };
}
