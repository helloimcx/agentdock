"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createBuiltinNoopKnowledgePlugin = createBuiltinNoopKnowledgePlugin;
const index_js_1 = require("../../../../../packages/knowledge-api/src/index.js");
function createBuiltinNoopKnowledgePlugin() {
    return (0, index_js_1.createNoopKnowledgePlugin)();
}
