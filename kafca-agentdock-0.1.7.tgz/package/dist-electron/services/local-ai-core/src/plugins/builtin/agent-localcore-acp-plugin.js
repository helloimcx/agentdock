"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createBuiltinLocalCoreAcpAgentPlugin = createBuiltinLocalCoreAcpAgentPlugin;
exports.createBuiltinOpencodeAgentPlugin = createBuiltinOpencodeAgentPlugin;
exports.createBuiltinClaudeCodeAgentPlugin = createBuiltinClaudeCodeAgentPlugin;
exports.createBuiltinStaticAgentCapabilityPlugin = createBuiltinStaticAgentCapabilityPlugin;
const desktop_js_1 = require("../../../../../shared/desktop.js");
const workspace_route_config_js_1 = require("../../router/workspace-route-config.js");
function createRuntime(agentType, match) {
    return {
        agentType,
        transport: desktop_js_1.LOCALCORE_ACP_AGENT_TYPE,
        displayName: agentType,
        matchesProject(project) {
            const normalizedAgentType = String(project.agent?.type || '').trim().toLowerCase();
            return match(normalizedAgentType);
        },
        createRoute(configState, project) {
            if (!this.matchesProject(project)) {
                return null;
            }
            return {
                kind: desktop_js_1.LOCALCORE_ACP_AGENT_TYPE,
                agentType,
                transport: desktop_js_1.LOCALCORE_ACP_AGENT_TYPE,
                config: {
                    ...(0, workspace_route_config_js_1.toLocalCoreProjectConfig)(configState, project),
                    agentType,
                },
                supportsStreamingProbe: true,
            };
        },
    };
}
function createBuiltinAgentPlugin(options) {
    let runtime = null;
    return {
        manifest: {
            id: options.pluginId,
            kind: 'agent',
            version: '0.1.0',
            provides: [`agent:${options.agentType}`],
        },
        capabilities: {
            agents: [
                {
                    id: `agent.${options.agentType}`,
                    agentType: options.agentType,
                    displayName: options.displayName || options.agentType,
                },
            ],
        },
        createRuntime(_ctx) {
            if (!runtime) {
                runtime = createRuntime(options.agentType, options.match);
            }
            return { runtime };
        },
    };
}
function createBuiltinLocalCoreAcpAgentPlugin() {
    const plugin = createBuiltinAgentPlugin({
        pluginId: 'builtin.agent-localcore-acp',
        agentType: desktop_js_1.LOCALCORE_ACP_AGENT_TYPE,
        match: (normalizedAgentType) => !normalizedAgentType || normalizedAgentType === 'acp' || normalizedAgentType === desktop_js_1.LOCALCORE_ACP_AGENT_TYPE,
        displayName: 'LocalCore ACP',
    });
    plugin.capabilities = {
        ...plugin.capabilities,
        channels: [
            {
                id: `channel.${desktop_js_1.LOCALCORE_ACP_AGENT_TYPE}`,
                platform: desktop_js_1.LOCALCORE_ACP_AGENT_TYPE,
                displayName: 'LocalCore ACP',
            },
        ],
    };
    return plugin;
}
function createBuiltinOpencodeAgentPlugin() {
    return createBuiltinAgentPlugin({
        pluginId: 'builtin.agent-opencode',
        agentType: 'opencode',
        match: (normalizedAgentType) => normalizedAgentType === 'opencode',
        displayName: 'OpenCode',
    });
}
function createBuiltinClaudeCodeAgentPlugin() {
    return createBuiltinAgentPlugin({
        pluginId: 'builtin.agent-claudecode',
        agentType: 'claudecode',
        match: (normalizedAgentType) => normalizedAgentType === 'claudecode',
        displayName: 'Claude Code',
    });
}
function createBuiltinStaticAgentCapabilityPlugin(agentType) {
    return {
        manifest: {
            id: `builtin.agent-${agentType}`,
            kind: 'agent',
            version: '0.1.0',
            provides: [`agent:${agentType}`],
        },
        capabilities: {
            agents: [
                {
                    id: `agent.${agentType}`,
                    agentType,
                    displayName: agentType,
                },
            ],
        },
    };
}
