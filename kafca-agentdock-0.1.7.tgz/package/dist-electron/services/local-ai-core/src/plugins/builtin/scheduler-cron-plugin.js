"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createBuiltinCronSchedulerPlugin = createBuiltinCronSchedulerPlugin;
const cron_js_1 = require("../../scheduler/cron.js");
class CronSchedulerTriggerRuntime {
    triggerTypes = ['cron', 'once'];
    supports(job) {
        return job.triggerType === 'cron' || job.triggerType === 'once';
    }
    isDue(job, now) {
        if (job.triggerType === 'once') {
            return Boolean(job.runAt && Date.parse(job.runAt) <= now.getTime() && !job.lastRunAt);
        }
        if (!job.cronExpr) {
            return false;
        }
        if (!(0, cron_js_1.cronMatchesDate)(job.cronExpr, now)) {
            return false;
        }
        const minuteStart = (0, cron_js_1.floorToMinute)(now).toISOString();
        return !job.lastRunAt || job.lastRunAt < minuteStart;
    }
}
function createBuiltinCronSchedulerPlugin() {
    return {
        manifest: {
            id: 'builtin.scheduler-cron',
            kind: 'scheduler',
            version: '0.1.0',
            provides: ['scheduler.trigger.cron'],
        },
        capabilities: {
            schedulers: [
                {
                    id: 'scheduler.trigger.cron',
                    triggerTypes: ['cron', 'once'],
                    deliveryTargets: [],
                    enabled: true,
                    displayName: 'Cron Trigger',
                },
            ],
        },
        createRuntime() {
            return {
                triggers: [new CronSchedulerTriggerRuntime()],
            };
        },
    };
}
