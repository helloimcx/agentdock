"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.upsertSessionGroup = exports.ASSISTANT_REPLY_TIMEOUT_MS = void 0;
exports.isInternalProgressMessage = isInternalProgressMessage;
exports.isAwaitingInputMessage = isAwaitingInputMessage;
exports.extractVisibleMessageContent = extractVisibleMessageContent;
exports.sessionMatchesDesktop = sessionMatchesDesktop;
exports.toMessages = toMessages;
exports.toMessagesFromThread = toMessagesFromThread;
exports.toChatThreadSummary = toChatThreadSummary;
exports.toCoreChatThreadSummary = toCoreChatThreadSummary;
exports.sortChatThreadsByLiveAndUpdated = sortChatThreadsByLiveAndUpdated;
exports.chatThreadMatchesSearch = chatThreadMatchesSearch;
exports.sortChatMessages = sortChatMessages;
exports.formatMessageTimestamp = formatMessageTimestamp;
exports.formatRuntimePhase = formatRuntimePhase;
exports.sessionProjectFromKey = sessionProjectFromKey;
exports.normalizeBridgeActionRows = normalizeBridgeActionRows;
exports.upsertThreadGroup = upsertThreadGroup;
exports.upsertThreadInGroup = upsertThreadInGroup;
exports.isPermissionActionRow = isPermissionActionRow;
exports.formatTaskHint = formatTaskHint;
exports.isTaskRunningState = isTaskRunningState;
exports.isTaskInputLocked = isTaskInputLocked;
exports.canStreamingPromoteTaskState = canStreamingPromoteTaskState;
const desktop_1 = require("../../../shared/desktop");
const session_utils_1 = require("@/lib/session-utils");
exports.ASSISTANT_REPLY_TIMEOUT_MS = 90000;
function isInternalProgressMessage(content) {
    if (!content) {
        return false;
    }
    return (content.startsWith('💭 ') ||
        content.startsWith('🔧 ') ||
        content.startsWith('📤 ') ||
        content.startsWith('⏳ '));
}
function isAwaitingInputMessage(content) {
    if (!content) {
        return false;
    }
    const normalized = content.replace(/\s+/g, ' ').trim();
    return (/^Agent 提问(?:\s*\(\d+\/\d+\))?/i.test(normalized) ||
        normalized.includes('请回复选项编号') ||
        normalized.includes('直接输入你的回答') ||
        normalized.includes('等待你的回复') ||
        normalized.includes('请直接回复') ||
        normalized.includes('请输入你的回答'));
}
function extractVisibleMessageContent(content) {
    if (!content) {
        return '';
    }
    const match = content.match(/\[User Message\]\s*([\s\S]*?)\s*\[\/User Message\]/);
    if (!match) {
        return content;
    }
    return match[1] || '';
}
function sessionMatchesDesktop(session) {
    return session.platform === 'desktop' || session.session_key.startsWith('desktop:');
}
function toMessages(history) {
    return history.map((message, index) => ({
        id: `${index}-${message.timestamp || message.role}`,
        role: message.role === 'user' ? 'user' : 'assistant',
        content: message.role === 'user' ? extractVisibleMessageContent(message.content) : message.content,
        kind: message.kind === 'progress' ? 'progress' : 'final',
        order: index,
        timestamp: message.timestamp,
    }));
}
function toMessagesFromThread(history) {
    return history.map((message, index) => ({
        id: message.id || `${index}-${message.timestamp || message.role}`,
        role: message.role === 'user' ? 'user' : 'assistant',
        content: message.role === 'user' ? extractVisibleMessageContent(message.content) : message.content,
        kind: message.kind === 'progress'
            ? 'progress'
            : message.kind === 'system'
                ? 'progress'
                : 'final',
        order: index,
        timestamp: message.timestamp,
    }));
}
function toChatThreadSummary(project, session) {
    return {
        id: session.id,
        project,
        name: (0, session_utils_1.sessionLabel)(session),
        live: session.live,
        createdAt: session.created_at,
        updatedAt: session.updated_at,
        excerpt: extractVisibleMessageContent(session.last_message?.content || ''),
        agentType: session.agent_type,
        bridgeSessionKey: session.session_key,
    };
}
function toCoreChatThreadSummary(thread) {
    return {
        id: thread.id,
        project: thread.workspaceId,
        name: thread.title,
        live: thread.live,
        createdAt: thread.createdAt,
        updatedAt: thread.updatedAt,
        excerpt: extractVisibleMessageContent(thread.excerpt),
        agentType: thread.agentType,
        bridgeSessionKey: thread.bridgeSessionKey,
    };
}
function sortChatThreadsByLiveAndUpdated(items) {
    return [...items].sort((a, b) => {
        if (a.live !== b.live) {
            return a.live ? -1 : 1;
        }
        return (b.updatedAt || b.createdAt || '').localeCompare(a.updatedAt || a.createdAt || '');
    });
}
function chatThreadMatchesSearch(thread, query) {
    if (!query) {
        return true;
    }
    const haystack = [thread.name, thread.excerpt, thread.bridgeSessionKey || ''].join(' ').toLowerCase();
    return haystack.includes(query);
}
function sortChatMessages(messages) {
    return [...messages].sort((a, b) => {
        const aTime = a.timestamp ? new Date(a.timestamp).getTime() : Number.NaN;
        const bTime = b.timestamp ? new Date(b.timestamp).getTime() : Number.NaN;
        const aHasTime = Number.isFinite(aTime);
        const bHasTime = Number.isFinite(bTime);
        if (aHasTime && bHasTime && aTime !== bTime) {
            return aTime - bTime;
        }
        if (a.order !== b.order) {
            return a.order - b.order;
        }
        return a.id.localeCompare(b.id);
    });
}
function formatMessageTimestamp(timestamp) {
    if (!timestamp) {
        return '';
    }
    const date = new Date(timestamp);
    if (Number.isNaN(date.getTime())) {
        return '';
    }
    return new Intl.DateTimeFormat(undefined, {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
    }).format(date);
}
function formatRuntimePhase(phase) {
    switch (phase) {
        case 'starting':
            return '启动中';
        case 'api_ready':
            return '服务就绪';
        case 'error':
            return '运行异常';
        default:
            return '未启动';
    }
}
function sessionProjectFromKey(sessionKey) {
    if (!sessionKey?.startsWith('desktop:')) {
        return '';
    }
    const [, project = ''] = sessionKey.split(':');
    return project;
}
function normalizeBridgeActionRows(input) {
    if (!Array.isArray(input)) {
        return [];
    }
    return input
        .map((row) => {
        if (!Array.isArray(row)) {
            return [];
        }
        return row
            .map((button) => (0, desktop_1.normalizeDesktopBridgeButtonOption)(button))
            .filter((button) => Boolean(button));
    })
        .filter((row) => row.length > 0);
}
function upsertThreadGroup(groups, project, sessions) {
    const next = groups.filter((group) => group.project !== project);
    next.push({ project, sessions });
    return next.sort((a, b) => a.project.localeCompare(b.project));
}
exports.upsertSessionGroup = upsertThreadGroup;
function upsertThreadInGroup(groups, project, thread) {
    const current = groups.find((group) => group.project === project)?.sessions || [];
    const nextSessions = sortChatThreadsByLiveAndUpdated([
        thread,
        ...current.filter((item) => item.id !== thread.id),
    ]);
    return upsertThreadGroup(groups, project, nextSessions);
}
function isPermissionActionRow(rows) {
    return rows.some((row) => row.some((action) => (0, desktop_1.isPermissionButtonOption)(action)));
}
function formatTaskHint(taskState, typing) {
    if (taskState === 'stopping') {
        return 'Stopping current task…';
    }
    if (taskState === 'error') {
        return '';
    }
    if (taskState === 'awaiting_input') {
        return 'Agent is waiting for your reply.';
    }
    if (taskState === 'permission_submitted') {
        return 'Permission sent. Waiting for the agent to continue…';
    }
    if (taskState === 'awaiting_permission') {
        return 'Waiting for your permission response.';
    }
    if (typing) {
        return 'Agent is typing…';
    }
    if (taskState === 'running') {
        return 'Task is running…';
    }
    return '';
}
function isTaskRunningState(taskState) {
    return (taskState === 'running' ||
        taskState === 'awaiting_permission' ||
        taskState === 'permission_submitted' ||
        taskState === 'stopping');
}
function isTaskInputLocked(taskState) {
    return taskState !== 'idle' && taskState !== 'awaiting_input' && taskState !== 'error';
}
function canStreamingPromoteTaskState(taskState) {
    return taskState !== 'awaiting_input' &&
        taskState !== 'awaiting_permission' &&
        taskState !== 'permission_submitted' &&
        taskState !== 'stopping';
}
