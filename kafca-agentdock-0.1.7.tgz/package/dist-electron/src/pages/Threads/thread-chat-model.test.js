"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_test_1 = __importDefault(require("node:test"));
const strict_1 = __importDefault(require("node:assert/strict"));
const thread_chat_model_1 = require("./thread-chat-model");
function createPermissionActions() {
    return [[
            { text: 'Allow', data: 'allow' },
            { text: 'Deny', data: 'deny' },
        ]];
}
function createMessage(overrides) {
    return {
        id: 'message',
        role: 'assistant',
        content: 'Permission required',
        order: 0,
        ...overrides,
    };
}
(0, node_test_1.default)('getLatestInteractivePermissionMessage returns the latest actionable permission prompt', () => {
    const messages = [
        createMessage({
            id: 'older-permission',
            order: 1,
            actionMode: 'permission',
            actionInteractive: true,
            actions: createPermissionActions(),
        }),
        createMessage({
            id: 'generic-buttons',
            order: 2,
            actionMode: 'generic',
            actionInteractive: true,
            actions: createPermissionActions(),
        }),
        createMessage({
            id: 'latest-permission',
            order: 3,
            actionMode: 'permission',
            actionInteractive: true,
            actions: createPermissionActions(),
        }),
    ];
    const prompt = (0, thread_chat_model_1.getLatestInteractivePermissionMessage)(messages);
    strict_1.default.ok(prompt);
    strict_1.default.equal(prompt.id, 'latest-permission');
});
(0, node_test_1.default)('getLatestInteractivePermissionMessage ignores submitted or non-interactive prompts', () => {
    const messages = [
        createMessage({
            id: 'submitted-permission',
            order: 1,
            actionMode: 'permission',
            actionInteractive: true,
            actions: [],
            actionStatus: 'Permission sent',
        }),
        createMessage({
            id: 'unsupported-permission',
            order: 2,
            actionMode: 'permission',
            actionInteractive: false,
            actions: createPermissionActions(),
        }),
    ];
    strict_1.default.equal((0, thread_chat_model_1.getLatestInteractivePermissionMessage)(messages), undefined);
});
(0, node_test_1.default)('taskStateAfterTypingStop keeps awaiting_permission prompts visible', () => {
    strict_1.default.equal((0, thread_chat_model_1.taskStateAfterTypingStop)('awaiting_permission'), 'awaiting_permission');
    strict_1.default.equal((0, thread_chat_model_1.taskStateAfterTypingStop)('running'), 'idle');
    strict_1.default.equal((0, thread_chat_model_1.taskStateAfterTypingStop)('permission_submitted'), 'idle');
});
