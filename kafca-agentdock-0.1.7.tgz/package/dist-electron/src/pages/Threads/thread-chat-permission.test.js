"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_test_1 = __importDefault(require("node:test"));
const strict_1 = __importDefault(require("node:assert/strict"));
const thread_chat_permission_1 = require("./thread-chat-permission");
const thread_chat_task_state_1 = require("./thread-chat-task-state");
function createPermissionActions() {
    return [[
            { text: 'Allow', data: 'allow' },
            { text: 'Deny', data: 'deny' },
        ]];
}
function createMessage(overrides) {
    const { id, ...rest } = overrides;
    return {
        role: 'assistant',
        content: 'Permission required',
        order: 0,
        ...rest,
        id,
    };
}
(0, node_test_1.default)('toPendingPermissionRequest returns an actionable permission prompt payload', () => {
    const prompt = (0, thread_chat_permission_1.toPendingPermissionRequest)(createMessage({
        id: 'latest-permission',
        order: 3,
        actionMode: 'permission',
        actionInteractive: true,
        actionReplyCtx: 'run-1',
        actions: createPermissionActions(),
    }));
    strict_1.default.ok(prompt);
    strict_1.default.equal(prompt.id, 'latest-permission');
    strict_1.default.deepEqual(prompt.actions, createPermissionActions());
    strict_1.default.equal(prompt.actionReplyCtx, 'run-1');
});
(0, node_test_1.default)('taskStateAfterTypingStop keeps awaiting_permission prompts visible', () => {
    strict_1.default.equal((0, thread_chat_task_state_1.taskStateAfterTypingStop)('awaiting_permission'), 'awaiting_permission');
    strict_1.default.equal((0, thread_chat_task_state_1.taskStateAfterTypingStop)('running'), 'idle');
    strict_1.default.equal((0, thread_chat_task_state_1.taskStateAfterTypingStop)('permission_submitted'), 'idle');
});
(0, node_test_1.default)('taskStateForBridgeButtons prioritizes interactive permission requests', () => {
    strict_1.default.equal((0, thread_chat_task_state_1.taskStateForBridgeButtons)(true, true), 'awaiting_permission');
    strict_1.default.equal((0, thread_chat_task_state_1.taskStateReasonForBridgeButtons)(true, true), 'bridge-buttons-awaiting-permission');
    strict_1.default.equal((0, thread_chat_task_state_1.taskStateForBridgeButtons)(true, false), 'awaiting_input');
    strict_1.default.equal((0, thread_chat_task_state_1.taskStateReasonForBridgeButtons)(true, false), 'bridge-buttons-awaiting-input');
    strict_1.default.equal((0, thread_chat_task_state_1.taskStateForBridgeButtons)(false, false), 'idle');
    strict_1.default.equal((0, thread_chat_task_state_1.taskStateReasonForBridgeButtons)(false, false), 'bridge-buttons-idle');
});
(0, node_test_1.default)('deriveTaskStateFromThreadDetail recognizes permission and input blocking states', () => {
    const pendingPermission = (0, thread_chat_task_state_1.deriveTaskStateFromThreadDetail)({
        id: 'thread-1',
        workspaceId: 'default',
        title: 'Thread',
        live: false,
        updatedAt: '2026-04-22T00:00:00.000Z',
        createdAt: '2026-04-22T00:00:00.000Z',
        historyCount: 1,
        excerpt: '',
        messages: [],
        selectedKnowledgeBaseIds: [],
        pendingPermissionRequest: {
            id: 'permission-1',
            content: 'Permission required',
            actions: createPermissionActions(),
            actionMode: 'permission',
            actionInteractive: true,
        },
    }, 0, 0);
    strict_1.default.deepEqual(pendingPermission, {
        state: 'awaiting_permission',
        reason: 'local-core-poll-awaiting-permission',
    });
    const awaitingInput = (0, thread_chat_task_state_1.deriveTaskStateFromThreadDetail)({
        id: 'thread-1',
        workspaceId: 'default',
        title: 'Thread',
        live: false,
        updatedAt: '2026-04-22T00:00:00.000Z',
        createdAt: '2026-04-22T00:00:00.000Z',
        historyCount: 1,
        excerpt: '',
        messages: [
            {
                id: 'assistant-1',
                role: 'assistant',
                content: '等待你的回复，请直接回复选项编号',
                timestamp: '2026-04-22T00:00:00.000Z',
                kind: 'progress',
            },
        ],
        selectedKnowledgeBaseIds: [],
        pendingPermissionRequest: null,
    }, 0, 0);
    strict_1.default.deepEqual(awaitingInput, {
        state: 'awaiting_input',
        reason: 'local-core-poll-awaiting-input',
    });
});
