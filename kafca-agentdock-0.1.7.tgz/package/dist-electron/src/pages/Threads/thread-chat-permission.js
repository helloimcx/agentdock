"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toPendingPermissionRequest = toPendingPermissionRequest;
function toPendingPermissionRequest(message) {
    if (!message.id ||
        message.role !== 'assistant' ||
        message.actionMode !== 'permission' ||
        !message.actionInteractive ||
        !message.content) {
        return null;
    }
    const actions = message.actions?.filter((row) => row.length > 0) || [];
    if (actions.length === 0) {
        return null;
    }
    return {
        id: message.id,
        content: message.content,
        actions,
        actionReplyCtx: message.actionReplyCtx,
        actionPending: message.actionPending,
        actionStatus: message.actionStatus,
        actionMode: 'permission',
        actionInteractive: true,
    };
}
