"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.api = exports.ApiError = void 0;
const DEFAULT_API_BASE = '/api/v1';
class ApiClient {
    token = '';
    baseUrl = DEFAULT_API_BASE;
    setToken(token) {
        this.token = token;
    }
    setBaseUrl(baseUrl) {
        const trimmed = baseUrl.trim();
        if (!trimmed) {
            this.baseUrl = DEFAULT_API_BASE;
            return;
        }
        this.baseUrl = trimmed.endsWith('/api/v1')
            ? trimmed
            : `${trimmed.replace(/\/+$/, '')}/api/v1`;
    }
    getToken() {
        return this.token;
    }
    getBaseUrl() {
        return this.baseUrl;
    }
    headers() {
        const h = { 'Content-Type': 'application/json' };
        if (this.token)
            h['Authorization'] = `Bearer ${this.token}`;
        return h;
    }
    async request(method, path, body, params) {
        let url = this.resolveUrl(path);
        if (params) {
            const qs = new URLSearchParams(params).toString();
            if (qs)
                url += `?${qs}`;
        }
        const res = await fetch(url, {
            method,
            headers: this.headers(),
            body: body ? JSON.stringify(body) : undefined,
        });
        const json = await res.json();
        if (!json.ok) {
            throw new ApiError(json.error || 'Unknown error', res.status);
        }
        return json.data;
    }
    get(path, params) { return this.request('GET', path, undefined, params); }
    post(path, body) { return this.request('POST', path, body); }
    patch(path, body) { return this.request('PATCH', path, body); }
    delete(path) { return this.request('DELETE', path); }
    resolveUrl(path) {
        const normalizedPath = path.replace(/^\/+/, '');
        if (this.baseUrl.startsWith('http://') || this.baseUrl.startsWith('https://')) {
            return new URL(normalizedPath, `${this.baseUrl}/`).toString();
        }
        return `${this.baseUrl}/${normalizedPath}`.replace(/([^:]\/)\/+/g, '$1');
    }
}
class ApiError extends Error {
    status;
    constructor(message, status) {
        super(message);
        this.status = status;
        this.name = 'ApiError';
    }
}
exports.ApiError = ApiError;
exports.api = new ApiClient();
exports.default = exports.api;
