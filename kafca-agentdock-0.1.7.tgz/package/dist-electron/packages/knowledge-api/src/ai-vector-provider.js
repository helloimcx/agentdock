"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AiVectorKnowledgeProvider = void 0;
exports.defaultKnowledgeConfig = defaultKnowledgeConfig;
const sqlite_store_js_1 = require("./sqlite-store.js");
const DEFAULT_CONFIG = {
    baseUrl: '',
    authMode: 'none',
    token: '',
    headerName: 'X-API-Key',
    defaultCollection: 'personal_knowledge',
};
function clone(value) {
    return JSON.parse(JSON.stringify(value));
}
function nowIso() {
    return new Date().toISOString();
}
function randomId(prefix) {
    return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}
function normalizeConfig(input) {
    return {
        baseUrl: String(input?.baseUrl || '').trim(),
        authMode: input?.authMode === 'bearer' || input?.authMode === 'header'
            ? input.authMode
            : 'none',
        token: String(input?.token || '').trim(),
        headerName: String(input?.headerName || DEFAULT_CONFIG.headerName).trim() || DEFAULT_CONFIG.headerName,
        defaultCollection: String(input?.defaultCollection || DEFAULT_CONFIG.defaultCollection).trim() || DEFAULT_CONFIG.defaultCollection,
    };
}
function normalizeBaseUrl(baseUrl) {
    const trimmed = String(baseUrl || '').trim().replace(/\/+$/, '');
    if (!trimmed) {
        return '';
    }
    return trimmed.endsWith('/ai/vector/v1') ? trimmed : `${trimmed}/ai/vector/v1`;
}
function summarizeSnippet(text, limit = 220) {
    const normalized = text.replace(/\s+/g, ' ').trim();
    if (normalized.length <= limit) {
        return normalized;
    }
    return `${normalized.slice(0, limit).trimEnd()}...`;
}
class AiVectorKnowledgeProvider {
    store;
    getConfigValue;
    setConfigValue;
    constructor(options) {
        this.store = new sqlite_store_js_1.KnowledgeSqliteStore({ userDataPath: options.userDataPath });
        this.getConfigValue = options.getConfig;
        this.setConfigValue = options.setConfig;
    }
    async listSources() {
        const bases = await this.listKnowledgeBases();
        return bases.map((base) => ({
            id: base.id,
            name: base.name,
            type: 'knowledge-base',
            status: 'ready',
            description: base.description,
            fileCount: base.fileCount,
            wordCount: base.wordCount,
        }));
    }
    async getConfig() {
        return normalizeConfig(this.getConfigValue());
    }
    async updateConfig(input) {
        const merged = normalizeConfig({
            ...normalizeConfig(this.getConfigValue()),
            ...input,
        });
        return normalizeConfig(await this.setConfigValue(merged));
    }
    async listFolders() {
        return this.store.listFolders();
    }
    async createFolder(input) {
        const name = String(input.name || '').trim();
        if (!name) {
            throw new Error('Folder name is required.');
        }
        const folders = this.store.listFolders();
        const parent = input.parentId ? folders.find((folder) => folder.id === input.parentId) || null : null;
        if (input.parentId && !parent) {
            throw new Error('Parent folder does not exist.');
        }
        const siblings = folders.filter((folder) => folder.parentId === (input.parentId || null));
        const timestamp = nowIso();
        const nextFolder = {
            id: randomId('folder'),
            name,
            parentId: input.parentId || null,
            path: this.buildFolderPath(name, parent || null),
            sortOrder: siblings.length,
            createdAt: timestamp,
            updatedAt: timestamp,
        };
        return this.store.insertFolder(nextFolder);
    }
    async updateFolder(id, input) {
        const name = String(input.name || '').trim();
        if (!name) {
            throw new Error('Folder name is required.');
        }
        const folder = this.store.getFolder(id);
        if (!folder) {
            throw new Error('Folder does not exist.');
        }
        const parent = folder.parentId ? this.store.getFolder(folder.parentId) : null;
        const previousPath = folder.path;
        const nextPath = this.buildFolderPath(name, parent);
        return this.store.renameFolder(id, {
            name,
            previousPath,
            nextPath,
            updatedAt: nowIso(),
        });
    }
    async deleteFolder(id) {
        const hasChildren = this.store.hasFolderChildren(id);
        if (hasChildren) {
            throw new Error('Delete or move child folders before removing this folder.');
        }
        const hasBases = this.store.hasKnowledgeBasesInFolder(id);
        if (hasBases) {
            throw new Error('Delete or move knowledge bases before removing this folder.');
        }
        if (!this.store.getFolder(id)) {
            throw new Error('Folder does not exist.');
        }
        this.store.deleteFolder(id);
        return { deleted: true };
    }
    async listKnowledgeBases() {
        return this.store.listKnowledgeBases();
    }
    async getKnowledgeBase(id) {
        return this.findLocalKnowledgeBase(id);
    }
    async createKnowledgeBase(input) {
        const name = String(input.name || '').trim();
        if (!name) {
            throw new Error('Knowledge base name is required.');
        }
        if (input.folderId && !this.store.getFolder(input.folderId)) {
            throw new Error('Selected folder does not exist.');
        }
        const timestamp = nowIso();
        const nextBase = {
            id: randomId('kb'),
            name,
            description: String(input.description || '').trim(),
            folderId: input.folderId || null,
            creatorName: String(input.creatorName || '系统管理员').trim() || '系统管理员',
            icon: String(input.icon || 'book').trim() || 'book',
            fileCount: 0,
            wordCount: 0,
            createdAt: timestamp,
            updatedAt: timestamp,
        };
        return this.store.insertKnowledgeBase(nextBase);
    }
    async updateKnowledgeBase(id, input) {
        const current = this.findLocalKnowledgeBase(id);
        if (input.folderId && !this.store.getFolder(input.folderId)) {
            throw new Error('Selected folder does not exist.');
        }
        const next = {
            ...current,
            name: input.name === undefined ? current.name : String(input.name || '').trim() || current.name,
            description: input.description === undefined ? current.description : String(input.description || '').trim(),
            folderId: input.folderId === undefined ? current.folderId : input.folderId || null,
            creatorName: input.creatorName === undefined ? current.creatorName : String(input.creatorName || '').trim() || current.creatorName,
            icon: input.icon === undefined ? current.icon : String(input.icon || '').trim() || current.icon,
            updatedAt: nowIso(),
        };
        return this.store.updateKnowledgeBase(next);
    }
    async deleteKnowledgeBase(id) {
        const base = this.store.getKnowledgeBase(id);
        if (!base) {
            throw new Error('Knowledge base does not exist.');
        }
        try {
            const files = await this.listKnowledgeBaseFiles(id);
            const remoteFileIds = files.length > 0
                ? files.map((file) => file.fileId)
                : await this.discoverKnowledgeBaseFileIds(id);
            if (remoteFileIds.length > 0) {
                const config = this.requireConfigured();
                await this.aiVectorRequest('/qdrant/batchDelete', {
                    method: 'POST',
                    body: JSON.stringify({
                        collection: config.defaultCollection,
                        file_ids: remoteFileIds,
                        knowledgebase_id: id,
                    }),
                    headers: {
                        'Content-Type': 'application/json',
                    },
                });
            }
        }
        catch {
            // Best effort remote cleanup. Local metadata is still the source of truth for this module.
        }
        this.store.deleteKnowledgeBase(id);
        return { deleted: true };
    }
    async listKnowledgeBaseFiles(knowledgeBaseId) {
        this.findLocalKnowledgeBase(knowledgeBaseId);
        return this.store.listKnowledgeBaseFiles(knowledgeBaseId);
    }
    async uploadKnowledgeBaseFiles(knowledgeBaseId, request) {
        this.findLocalKnowledgeBase(knowledgeBaseId);
        this.requireConfigured();
        const response = await this.aiVectorRequest('/qdrant/file', {
            method: 'POST',
            body: request.body,
            headers: {
                'Content-Type': request.contentType,
            },
        });
        const cachedFiles = (response || [])
            .filter((item) => Boolean(item.success))
            .map((item) => this.mapFile(item));
        if (cachedFiles.length > 0) {
            this.store.upsertKnowledgeBaseFiles(cachedFiles);
            this.store.touchKnowledgeBase(knowledgeBaseId, nowIso());
        }
        return (response || []).map((item) => ({
            fileId: String(item.file_id || ''),
            fileName: String(item.file_name || ''),
            fileType: String(item.file_type || ''),
            success: Boolean(item.success),
            message: String(item.msg || (item.success ? 'success' : 'Upload failed')),
            wordCount: typeof item.word_count === 'number' ? item.word_count : null,
        }));
    }
    async deleteKnowledgeBaseFile(knowledgeBaseId, fileId) {
        this.findLocalKnowledgeBase(knowledgeBaseId);
        const config = this.requireConfigured();
        const response = await this.aiVectorRequest('/qdrant/delete', {
            method: 'POST',
            body: JSON.stringify({
                collection: config.defaultCollection,
                file_id: fileId,
                knowledgebase_id: knowledgeBaseId,
            }),
            headers: {
                'Content-Type': 'application/json',
            },
        });
        const deleted = Boolean(response?.success);
        if (deleted) {
            this.store.deleteKnowledgeBaseFile(fileId);
            this.store.touchKnowledgeBase(knowledgeBaseId, nowIso());
        }
        return { deleted };
    }
    async searchKnowledgeBase(knowledgeBaseId, input) {
        const base = this.findLocalKnowledgeBase(knowledgeBaseId);
        const config = this.requireConfigured();
        const response = await this.aiVectorRequest('/qdrant/query', {
            method: 'POST',
            body: JSON.stringify({
                collection: config.defaultCollection,
                query: String(input.query || '').trim(),
                knowledgebase_id: knowledgeBaseId,
                limit: Math.max(1, Number(input.limit || 8)),
            }),
            headers: {
                'Content-Type': 'application/json',
            },
        });
        return (response?.documents || []).map((item) => {
            const metadata = item.metadata || {};
            const content = String(metadata.document || '');
            return {
                id: String(item.id || randomId('result')),
                knowledgeBaseId,
                fileId: String(metadata.file_id || ''),
                fileName: String(metadata.file_name || '未命名文件'),
                title: `${base.name} · ${String(metadata.file_name || '搜索结果')}`,
                snippet: summarizeSnippet(content),
                score: Number(item.score || 0),
                chunkOffset: Number(metadata.chunk_offset || 0),
                content,
            };
        });
    }
    buildFolderPath(name, parent) {
        return parent ? `${parent.path}/${name}` : name;
    }
    findLocalKnowledgeBase(id) {
        const base = this.store.getKnowledgeBase(id);
        if (!base) {
            throw new Error('Knowledge base does not exist.');
        }
        return clone(base);
    }
    requireConfigured() {
        const config = normalizeConfig(this.getConfigValue());
        if (!config.baseUrl) {
            throw new Error('Knowledge service is not configured. Set the ai_vector base URL in Workspace settings.');
        }
        return config;
    }
    mapFile(file) {
        return {
            knowledgebaseId: file.knowledgebase_id || null,
            fileId: String(file.file_id || ''),
            fileName: String(file.file_name || ''),
            fileType: String(file.file_type || ''),
            fileSize: Number(file.file_size || 0),
            folder: file.folder || null,
            createTime: String(file.create_time || ''),
            wordCount: typeof file.word_count === 'number' ? file.word_count : null,
            metadata: file.metadata || null,
            abstract: file.abstract || null,
            fullContent: file.full_content || null,
        };
    }
    async discoverKnowledgeBaseFileIds(knowledgeBaseId) {
        const config = this.requireConfigured();
        const response = await this.aiVectorRequest('/qdrant/query', {
            method: 'POST',
            body: JSON.stringify({
                collection: config.defaultCollection,
                query: '*',
                knowledgebase_id: knowledgeBaseId,
                limit: 200,
            }),
            headers: {
                'Content-Type': 'application/json',
            },
        });
        return Array.from(new Set((response?.documents || [])
            .map((item) => String(item.metadata?.file_id || '').trim())
            .filter(Boolean)));
    }
    async aiVectorRequest(path, init) {
        const config = this.requireConfigured();
        const baseUrl = normalizeBaseUrl(config.baseUrl);
        const headers = {
            ...(init.headers || {}),
            ...this.buildAuthHeaders(config),
        };
        const response = await fetch(`${baseUrl}${path}`, {
            method: init.method,
            headers,
            body: init.body,
        });
        const text = await response.text();
        const payload = text ? JSON.parse(text) : null;
        if (!response.ok) {
            if (payload && typeof payload === 'object' && 'resultMsg' in payload) {
                throw new Error(String(payload.resultMsg || `ai_vector request failed: ${response.status}`));
            }
            throw new Error(`ai_vector request failed: ${response.status}`);
        }
        if (payload && typeof payload === 'object' && ('resultCode' in payload || 'resultMsg' in payload || 'data' in payload)) {
            const envelope = payload;
            if (Number(envelope.resultCode || 0) !== 0) {
                throw new Error(String(envelope.resultMsg || `ai_vector request failed: ${response.status}`));
            }
            return envelope.data;
        }
        return payload;
    }
    buildAuthHeaders(config) {
        if (config.authMode === 'bearer' && config.token) {
            return { Authorization: `Bearer ${config.token}` };
        }
        if (config.authMode === 'header' && config.token) {
            return { [config.headerName || DEFAULT_CONFIG.headerName]: config.token };
        }
        return {};
    }
}
exports.AiVectorKnowledgeProvider = AiVectorKnowledgeProvider;
function defaultKnowledgeConfig() {
    return clone(DEFAULT_CONFIG);
}
