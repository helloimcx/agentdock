"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.KnowledgeSqliteStore = void 0;
const node_fs_1 = require("node:fs");
const node_path_1 = require("node:path");
const node_sqlite_1 = require("node:sqlite");
const SCHEMA_VERSION = '2';
function clone(value) {
    return JSON.parse(JSON.stringify(value));
}
function parseMetadata(raw) {
    if (!raw) {
        return null;
    }
    try {
        const parsed = JSON.parse(raw);
        return parsed && typeof parsed === 'object' ? parsed : null;
    }
    catch {
        return null;
    }
}
function cleanupDatabaseFiles(dbPath) {
    (0, node_fs_1.rmSync)(dbPath, { force: true });
    (0, node_fs_1.rmSync)(`${dbPath}-shm`, { force: true });
    (0, node_fs_1.rmSync)(`${dbPath}-wal`, { force: true });
}
class KnowledgeSqliteStore {
    dbPath;
    legacyStorePath;
    legacyBackupPath;
    db;
    constructor(options) {
        this.dbPath = (0, node_path_1.join)(options.userDataPath, 'runtime', 'knowledge.db');
        this.legacyStorePath = (0, node_path_1.join)(options.userDataPath, 'runtime', 'knowledge-store.json');
        this.legacyBackupPath = `${this.legacyStorePath}.bak`;
        (0, node_fs_1.mkdirSync)((0, node_path_1.dirname)(this.dbPath), { recursive: true });
        const shouldMigrate = !(0, node_fs_1.existsSync)(this.dbPath) && (0, node_fs_1.existsSync)(this.legacyStorePath);
        this.db = new node_sqlite_1.DatabaseSync(this.dbPath);
        try {
            this.initializeSchema();
            if (shouldMigrate) {
                this.migrateLegacyJson();
            }
        }
        catch (error) {
            this.db.close();
            if (shouldMigrate) {
                cleanupDatabaseFiles(this.dbPath);
            }
            throw error;
        }
    }
    close() {
        this.db.close();
    }
    listFolders() {
        const rows = this.db.prepare(`
      SELECT id, name, parent_id, path, sort_order, created_at, updated_at
      FROM knowledge_folders
      ORDER BY path ASC, sort_order ASC
    `).all();
        return rows.map((row) => this.mapFolder(row));
    }
    getFolder(id) {
        const row = this.db.prepare(`
      SELECT id, name, parent_id, path, sort_order, created_at, updated_at
      FROM knowledge_folders
      WHERE id = ?
      LIMIT 1
    `).get(id);
        return row ? this.mapFolder(row) : null;
    }
    insertFolder(folder) {
        this.db.prepare(`
      INSERT INTO knowledge_folders (
        id, name, parent_id, path, sort_order, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(folder.id, folder.name, folder.parentId, folder.path, folder.sortOrder, folder.createdAt, folder.updatedAt);
        return clone(folder);
    }
    renameFolder(id, input) {
        this.transaction(() => {
            const updateResult = this.db.prepare(`
        UPDATE knowledge_folders
        SET name = ?, path = ?, updated_at = ?
        WHERE id = ?
      `).run(input.name, input.nextPath, input.updatedAt, id);
            if (Number(updateResult.changes || 0) === 0) {
                throw new Error('Folder does not exist.');
            }
            this.db.prepare(`
        UPDATE knowledge_folders
        SET path = replace(path, ?, ?), updated_at = ?
        WHERE id <> ? AND path LIKE ?
      `).run(input.previousPath, input.nextPath, input.updatedAt, id, `${input.previousPath}/%`);
        });
        const folder = this.getFolder(id);
        if (!folder) {
            throw new Error('Folder does not exist.');
        }
        return folder;
    }
    deleteFolder(id) {
        this.db.prepare('DELETE FROM knowledge_folders WHERE id = ?').run(id);
    }
    listKnowledgeBases() {
        const rows = this.db.prepare(`
      SELECT
        bases.id,
        bases.name,
        bases.description,
        bases.folder_id,
        bases.creator_name,
        bases.icon,
        bases.created_at,
        bases.updated_at,
        COALESCE(stats.file_count, 0) AS file_count,
        COALESCE(stats.word_count, 0) AS word_count
      FROM knowledge_bases AS bases
      LEFT JOIN (
        SELECT
          knowledgebase_id,
          COUNT(*) AS file_count,
          COALESCE(SUM(COALESCE(word_count, 0)), 0) AS word_count
        FROM knowledge_files
        GROUP BY knowledgebase_id
      ) AS stats ON stats.knowledgebase_id = bases.id
      ORDER BY bases.updated_at DESC
    `).all();
        return rows.map((row) => this.mapKnowledgeBase(row));
    }
    getKnowledgeBase(id) {
        const row = this.db.prepare(`
      SELECT
        bases.id,
        bases.name,
        bases.description,
        bases.folder_id,
        bases.creator_name,
        bases.icon,
        bases.created_at,
        bases.updated_at,
        COALESCE(stats.file_count, 0) AS file_count,
        COALESCE(stats.word_count, 0) AS word_count
      FROM knowledge_bases AS bases
      LEFT JOIN (
        SELECT
          knowledgebase_id,
          COUNT(*) AS file_count,
          COALESCE(SUM(COALESCE(word_count, 0)), 0) AS word_count
        FROM knowledge_files
        GROUP BY knowledgebase_id
      ) AS stats ON stats.knowledgebase_id = bases.id
      WHERE bases.id = ?
      LIMIT 1
    `).get(id);
        return row ? this.mapKnowledgeBase(row) : null;
    }
    insertKnowledgeBase(base) {
        this.db.prepare(`
      INSERT INTO knowledge_bases (
        id, name, description, folder_id, creator_name, icon, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(base.id, base.name, base.description, base.folderId, base.creatorName, base.icon, base.createdAt, base.updatedAt);
        return clone(base);
    }
    updateKnowledgeBase(base) {
        const result = this.db.prepare(`
      UPDATE knowledge_bases
      SET name = ?, description = ?, folder_id = ?, creator_name = ?, icon = ?, updated_at = ?
      WHERE id = ?
    `).run(base.name, base.description, base.folderId, base.creatorName, base.icon, base.updatedAt, base.id);
        if (Number(result.changes || 0) === 0) {
            throw new Error('Knowledge base does not exist.');
        }
        return this.getKnowledgeBase(base.id) || clone(base);
    }
    touchKnowledgeBase(id, updatedAt) {
        this.db.prepare('UPDATE knowledge_bases SET updated_at = ? WHERE id = ?').run(updatedAt, id);
    }
    deleteKnowledgeBase(id) {
        this.transaction(() => {
            this.db.prepare('DELETE FROM thread_knowledge_bases WHERE knowledge_base_id = ?').run(id);
            this.db.prepare('DELETE FROM knowledge_files WHERE knowledgebase_id = ?').run(id);
            this.db.prepare('DELETE FROM knowledge_bases WHERE id = ?').run(id);
        });
    }
    listKnowledgeBaseFiles(knowledgeBaseId) {
        const rows = this.db.prepare(`
      SELECT
        knowledgebase_id,
        file_id,
        file_name,
        file_type,
        file_size,
        folder,
        create_time,
        word_count,
        metadata_json,
        abstract,
        full_content,
        updated_at
      FROM knowledge_files
      WHERE knowledgebase_id = ?
      ORDER BY create_time DESC, file_name COLLATE NOCASE ASC
    `).all(knowledgeBaseId);
        return rows.map((row) => this.mapKnowledgeFile(row));
    }
    upsertKnowledgeBaseFiles(files) {
        if (files.length === 0) {
            return;
        }
        const statement = this.db.prepare(`
      INSERT INTO knowledge_files (
        knowledgebase_id,
        file_id,
        file_name,
        file_type,
        file_size,
        folder,
        create_time,
        word_count,
        metadata_json,
        abstract,
        full_content,
        updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(file_id) DO UPDATE SET
        knowledgebase_id = excluded.knowledgebase_id,
        file_name = excluded.file_name,
        file_type = excluded.file_type,
        file_size = excluded.file_size,
        folder = excluded.folder,
        create_time = excluded.create_time,
        word_count = excluded.word_count,
        metadata_json = excluded.metadata_json,
        abstract = excluded.abstract,
        full_content = excluded.full_content,
        updated_at = excluded.updated_at
    `);
        this.transaction(() => {
            files.forEach((file) => {
                statement.run(file.knowledgebaseId || null, file.fileId, file.fileName, file.fileType, file.fileSize, file.folder || null, file.createTime, file.wordCount ?? null, file.metadata ? JSON.stringify(file.metadata) : null, file.abstract || null, file.fullContent || null, new Date().toISOString());
            });
        });
    }
    deleteKnowledgeBaseFile(fileId) {
        this.db.prepare('DELETE FROM knowledge_files WHERE file_id = ?').run(fileId);
    }
    listThreadKnowledgeBaseIds(threadId) {
        const rows = this.db.prepare(`
      SELECT thread_id, knowledge_base_id, created_at
      FROM thread_knowledge_bases
      WHERE thread_id = ?
      ORDER BY created_at ASC, rowid ASC
    `).all(threadId);
        return rows.map((row) => row.knowledge_base_id);
    }
    replaceThreadKnowledgeBaseIds(threadId, knowledgeBaseIds) {
        const uniqueIds = Array.from(new Set(knowledgeBaseIds.map((id) => String(id || '').trim()).filter(Boolean)));
        const missingId = uniqueIds.find((knowledgeBaseId) => !this.getKnowledgeBase(knowledgeBaseId));
        if (missingId) {
            throw new Error(`Knowledge base does not exist: ${missingId}`);
        }
        this.transaction(() => {
            this.db.prepare('DELETE FROM thread_knowledge_bases WHERE thread_id = ?').run(threadId);
            if (uniqueIds.length === 0) {
                return;
            }
            const insertStatement = this.db.prepare(`
        INSERT INTO thread_knowledge_bases (
          thread_id,
          knowledge_base_id,
          created_at
        ) VALUES (?, ?, ?)
      `);
            uniqueIds.forEach((knowledgeBaseId) => {
                insertStatement.run(threadId, knowledgeBaseId, new Date().toISOString());
            });
        });
        return uniqueIds;
    }
    deleteThreadKnowledgeBaseLinks(threadId) {
        this.db.prepare('DELETE FROM thread_knowledge_bases WHERE thread_id = ?').run(threadId);
    }
    hasFolderChildren(id) {
        const row = this.db.prepare(`
      SELECT 1 AS value
      FROM knowledge_folders
      WHERE parent_id = ?
      LIMIT 1
    `).get(id);
        return Boolean(row?.value);
    }
    hasKnowledgeBasesInFolder(id) {
        const row = this.db.prepare(`
      SELECT 1 AS value
      FROM knowledge_bases
      WHERE folder_id = ?
      LIMIT 1
    `).get(id);
        return Boolean(row?.value);
    }
    runInTransaction(callback) {
        return this.transaction(callback);
    }
    initializeSchema() {
        this.db.exec('PRAGMA foreign_keys = ON;');
        this.db.exec(`
      CREATE TABLE IF NOT EXISTS meta (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS knowledge_folders (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        parent_id TEXT,
        path TEXT NOT NULL,
        sort_order INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS knowledge_bases (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT NOT NULL DEFAULT '',
        folder_id TEXT,
        creator_name TEXT NOT NULL,
        icon TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS knowledge_files (
        file_id TEXT PRIMARY KEY,
        knowledgebase_id TEXT,
        file_name TEXT NOT NULL,
        file_type TEXT NOT NULL,
        file_size INTEGER NOT NULL DEFAULT 0,
        folder TEXT,
        create_time TEXT NOT NULL,
        word_count INTEGER,
        metadata_json TEXT,
        abstract TEXT,
        full_content TEXT,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS thread_knowledge_bases (
        thread_id TEXT NOT NULL,
        knowledge_base_id TEXT NOT NULL,
        created_at TEXT NOT NULL,
        PRIMARY KEY (thread_id, knowledge_base_id)
      );

      CREATE INDEX IF NOT EXISTS idx_knowledge_folders_parent_id
        ON knowledge_folders (parent_id);
      CREATE INDEX IF NOT EXISTS idx_knowledge_bases_folder_id
        ON knowledge_bases (folder_id);
      CREATE INDEX IF NOT EXISTS idx_knowledge_files_knowledgebase_id
        ON knowledge_files (knowledgebase_id);
      CREATE INDEX IF NOT EXISTS idx_knowledge_files_create_time
        ON knowledge_files (create_time DESC);
      CREATE INDEX IF NOT EXISTS idx_thread_knowledge_bases_thread_id
        ON thread_knowledge_bases (thread_id);
    `);
        this.db.prepare(`
      INSERT INTO meta (key, value)
      VALUES ('schema_version', ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value
    `).run(SCHEMA_VERSION);
    }
    migrateLegacyJson() {
        if (!(0, node_fs_1.existsSync)(this.legacyStorePath)) {
            return;
        }
        if ((0, node_fs_1.existsSync)(this.legacyBackupPath)) {
            (0, node_fs_1.unlinkSync)(this.legacyBackupPath);
        }
        (0, node_fs_1.renameSync)(this.legacyStorePath, this.legacyBackupPath);
        try {
            const raw = JSON.parse((0, node_fs_1.readFileSync)(this.legacyBackupPath, 'utf8'));
            const folders = Array.isArray(raw.folders) ? raw.folders : [];
            const knowledgeBases = Array.isArray(raw.knowledgeBases) ? raw.knowledgeBases : [];
            this.transaction(() => {
                const insertFolder = this.db.prepare(`
          INSERT INTO knowledge_folders (
            id, name, parent_id, path, sort_order, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?)
        `);
                const insertKnowledgeBase = this.db.prepare(`
          INSERT INTO knowledge_bases (
            id, name, description, folder_id, creator_name, icon, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `);
                folders.forEach((folder) => {
                    insertFolder.run(folder.id, folder.name, folder.parentId || null, folder.path, folder.sortOrder, folder.createdAt, folder.updatedAt);
                });
                knowledgeBases.forEach((base) => {
                    insertKnowledgeBase.run(base.id, base.name, base.description, base.folderId || null, base.creatorName, base.icon, base.createdAt, base.updatedAt);
                });
            });
        }
        catch (error) {
            if ((0, node_fs_1.existsSync)(this.legacyBackupPath) && !(0, node_fs_1.existsSync)(this.legacyStorePath)) {
                (0, node_fs_1.renameSync)(this.legacyBackupPath, this.legacyStorePath);
            }
            throw error;
        }
    }
    transaction(callback) {
        this.db.exec('BEGIN IMMEDIATE');
        try {
            const result = callback();
            this.db.exec('COMMIT');
            return result;
        }
        catch (error) {
            this.db.exec('ROLLBACK');
            throw error;
        }
    }
    mapFolder(row) {
        return {
            id: row.id,
            name: row.name,
            parentId: row.parent_id,
            path: row.path,
            sortOrder: Number(row.sort_order || 0),
            createdAt: row.created_at,
            updatedAt: row.updated_at,
        };
    }
    mapKnowledgeBase(row) {
        return {
            id: row.id,
            name: row.name,
            description: row.description,
            folderId: row.folder_id,
            creatorName: row.creator_name,
            icon: row.icon,
            fileCount: Number(row.file_count || 0),
            wordCount: Number(row.word_count || 0),
            createdAt: row.created_at,
            updatedAt: row.updated_at,
        };
    }
    mapKnowledgeFile(row) {
        return {
            knowledgebaseId: row.knowledgebase_id,
            fileId: row.file_id,
            fileName: row.file_name,
            fileType: row.file_type,
            fileSize: Number(row.file_size || 0),
            folder: row.folder,
            createTime: row.create_time,
            wordCount: typeof row.word_count === 'number' ? row.word_count : null,
            metadata: parseMetadata(row.metadata_json),
            abstract: row.abstract,
            fullContent: row.full_content,
        };
    }
}
exports.KnowledgeSqliteStore = KnowledgeSqliteStore;
