"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SqliteThreadKnowledgeAttachmentStore = void 0;
const sqlite_store_js_1 = require("./sqlite-store.js");
class SqliteThreadKnowledgeAttachmentStore {
    store;
    constructor(options) {
        this.store = new sqlite_store_js_1.KnowledgeSqliteStore({ userDataPath: options.userDataPath });
    }
    async listThreadKnowledgeBaseIds(threadId) {
        return this.store.listThreadKnowledgeBaseIds(threadId);
    }
    async updateThreadKnowledgeBaseIds(threadId, knowledgeBaseIds) {
        return this.store.replaceThreadKnowledgeBaseIds(threadId, knowledgeBaseIds);
    }
    async deleteThreadKnowledgeBaseLinks(threadId) {
        this.store.deleteThreadKnowledgeBaseLinks(threadId);
        return { deleted: true };
    }
}
exports.SqliteThreadKnowledgeAttachmentStore = SqliteThreadKnowledgeAttachmentStore;
