"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.defaultKnowledgeConfig = exports.SqliteThreadKnowledgeAttachmentStore = exports.AiVectorKnowledgeProvider = exports.NoopKnowledgeProvider = exports.NoopThreadKnowledgeAttachmentStore = void 0;
exports.createAiVectorKnowledgePlugin = createAiVectorKnowledgePlugin;
exports.createNoopKnowledgePlugin = createNoopKnowledgePlugin;
const ai_vector_provider_js_1 = require("./ai-vector-provider.js");
Object.defineProperty(exports, "AiVectorKnowledgeProvider", { enumerable: true, get: function () { return ai_vector_provider_js_1.AiVectorKnowledgeProvider; } });
Object.defineProperty(exports, "defaultKnowledgeConfig", { enumerable: true, get: function () { return ai_vector_provider_js_1.defaultKnowledgeConfig; } });
const thread_knowledge_store_js_1 = require("./thread-knowledge-store.js");
Object.defineProperty(exports, "SqliteThreadKnowledgeAttachmentStore", { enumerable: true, get: function () { return thread_knowledge_store_js_1.SqliteThreadKnowledgeAttachmentStore; } });
class NoopThreadKnowledgeAttachmentStore {
    async listThreadKnowledgeBaseIds() {
        return [];
    }
    async updateThreadKnowledgeBaseIds() {
        return [];
    }
    async deleteThreadKnowledgeBaseLinks() {
        return { deleted: true };
    }
}
exports.NoopThreadKnowledgeAttachmentStore = NoopThreadKnowledgeAttachmentStore;
class NoopKnowledgeProvider {
    async listSources() {
        return [];
    }
    async getConfig() {
        return (0, ai_vector_provider_js_1.defaultKnowledgeConfig)();
    }
    async updateConfig() {
        return (0, ai_vector_provider_js_1.defaultKnowledgeConfig)();
    }
    async listFolders() {
        return [];
    }
    async createFolder(_input) {
        throw new Error('Knowledge provider is unavailable.');
    }
    async updateFolder(_id, _input) {
        throw new Error('Knowledge provider is unavailable.');
    }
    async deleteFolder(_id) {
        throw new Error('Knowledge provider is unavailable.');
    }
    async listKnowledgeBases() {
        return [];
    }
    async getKnowledgeBase(_id) {
        throw new Error('Knowledge provider is unavailable.');
    }
    async createKnowledgeBase(_input) {
        throw new Error('Knowledge provider is unavailable.');
    }
    async updateKnowledgeBase(_id, _input) {
        throw new Error('Knowledge provider is unavailable.');
    }
    async deleteKnowledgeBase(_id) {
        throw new Error('Knowledge provider is unavailable.');
    }
    async listKnowledgeBaseFiles(_knowledgeBaseId) {
        return [];
    }
    async uploadKnowledgeBaseFiles(_knowledgeBaseId, _request) {
        throw new Error('Knowledge provider is unavailable.');
    }
    async deleteKnowledgeBaseFile(_knowledgeBaseId, _fileId) {
        throw new Error('Knowledge provider is unavailable.');
    }
    async searchKnowledgeBase(_knowledgeBaseId, _input) {
        return [];
    }
}
exports.NoopKnowledgeProvider = NoopKnowledgeProvider;
function createAiVectorKnowledgePlugin(options) {
    let provider = null;
    let attachments = null;
    return {
        manifest: {
            id: 'knowledge.ai-vector',
            kind: 'knowledge',
            version: '0.1.0',
            provides: ['knowledge:ai-vector'],
            configSchema: {
                fields: [
                    { key: 'baseUrl', type: 'string', label: 'Base URL' },
                    { key: 'authMode', type: 'string', label: 'Auth mode', defaultValue: 'none' },
                    { key: 'defaultCollection', type: 'string', label: 'Default collection' },
                ],
            },
        },
        capabilities: {
            knowledge: [
                {
                    id: 'knowledge.ai-vector',
                    sourceType: 'ai-vector',
                    enabled: true,
                    displayName: 'AI Vector Knowledge',
                },
            ],
        },
        createRuntime(_ctx) {
            provider ??= new ai_vector_provider_js_1.AiVectorKnowledgeProvider({
                userDataPath: options.userDataPath,
                getConfig: options.getConfig,
                setConfig: options.setConfig,
            });
            attachments ??= new thread_knowledge_store_js_1.SqliteThreadKnowledgeAttachmentStore({
                userDataPath: options.userDataPath,
            });
            return { provider, attachments };
        },
        healthCheck() {
            return { status: 'healthy' };
        },
    };
}
function createNoopKnowledgePlugin() {
    let provider = null;
    let attachments = null;
    return {
        manifest: {
            id: 'knowledge.noop',
            kind: 'knowledge',
            version: '0.1.0',
            provides: ['knowledge:noop'],
        },
        capabilities: {
            knowledge: [
                {
                    id: 'knowledge.noop',
                    sourceType: 'noop',
                    enabled: false,
                    displayName: 'Disabled Knowledge',
                },
            ],
        },
        createRuntime(_ctx) {
            provider ??= new NoopKnowledgeProvider();
            attachments ??= new NoopThreadKnowledgeAttachmentStore();
            return { provider, attachments };
        },
        healthCheck() {
            return { status: 'healthy' };
        },
    };
}
