"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_test_1 = __importDefault(require("node:test"));
const strict_1 = __importDefault(require("node:assert/strict"));
const node_fs_1 = require("node:fs");
const node_fs_2 = require("node:fs");
const node_os_1 = require("node:os");
const node_path_1 = require("node:path");
const index_js_1 = require("../src/index.js");
const sqlite_store_js_1 = require("../src/sqlite-store.js");
function withTempDir() {
    const dir = (0, node_fs_2.mkdtempSync)((0, node_path_1.join)((0, node_os_1.tmpdir)(), 'agentdock-kb-'));
    return {
        dir,
        cleanup() {
            (0, node_fs_1.rmSync)(dir, { recursive: true, force: true });
        },
    };
}
(0, node_test_1.default)('migrates legacy knowledge-store.json into sqlite and keeps a backup', () => {
    const temp = withTempDir();
    try {
        const runtimeDir = (0, node_path_1.join)(temp.dir, 'runtime');
        (0, node_fs_1.mkdirSync)(runtimeDir, { recursive: true });
        (0, node_fs_1.writeFileSync)((0, node_path_1.join)(runtimeDir, 'knowledge-store.json'), JSON.stringify({
            folders: [
                {
                    id: 'folder-1',
                    name: '运营',
                    parentId: null,
                    path: '运营',
                    sortOrder: 0,
                    createdAt: '2026-01-01T00:00:00.000Z',
                    updatedAt: '2026-01-01T00:00:00.000Z',
                },
            ],
            knowledgeBases: [
                {
                    id: 'kb-1',
                    name: '运营知识库',
                    description: 'desc',
                    folderId: 'folder-1',
                    creatorName: '系统管理员',
                    icon: 'book',
                    fileCount: 0,
                    wordCount: 0,
                    createdAt: '2026-01-01T00:00:00.000Z',
                    updatedAt: '2026-01-01T00:00:00.000Z',
                },
            ],
        }), 'utf8');
        const store = new sqlite_store_js_1.KnowledgeSqliteStore({ userDataPath: temp.dir });
        try {
            strict_1.default.equal(store.listFolders().length, 1);
            strict_1.default.equal(store.listKnowledgeBases().length, 1);
            strict_1.default.equal(store.getKnowledgeBase('kb-1')?.name, '运营知识库');
            strict_1.default.equal((0, node_fs_1.existsSync)((0, node_path_1.join)(runtimeDir, 'knowledge-store.json')), false);
            strict_1.default.equal((0, node_fs_1.existsSync)((0, node_path_1.join)(runtimeDir, 'knowledge-store.json.bak')), true);
            strict_1.default.equal((0, node_fs_1.existsSync)((0, node_path_1.join)(runtimeDir, 'knowledge.db')), true);
        }
        finally {
            store.close();
        }
    }
    finally {
        temp.cleanup();
    }
});
(0, node_test_1.default)('uses uploaded file cache when remote list is empty', async () => {
    const temp = withTempDir();
    const config = {
        ...(0, index_js_1.defaultKnowledgeConfig)(),
        baseUrl: 'http://vector.example.com',
    };
    let knowledgeBaseId = '';
    const provider = new index_js_1.AiVectorKnowledgeProvider({
        userDataPath: temp.dir,
        getConfig: () => config,
        setConfig: (input) => ({ ...config, ...input }),
    });
    const originalFetch = globalThis.fetch;
    globalThis.fetch = (async (input) => {
        const url = String(input);
        if (url.endsWith('/qdrant/file')) {
            return new Response(JSON.stringify({
                resultCode: 0,
                resultMsg: 'success',
                data: [
                    {
                        knowledgebase_id: knowledgeBaseId,
                        file_id: 'file-1',
                        file_name: 'doc.md',
                        file_type: 'md',
                        file_size: 12,
                        folder: null,
                        create_time: '2026-01-02T00:00:00.000Z',
                        word_count: 5,
                        metadata: { source: 'upload' },
                        abstract: 'summary',
                        full_content: 'hello world',
                        success: true,
                    },
                ],
            }));
        }
        throw new Error(`Unexpected fetch URL: ${url}`);
    });
    try {
        const base = await provider.createKnowledgeBase({
            name: '运营知识库',
            description: 'desc',
        });
        knowledgeBaseId = base.id;
        const upload = await provider.uploadKnowledgeBaseFiles(knowledgeBaseId, {
            contentType: 'multipart/form-data; boundary=test',
            body: new Uint8Array([1, 2, 3]),
        });
        const files = await provider.listKnowledgeBaseFiles(knowledgeBaseId);
        const nextBase = await provider.getKnowledgeBase(knowledgeBaseId);
        strict_1.default.equal(upload.length, 1);
        strict_1.default.equal(files.length, 1);
        strict_1.default.equal(files[0]?.fileId, 'file-1');
        strict_1.default.equal(files[0]?.wordCount, 5);
        strict_1.default.equal(nextBase.fileCount, 1);
        strict_1.default.equal(nextBase.wordCount, 5);
    }
    finally {
        globalThis.fetch = originalFetch;
        temp.cleanup();
    }
});
(0, node_test_1.default)('reads file lists and stats from sqlite without calling remote list', async () => {
    const temp = withTempDir();
    const config = {
        ...(0, index_js_1.defaultKnowledgeConfig)(),
        baseUrl: 'http://vector.example.com',
    };
    let knowledgeBaseId = '';
    const provider = new index_js_1.AiVectorKnowledgeProvider({
        userDataPath: temp.dir,
        getConfig: () => config,
        setConfig: (input) => ({ ...config, ...input }),
    });
    const originalFetch = globalThis.fetch;
    globalThis.fetch = (async (input) => {
        const url = String(input);
        if (url.endsWith('/qdrant/file')) {
            return new Response(JSON.stringify({
                resultCode: 0,
                resultMsg: 'success',
                data: [
                    {
                        knowledgebase_id: knowledgeBaseId,
                        file_id: 'file-1',
                        file_name: 'doc.md',
                        file_type: 'md',
                        file_size: 12,
                        folder: null,
                        create_time: '2026-01-02T00:00:00.000Z',
                        word_count: 5,
                        metadata: null,
                        abstract: null,
                        full_content: 'hello world',
                        success: true,
                    },
                ],
            }));
        }
        throw new Error(`Unexpected fetch URL: ${url}`);
    });
    try {
        const base = await provider.createKnowledgeBase({
            name: '运营知识库',
            description: 'desc',
        });
        knowledgeBaseId = base.id;
        await provider.uploadKnowledgeBaseFiles(knowledgeBaseId, {
            contentType: 'multipart/form-data; boundary=test',
            body: new Uint8Array([1, 2, 3]),
        });
        globalThis.fetch = (async (input) => {
            throw new Error(`No remote read expected: ${String(input)}`);
        });
        const files = await provider.listKnowledgeBaseFiles(knowledgeBaseId);
        const nextBase = await provider.getKnowledgeBase(knowledgeBaseId);
        const bases = await provider.listKnowledgeBases();
        strict_1.default.equal(files.length, 1);
        strict_1.default.equal(files[0]?.fileId, 'file-1');
        strict_1.default.equal(nextBase.fileCount, 1);
        strict_1.default.equal(nextBase.wordCount, 5);
        strict_1.default.equal(bases[0]?.fileCount, 1);
        strict_1.default.equal(bases[0]?.wordCount, 5);
    }
    finally {
        globalThis.fetch = originalFetch;
        temp.cleanup();
    }
});
(0, node_test_1.default)('supports raw ai_vector search responses without envelope', async () => {
    const temp = withTempDir();
    const config = {
        ...(0, index_js_1.defaultKnowledgeConfig)(),
        baseUrl: 'http://vector.example.com',
    };
    const provider = new index_js_1.AiVectorKnowledgeProvider({
        userDataPath: temp.dir,
        getConfig: () => config,
        setConfig: (input) => ({ ...config, ...input }),
    });
    const originalFetch = globalThis.fetch;
    globalThis.fetch = (async (input) => {
        const url = String(input);
        if (url.endsWith('/qdrant/query')) {
            return new Response(JSON.stringify({
                intent: 'CHAT',
                documents: [
                    {
                        id: 'result-1',
                        score: 0.9,
                        metadata: {
                            file_id: 'file-1',
                            file_name: 'doc.md',
                            document: 'hello knowledge',
                            chunk_offset: 2,
                        },
                    },
                ],
            }));
        }
        throw new Error(`Unexpected fetch URL: ${url}`);
    });
    try {
        const base = await provider.createKnowledgeBase({
            name: '运营知识库',
            description: 'desc',
        });
        const results = await provider.searchKnowledgeBase(base.id, { query: 'hello', limit: 3 });
        strict_1.default.equal(results.length, 1);
        strict_1.default.equal(results[0]?.fileId, 'file-1');
        strict_1.default.equal(results[0]?.chunkOffset, 2);
        strict_1.default.equal(results[0]?.title, '运营知识库 · doc.md');
        strict_1.default.match(results[0]?.snippet || '', /hello knowledge/);
    }
    finally {
        globalThis.fetch = originalFetch;
        temp.cleanup();
    }
});
(0, node_test_1.default)('stores selected knowledge-base bindings per thread in sqlite', async () => {
    const temp = withTempDir();
    const provider = new index_js_1.AiVectorKnowledgeProvider({
        userDataPath: temp.dir,
        getConfig: () => (0, index_js_1.defaultKnowledgeConfig)(),
        setConfig: (input) => ({ ...(0, index_js_1.defaultKnowledgeConfig)(), ...input }),
    });
    const attachments = new index_js_1.SqliteThreadKnowledgeAttachmentStore({
        userDataPath: temp.dir,
    });
    try {
        const firstBase = await provider.createKnowledgeBase({ name: '知识库 A' });
        const secondBase = await provider.createKnowledgeBase({ name: '知识库 B' });
        const storedIds = await attachments.updateThreadKnowledgeBaseIds('thread-1', [
            firstBase.id,
            secondBase.id,
            firstBase.id,
        ]);
        strict_1.default.deepEqual(storedIds, [firstBase.id, secondBase.id]);
        strict_1.default.deepEqual(await attachments.listThreadKnowledgeBaseIds('thread-1'), [firstBase.id, secondBase.id]);
        await attachments.deleteThreadKnowledgeBaseLinks('thread-1');
        strict_1.default.deepEqual(await attachments.listThreadKnowledgeBaseIds('thread-1'), []);
    }
    finally {
        temp.cleanup();
    }
});
(0, node_test_1.default)('ai-vector knowledge plugin creates provider runtime and registers enabled capability', async () => {
    const temp = withTempDir();
    try {
        const plugin = (0, index_js_1.createAiVectorKnowledgePlugin)({
            userDataPath: temp.dir,
            getConfig: () => (0, index_js_1.defaultKnowledgeConfig)(),
            setConfig: (input) => ({ ...(0, index_js_1.defaultKnowledgeConfig)(), ...input }),
        });
        strict_1.default.equal(plugin.manifest.id, 'knowledge.ai-vector');
        strict_1.default.equal(plugin.capabilities?.knowledge?.[0]?.enabled, true);
        const runtime = await plugin.createRuntime?.({
            bus: { emit() { }, on() { return () => { }; } },
            capabilities: {
                registerAgent() { },
                registerChannel() { },
                registerKnowledge() { },
                registerScheduler() { },
                registerUi() { },
                registerContributions() { },
                listAgents() { return []; },
                listChannels() { return []; },
                listKnowledge() { return []; },
                listSchedulers() { return []; },
                listUi() { return []; },
                snapshot() { return { agents: [], channels: [], knowledge: [], schedulers: [], ui: [] }; },
            },
            logger: { log() { } },
        });
        strict_1.default.ok(runtime);
        strict_1.default.deepEqual(await runtime?.attachments.listThreadKnowledgeBaseIds('thread-1'), []);
        strict_1.default.deepEqual(await runtime?.provider.listKnowledgeBases(), []);
    }
    finally {
        temp.cleanup();
    }
});
(0, node_test_1.default)('noop knowledge plugin exposes a disabled capability and inert runtime', async () => {
    const plugin = (0, index_js_1.createNoopKnowledgePlugin)();
    const runtime = await plugin.createRuntime?.({
        bus: { emit() { }, on() { return () => { }; } },
        capabilities: {
            registerAgent() { },
            registerChannel() { },
            registerKnowledge() { },
            registerScheduler() { },
            registerUi() { },
            registerContributions() { },
            listAgents() { return []; },
            listChannels() { return []; },
            listKnowledge() { return []; },
            listSchedulers() { return []; },
            listUi() { return []; },
            snapshot() { return { agents: [], channels: [], knowledge: [], schedulers: [], ui: [] }; },
        },
        logger: { log() { } },
    });
    strict_1.default.equal(plugin.capabilities?.knowledge?.[0]?.enabled, false);
    strict_1.default.deepEqual(await runtime?.provider.listKnowledgeBases(), []);
    strict_1.default.deepEqual(await runtime?.attachments.listThreadKnowledgeBaseIds('thread-1'), []);
});
(0, node_test_1.default)('deletes remote vector data for cached-miss knowledge bases before removing local base', async () => {
    const temp = withTempDir();
    const config = {
        ...(0, index_js_1.defaultKnowledgeConfig)(),
        baseUrl: 'http://vector.example.com',
    };
    let knowledgeBaseId = '';
    let batchDeletePayload = null;
    const provider = new index_js_1.AiVectorKnowledgeProvider({
        userDataPath: temp.dir,
        getConfig: () => config,
        setConfig: (input) => ({ ...config, ...input }),
    });
    const originalFetch = globalThis.fetch;
    globalThis.fetch = (async (input, init) => {
        const url = String(input);
        if (url.endsWith('/qdrant/query')) {
            return new Response(JSON.stringify({
                intent: 'CHAT',
                documents: [
                    {
                        id: 'result-1',
                        metadata: {
                            file_id: 'file-a',
                            file_name: 'doc-a.md',
                        },
                    },
                    {
                        id: 'result-2',
                        metadata: {
                            file_id: 'file-b',
                            file_name: 'doc-b.md',
                        },
                    },
                    {
                        id: 'result-3',
                        metadata: {
                            file_id: 'file-a',
                            file_name: 'doc-a.md',
                        },
                    },
                ],
            }));
        }
        if (url.endsWith('/qdrant/batchDelete')) {
            batchDeletePayload = init?.body ? JSON.parse(String(init.body)) : null;
            return new Response(JSON.stringify({
                resultCode: 0,
                resultMsg: 'success',
                data: { success: true },
            }));
        }
        throw new Error(`Unexpected fetch URL: ${url}`);
    });
    try {
        const base = await provider.createKnowledgeBase({
            name: '运营知识库',
            description: 'desc',
        });
        knowledgeBaseId = base.id;
        const result = await provider.deleteKnowledgeBase(knowledgeBaseId);
        strict_1.default.equal(result.deleted, true);
        strict_1.default.deepEqual(batchDeletePayload, {
            collection: 'personal_knowledge',
            knowledgebase_id: knowledgeBaseId,
            file_ids: ['file-a', 'file-b'],
        });
        await strict_1.default.rejects(() => provider.getKnowledgeBase(knowledgeBaseId), /Knowledge base does not exist/);
    }
    finally {
        globalThis.fetch = originalFetch;
        temp.cleanup();
    }
});
