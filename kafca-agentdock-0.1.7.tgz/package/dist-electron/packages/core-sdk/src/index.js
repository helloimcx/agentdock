"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LOCAL_AI_CORE_ORIGIN = exports.LOCAL_AI_CORE_BASE = void 0;
exports.detectLocalAiCore = detectLocalAiCore;
exports.subscribeEvents = subscribeEvents;
exports.getCoreRuntime = getCoreRuntime;
exports.startCoreService = startCoreService;
exports.stopCoreService = stopCoreService;
exports.restartCoreService = restartCoreService;
exports.getCoreLogs = getCoreLogs;
exports.readCoreConfigFile = readCoreConfigFile;
exports.saveCoreRawConfigFile = saveCoreRawConfigFile;
exports.saveCoreStructuredConfigFile = saveCoreStructuredConfigFile;
exports.saveCoreSettings = saveCoreSettings;
exports.listChannelGateways = listChannelGateways;
exports.getChannelGatewayStatus = getChannelGatewayStatus;
exports.testChannelConnection = testChannelConnection;
exports.enableChannelGateway = enableChannelGateway;
exports.disableChannelGateway = disableChannelGateway;
exports.listChannelPendingPairings = listChannelPendingPairings;
exports.approveChannelPairing = approveChannelPairing;
exports.rejectChannelPairing = rejectChannelPairing;
exports.listChannelAuthorizedUsers = listChannelAuthorizedUsers;
exports.listLarkGateways = listLarkGateways;
exports.getLarkGatewayStatus = getLarkGatewayStatus;
exports.testLarkConnection = testLarkConnection;
exports.enableLarkGateway = enableLarkGateway;
exports.disableLarkGateway = disableLarkGateway;
exports.listLarkPendingPairings = listLarkPendingPairings;
exports.approveLarkPairing = approveLarkPairing;
exports.rejectLarkPairing = rejectLarkPairing;
exports.listLarkAuthorizedUsers = listLarkAuthorizedUsers;
exports.getWeixinQrCode = getWeixinQrCode;
exports.checkWeixinQrCodeStatus = checkWeixinQrCodeStatus;
exports.listWorkspaces = listWorkspaces;
exports.listScheduledJobs = listScheduledJobs;
exports.getScheduledJob = getScheduledJob;
exports.createScheduledJob = createScheduledJob;
exports.updateScheduledJob = updateScheduledJob;
exports.deleteScheduledJob = deleteScheduledJob;
exports.runScheduledJob = runScheduledJob;
exports.listScheduledJobRuns = listScheduledJobRuns;
exports.listThreads = listThreads;
exports.createThread = createThread;
exports.getThread = getThread;
exports.renameThread = renameThread;
exports.updateThreadKnowledgeBases = updateThreadKnowledgeBases;
exports.deleteThread = deleteThread;
exports.sendMessage = sendMessage;
exports.sendAction = sendAction;
exports.interruptRun = interruptRun;
exports.listKnowledgeSources = listKnowledgeSources;
exports.getKnowledgeConfig = getKnowledgeConfig;
exports.saveKnowledgeConfig = saveKnowledgeConfig;
exports.listKnowledgeFolders = listKnowledgeFolders;
exports.createKnowledgeFolder = createKnowledgeFolder;
exports.updateKnowledgeFolder = updateKnowledgeFolder;
exports.deleteKnowledgeFolder = deleteKnowledgeFolder;
exports.listKnowledgeBases = listKnowledgeBases;
exports.createKnowledgeBase = createKnowledgeBase;
exports.getKnowledgeBase = getKnowledgeBase;
exports.updateKnowledgeBase = updateKnowledgeBase;
exports.deleteKnowledgeBase = deleteKnowledgeBase;
exports.listKnowledgeBaseFiles = listKnowledgeBaseFiles;
exports.uploadKnowledgeBaseFiles = uploadKnowledgeBaseFiles;
exports.deleteKnowledgeBaseFile = deleteKnowledgeBaseFile;
exports.searchKnowledgeBase = searchKnowledgeBase;
exports.getCapabilities = getCapabilities;
exports.getCapabilitySnapshot = getCapabilitySnapshot;
exports.getPluginDiagnostics = getPluginDiagnostics;
exports.probeWorkspaceStreaming = probeWorkspaceStreaming;
exports.onRuntimeUpdated = onRuntimeUpdated;
exports.onBridgeUpdated = onBridgeUpdated;
const DEFAULT_LOCAL_AI_CORE_ORIGIN = 'http://127.0.0.1:9831';
const DEFAULT_LOCAL_AI_CORE_BASE = `${DEFAULT_LOCAL_AI_CORE_ORIGIN}/api/local/v1`;
function normalizeLocalAiCoreBase(baseUrl) {
    const trimmed = baseUrl.trim();
    if (!trimmed) {
        return DEFAULT_LOCAL_AI_CORE_BASE;
    }
    return trimmed.replace(/\/+$/, '');
}
exports.LOCAL_AI_CORE_BASE = normalizeLocalAiCoreBase(typeof __LOCAL_AI_CORE_BASE__ !== 'undefined' ? __LOCAL_AI_CORE_BASE__ : '');
exports.LOCAL_AI_CORE_ORIGIN = exports.LOCAL_AI_CORE_BASE.endsWith('/api/local/v1')
    ? exports.LOCAL_AI_CORE_BASE.slice(0, -'/api/local/v1'.length) || DEFAULT_LOCAL_AI_CORE_ORIGIN
    : DEFAULT_LOCAL_AI_CORE_ORIGIN;
const listeners = new Set();
let eventSource = null;
async function coreRequest(method, path, body) {
    const response = await fetch(`${exports.LOCAL_AI_CORE_BASE}${path}`, {
        method,
        headers: {
            'Content-Type': 'application/json',
        },
        body: body ? JSON.stringify(body) : undefined,
    });
    const json = await response.json();
    if (!response.ok || !json.ok) {
        throw new Error(json.error || `Local AI Core request failed: ${response.status}`);
    }
    return json.data;
}
function ensureEventSource() {
    if (eventSource || typeof window === 'undefined') {
        return;
    }
    eventSource = new EventSource(`${exports.LOCAL_AI_CORE_BASE}/events`);
    const forward = (event) => {
        try {
            const payload = JSON.parse(event.data);
            listeners.forEach((listener) => listener(payload));
        }
        catch {
            // Ignore malformed payloads from a local dev server.
        }
    };
    [
        'runtime.updated',
        'thread.updated',
        'message.created',
        'message.updated',
        'run.updated',
        'scheduler.job.updated',
        'scheduler.run.updated',
        'presence.updated',
        'stream.updated',
    ].forEach((eventName) => {
        eventSource?.addEventListener(eventName, forward);
    });
    eventSource.onerror = () => {
        eventSource?.close();
        eventSource = null;
        if (listeners.size > 0) {
            window.setTimeout(() => ensureEventSource(), 1000);
        }
    };
}
function maybeCloseEventSource() {
    if (listeners.size === 0 && eventSource) {
        eventSource.close();
        eventSource = null;
    }
}
async function detectLocalAiCore(timeoutMs = 350) {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), timeoutMs);
    try {
        const response = await fetch(`${exports.LOCAL_AI_CORE_BASE}/health`, { signal: controller.signal });
        const json = await response.json();
        return response.ok && json.ok && json.data?.name === 'local-ai-core';
    }
    catch {
        return false;
    }
    finally {
        window.clearTimeout(timer);
    }
}
function subscribeEvents(listener) {
    listeners.add(listener);
    ensureEventSource();
    return () => {
        listeners.delete(listener);
        maybeCloseEventSource();
    };
}
async function getCoreRuntime() {
    return coreRequest('GET', '/runtime');
}
async function startCoreService() {
    return coreRequest('POST', '/runtime/service/start');
}
async function stopCoreService() {
    return coreRequest('POST', '/runtime/service/stop');
}
async function restartCoreService() {
    return coreRequest('POST', '/runtime/service/restart');
}
async function getCoreLogs(limit) {
    const suffix = typeof limit === 'number' ? `?limit=${encodeURIComponent(String(limit))}` : '';
    return coreRequest('GET', `/runtime/logs${suffix}`);
}
async function readCoreConfigFile() {
    return coreRequest('GET', '/runtime/config');
}
async function saveCoreRawConfigFile(raw) {
    return coreRequest('POST', '/runtime/config/raw', { raw });
}
async function saveCoreStructuredConfigFile(config) {
    return coreRequest('POST', '/runtime/config/structured', { config });
}
async function saveCoreSettings(input) {
    return coreRequest('POST', '/runtime/settings', input);
}
async function listChannelGateways(platform) {
    return coreRequest('GET', `/platforms/${encodeURIComponent(platform)}`);
}
async function getChannelGatewayStatus(platform, workspaceId) {
    return coreRequest('GET', `/platforms/${encodeURIComponent(platform)}/${encodeURIComponent(workspaceId)}`);
}
async function testChannelConnection(platform, workspaceId) {
    return coreRequest('POST', `/platforms/${encodeURIComponent(platform)}/${encodeURIComponent(workspaceId)}/test`);
}
async function enableChannelGateway(platform, workspaceId) {
    return coreRequest('POST', `/platforms/${encodeURIComponent(platform)}/${encodeURIComponent(workspaceId)}/enable`);
}
async function disableChannelGateway(platform, workspaceId) {
    return coreRequest('POST', `/platforms/${encodeURIComponent(platform)}/${encodeURIComponent(workspaceId)}/disable`);
}
async function listChannelPendingPairings(platform, workspaceId) {
    const suffix = workspaceId ? `?workspace_id=${encodeURIComponent(workspaceId)}` : '';
    return coreRequest('GET', `/platforms/${encodeURIComponent(platform)}/pairings${suffix}`);
}
async function approveChannelPairing(platform, code) {
    return coreRequest('POST', `/platforms/${encodeURIComponent(platform)}/pairings/approve`, { code });
}
async function rejectChannelPairing(platform, code) {
    return coreRequest('POST', `/platforms/${encodeURIComponent(platform)}/pairings/reject`, { code });
}
async function listChannelAuthorizedUsers(platform, workspaceId) {
    const suffix = workspaceId ? `?workspace_id=${encodeURIComponent(workspaceId)}` : '';
    return coreRequest('GET', `/platforms/${encodeURIComponent(platform)}/users${suffix}`);
}
async function listLarkGateways() {
    return listChannelGateways('lark');
}
async function getLarkGatewayStatus(workspaceId) {
    return getChannelGatewayStatus('lark', workspaceId);
}
async function testLarkConnection(workspaceId) {
    return testChannelConnection('lark', workspaceId);
}
async function enableLarkGateway(workspaceId) {
    return enableChannelGateway('lark', workspaceId);
}
async function disableLarkGateway(workspaceId) {
    return disableChannelGateway('lark', workspaceId);
}
async function listLarkPendingPairings(workspaceId) {
    return listChannelPendingPairings('lark', workspaceId);
}
async function approveLarkPairing(code) {
    return approveChannelPairing('lark', code);
}
async function rejectLarkPairing(code) {
    return rejectChannelPairing('lark', code);
}
async function listLarkAuthorizedUsers(workspaceId) {
    return listChannelAuthorizedUsers('lark', workspaceId);
}
async function getWeixinQrCode(workspaceId) {
    return coreRequest('POST', `/platforms/weixin/${encodeURIComponent(workspaceId)}/qrcode`);
}
async function checkWeixinQrCodeStatus(workspaceId, ticket) {
    return coreRequest('GET', `/platforms/weixin/${encodeURIComponent(workspaceId)}/qrcode/status?ticket=${encodeURIComponent(ticket)}`);
}
async function listWorkspaces() {
    return coreRequest('GET', '/workspaces');
}
async function listScheduledJobs(workspaceId) {
    const suffix = workspaceId ? `?workspace_id=${encodeURIComponent(workspaceId)}` : '';
    return coreRequest('GET', `/scheduler/jobs${suffix}`);
}
async function getScheduledJob(jobId) {
    return coreRequest('GET', `/scheduler/jobs/${encodeURIComponent(jobId)}`);
}
async function createScheduledJob(input) {
    return coreRequest('POST', '/scheduler/jobs', input);
}
async function updateScheduledJob(jobId, input) {
    return coreRequest('PATCH', `/scheduler/jobs/${encodeURIComponent(jobId)}`, input);
}
async function deleteScheduledJob(jobId) {
    return coreRequest('DELETE', `/scheduler/jobs/${encodeURIComponent(jobId)}`);
}
async function runScheduledJob(jobId) {
    return coreRequest('POST', `/scheduler/jobs/${encodeURIComponent(jobId)}/run`);
}
async function listScheduledJobRuns(jobId) {
    return coreRequest('GET', `/scheduler/jobs/${encodeURIComponent(jobId)}/runs`);
}
async function listThreads(workspaceId) {
    return coreRequest('GET', `/threads?workspace_id=${encodeURIComponent(workspaceId)}`);
}
async function createThread(workspaceId, title) {
    return coreRequest('POST', '/threads', { workspaceId, title });
}
async function getThread(threadId) {
    return coreRequest('GET', `/threads/${encodeURIComponent(threadId)}`);
}
async function renameThread(threadId, title) {
    return coreRequest('PATCH', `/threads/${encodeURIComponent(threadId)}`, { title });
}
async function updateThreadKnowledgeBases(threadId, knowledgeBaseIds) {
    return coreRequest('PATCH', `/threads/${encodeURIComponent(threadId)}/knowledge-bases`, { knowledgeBaseIds });
}
async function deleteThread(threadId) {
    return coreRequest('DELETE', `/threads/${encodeURIComponent(threadId)}`);
}
async function sendMessage(threadId, content) {
    return coreRequest('POST', `/threads/${encodeURIComponent(threadId)}/messages`, { content });
}
async function sendAction(threadId, content) {
    return coreRequest('POST', `/threads/${encodeURIComponent(threadId)}/actions`, { content });
}
async function interruptRun(runId) {
    return coreRequest('POST', `/runs/${encodeURIComponent(runId)}/interrupt`);
}
async function listKnowledgeSources() {
    return coreRequest('GET', '/knowledge/sources');
}
async function getKnowledgeConfig() {
    return coreRequest('GET', '/knowledge/config');
}
async function saveKnowledgeConfig(input) {
    return coreRequest('POST', '/knowledge/config', input);
}
async function listKnowledgeFolders() {
    return coreRequest('GET', '/knowledge/folders');
}
async function createKnowledgeFolder(input) {
    return coreRequest('POST', '/knowledge/folders', input);
}
async function updateKnowledgeFolder(folderId, input) {
    return coreRequest('PATCH', `/knowledge/folders/${encodeURIComponent(folderId)}`, input);
}
async function deleteKnowledgeFolder(folderId) {
    return coreRequest('DELETE', `/knowledge/folders/${encodeURIComponent(folderId)}`);
}
async function listKnowledgeBases() {
    return coreRequest('GET', '/knowledge/bases');
}
async function createKnowledgeBase(input) {
    return coreRequest('POST', '/knowledge/bases', input);
}
async function getKnowledgeBase(knowledgeBaseId) {
    return coreRequest('GET', `/knowledge/bases/${encodeURIComponent(knowledgeBaseId)}`);
}
async function updateKnowledgeBase(knowledgeBaseId, input) {
    return coreRequest('PATCH', `/knowledge/bases/${encodeURIComponent(knowledgeBaseId)}`, input);
}
async function deleteKnowledgeBase(knowledgeBaseId) {
    return coreRequest('DELETE', `/knowledge/bases/${encodeURIComponent(knowledgeBaseId)}`);
}
async function listKnowledgeBaseFiles(knowledgeBaseId) {
    return coreRequest('GET', `/knowledge/bases/${encodeURIComponent(knowledgeBaseId)}/files`);
}
async function uploadKnowledgeBaseFiles(knowledgeBaseId, input) {
    const formData = new FormData();
    formData.append('collection', input.collection);
    formData.append('knowledgebase_id', knowledgeBaseId);
    if (input.folder) {
        formData.append('folder', input.folder);
    }
    input.files.forEach((file) => {
        formData.append('files', file, file.name);
    });
    const response = await fetch(`${exports.LOCAL_AI_CORE_BASE}/knowledge/bases/${encodeURIComponent(knowledgeBaseId)}/files`, {
        method: 'POST',
        body: formData,
    });
    const json = await response.json();
    if (!response.ok || !json.ok) {
        throw new Error(json.error || `Local AI Core upload failed: ${response.status}`);
    }
    return json.data;
}
async function deleteKnowledgeBaseFile(knowledgeBaseId, fileId) {
    return coreRequest('DELETE', `/knowledge/bases/${encodeURIComponent(knowledgeBaseId)}/files/${encodeURIComponent(fileId)}`);
}
async function searchKnowledgeBase(knowledgeBaseId, input) {
    return coreRequest('POST', `/knowledge/bases/${encodeURIComponent(knowledgeBaseId)}/search`, input);
}
async function getCapabilities() {
    return coreRequest('GET', '/capabilities');
}
async function getCapabilitySnapshot() {
    return coreRequest('GET', '/capabilities/snapshot');
}
async function getPluginDiagnostics() {
    return coreRequest('GET', '/plugins/diagnostics');
}
async function probeWorkspaceStreaming(workspaceId) {
    return coreRequest('POST', `/workspaces/${encodeURIComponent(workspaceId)}/streaming-probe`);
}
function onRuntimeUpdated(listener) {
    return subscribeEvents((event) => {
        if (event.type === 'runtime.updated') {
            listener(event.runtime);
        }
    });
}
function onBridgeUpdated(listener) {
    return subscribeEvents((event) => {
        if (event.type === 'stream.updated') {
            listener(event.stream);
        }
        if (event.type === 'message.created' ||
            event.type === 'message.updated' ||
            event.type === 'run.updated') {
            if ('stream' in event && event.stream) {
                listener(event.stream);
            }
        }
    });
}
