"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SCHEDULER_PROTOCOL_INSTRUCTION = exports.LOCALCORE_ACP_AGENT_TYPE = exports.DESKTOP_INTERACTIVE_PERMISSION_AGENT_TYPES = exports.DESKTOP_PROVIDER_THINKING_OPTIONS = exports.DESKTOP_PROVIDER_PRESET_OPTIONS = exports.DESKTOP_PLATFORM_TYPE_OPTIONS = exports.DESKTOP_AGENT_TYPE_OPTIONS = exports.DESKTOP_LARK_SDK_PACKAGE = exports.DESKTOP_CLAUDECODE_ACP_PACKAGE = exports.DEFAULT_DESKTOP_CLAUDECODE_MODEL = exports.DEFAULT_DESKTOP_OPENCODE_MODEL = exports.DEFAULT_DESKTOP_AGENT_TYPE = void 0;
exports.deriveDesktopRuntimePhase = deriveDesktopRuntimePhase;
exports.deriveDesktopRuntimeRoles = deriveDesktopRuntimeRoles;
exports.normalizeDesktopPlatformType = normalizeDesktopPlatformType;
exports.wrapUserMessageWithSchedulerProtocol = wrapUserMessageWithSchedulerProtocol;
exports.getDefaultDesktopAgentModel = getDefaultDesktopAgentModel;
exports.normalizeDesktopAgentModel = normalizeDesktopAgentModel;
exports.normalizePermissionResponse = normalizePermissionResponse;
exports.isPermissionButtonOption = isPermissionButtonOption;
exports.normalizeDesktopBridgeButtonOption = normalizeDesktopBridgeButtonOption;
exports.supportsInteractivePermission = supportsInteractivePermission;
exports.isAcpAgentType = isAcpAgentType;
exports.DEFAULT_DESKTOP_AGENT_TYPE = 'opencode';
exports.DEFAULT_DESKTOP_OPENCODE_MODEL = 'opencode/minimax-m2.5-free';
exports.DEFAULT_DESKTOP_CLAUDECODE_MODEL = '';
exports.DESKTOP_CLAUDECODE_ACP_PACKAGE = '@agentclientprotocol/claude-agent-acp';
exports.DESKTOP_LARK_SDK_PACKAGE = '@larksuiteoapi/node-sdk';
exports.DESKTOP_AGENT_TYPE_OPTIONS = [
    'opencode',
    'codex',
    'claudecode',
    'cursor',
    'gemini',
    'qoder',
    'iflow',
    'localcore-acp',
];
exports.DESKTOP_PLATFORM_TYPE_OPTIONS = [
    'telegram',
    'feishu',
    'lark',
    'discord',
    'slack',
    'dingtalk',
    'wecom',
    'weixin',
    'qq',
    'qqbot',
    'line',
];
exports.DESKTOP_PROVIDER_PRESET_OPTIONS = [
    'openai',
    'openrouter',
    'anthropic',
    'minimax',
    'zhipuai',
    'deepseek',
    'siliconflow',
    'moonshot',
    'ollama',
];
exports.DESKTOP_PROVIDER_THINKING_OPTIONS = ['', 'enabled', 'disabled'];
exports.DESKTOP_INTERACTIVE_PERMISSION_AGENT_TYPES = ['opencode', 'claudecode', 'acp', 'localcore-acp'];
exports.LOCALCORE_ACP_AGENT_TYPE = 'localcore-acp';
exports.SCHEDULER_PROTOCOL_INSTRUCTION = [
    '[Scheduler Tools]',
    'If the user asks to create, view, edit, delete, or manually run a scheduled task for this conversation, use the Bash tool to run the local scheduler CLI.',
    'Use these commands:',
    'lac scheduler add --cron "<5-field cron>" --message "<exact message to send>" --desc "<short label>" [--execution-mode same-thread|side-thread]',
    'lac scheduler list',
    'lac scheduler list --thread',
    'lac scheduler info <job-id>',
    'lac scheduler edit <job-id> [--cron "<5-field cron>"] [--message "<exact message>"] [--desc "<short label>"] [--enabled true|false] [--execution-mode same-thread|side-thread]',
    'lac scheduler del <job-id>',
    'lac scheduler run <job-id>',
    'Environment variables LOCAL_AI_WORKSPACE_ID, LOCAL_AI_THREAD_ID, LOCAL_AI_PLATFORM, LOCAL_AI_CHAT_ID, and LOCAL_AI_PLATFORM_USER_ID are already set when available.',
    'Prefer relying on those variables instead of inventing your own route or creating session-only cron jobs.',
    'By default, `lac scheduler list` shows all scheduled tasks in the current workspace. Use `lac scheduler list --thread` to show only the current conversation thread.',
    'Use `--execution-mode same-thread` to reuse the current thread, or `--execution-mode side-thread` to run in a dedicated scheduled thread.',
    'Only use the scheduler CLI when the user explicitly asks for scheduled automation.',
    '[/Scheduler Tools]',
].join('\n');
const PERMISSION_RESPONSE_MAP = {
    allow: 'allow',
    deny: 'deny',
    'allow all': 'allow all',
    allowall: 'allow all',
    'perm:allow': 'allow',
    'perm:deny': 'deny',
    'perm:allow_all': 'allow all',
};
function deriveDesktopRuntimePhase(service) {
    if (service.status === 'starting') {
        return 'starting';
    }
    return 'api_ready';
}
function deriveDesktopRuntimeRoles(service) {
    return {
        conversation: {
            status: 'running',
            label: 'Local AI Core',
        },
        platformGateway: {
            status: service.status,
            label: 'Native Platform Gateway',
            service,
        },
    };
}
function normalizeDesktopPlatformType(platformType) {
    const normalized = String(platformType || '').trim().toLowerCase();
    if (normalized === 'feishu') {
        return 'lark';
    }
    return normalized;
}
function wrapUserMessageWithSchedulerProtocol(content, extraBlocks = []) {
    return [
        exports.SCHEDULER_PROTOCOL_INSTRUCTION,
        ...extraBlocks.flatMap((block) => (block ? ['', block] : [])),
        '',
        '[User Message]',
        content,
        '[/User Message]',
    ].join('\n');
}
function getDefaultDesktopAgentModel(agentType) {
    switch (String(agentType || '').trim().toLowerCase()) {
        case 'opencode':
            return exports.DEFAULT_DESKTOP_OPENCODE_MODEL;
        case 'claudecode':
            return exports.DEFAULT_DESKTOP_CLAUDECODE_MODEL;
        default:
            return '';
    }
}
function normalizeDesktopAgentModel(agentType, model) {
    const normalizedType = String(agentType || '').trim().toLowerCase();
    const normalizedModel = String(model || '').trim();
    if (!normalizedType) {
        return normalizedModel;
    }
    if (normalizedType === 'opencode') {
        return normalizedModel || exports.DEFAULT_DESKTOP_OPENCODE_MODEL;
    }
    if (normalizedType === 'claudecode' && normalizedModel.startsWith('opencode/')) {
        return '';
    }
    return normalizedModel;
}
function normalizePermissionResponse(input) {
    if (!input) {
        return null;
    }
    return PERMISSION_RESPONSE_MAP[String(input).trim().toLowerCase()] || null;
}
function isPermissionButtonOption(option) {
    return Boolean(normalizePermissionResponse(option?.data));
}
function normalizeDesktopBridgeButtonOption(input) {
    if (!input || typeof input !== 'object') {
        return null;
    }
    const record = input;
    const rawText = typeof record.text === 'string'
        ? record.text
        : typeof record.Text === 'string'
            ? record.Text
            : '';
    const rawData = typeof record.data === 'string'
        ? record.data
        : typeof record.Data === 'string'
            ? record.Data
            : '';
    if (!rawText || !rawData) {
        return null;
    }
    const permissionResponse = normalizePermissionResponse(rawData);
    if (permissionResponse) {
        return {
            text: permissionResponse,
            data: permissionResponse,
        };
    }
    return {
        text: rawText,
        data: rawData,
    };
}
function supportsInteractivePermission(agentType) {
    if (!agentType) {
        return false;
    }
    return exports.DESKTOP_INTERACTIVE_PERMISSION_AGENT_TYPES.includes(String(agentType).trim().toLowerCase());
}
function isAcpAgentType(agentType) {
    const normalized = String(agentType || '').trim().toLowerCase();
    return normalized === 'acp'
        || normalized === 'opencode'
        || normalized === 'claudecode'
        || normalized === exports.LOCALCORE_ACP_AGENT_TYPE;
}
