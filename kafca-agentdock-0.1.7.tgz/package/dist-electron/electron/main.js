"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const node_child_process_1 = require("node:child_process");
const node_fs_1 = require("node:fs");
const node_path_1 = require("node:path");
let mainWindow = null;
let localCoreProcess = null;
let localCoreStartupPromise = null;
const userDataOverride = process.env.AI_WORKSTATION_USER_DATA_DIR?.trim();
const smokeOutputPath = process.env.AI_WORKSTATION_SMOKE_OUTPUT?.trim();
function appResourcePath(...segments) {
    return (0, node_path_1.join)(electron_1.app.getAppPath(), ...segments);
}
if (userDataOverride) {
    (0, node_fs_1.mkdirSync)(userDataOverride, { recursive: true });
    electron_1.app.setPath('userData', userDataOverride);
}
function localCoreEntryPath() {
    return appResourcePath('dist-electron', 'services', 'local-ai-core', 'src', 'runtime', 'standalone.js');
}
function appIconPath() {
    return appResourcePath('build', 'icon.png');
}
async function isLocalCoreHealthy(timeoutMs = 350) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
        const response = await fetch('http://127.0.0.1:9831/api/local/v1/health', {
            signal: controller.signal,
        });
        return response.ok;
    }
    catch {
        return false;
    }
    finally {
        clearTimeout(timer);
    }
}
async function waitForLocalCoreHealthy(timeoutMs = 15000) {
    const startedAt = Date.now();
    while (Date.now() - startedAt < timeoutMs) {
        if (await isLocalCoreHealthy(500)) {
            return;
        }
        await new Promise((resolve) => setTimeout(resolve, 250));
    }
    throw new Error(`Local AI Core did not become healthy within ${timeoutMs}ms`);
}
async function fetchSmokeJson(path) {
    const response = await fetch(`http://127.0.0.1:9831${path}`);
    if (!response.ok) {
        throw new Error(`Smoke request failed for ${path}: HTTP ${response.status}`);
    }
    return response.json();
}
async function ensureLocalCoreProcess() {
    if (await isLocalCoreHealthy()) {
        return;
    }
    if (localCoreStartupPromise) {
        return localCoreStartupPromise;
    }
    localCoreStartupPromise = (async () => {
        if (!localCoreProcess) {
            const entry = localCoreEntryPath();
            if (!(0, node_fs_1.existsSync)(entry)) {
                throw new Error(`Missing Local AI Core entry: ${entry}`);
            }
            const child = (0, node_child_process_1.spawn)(process.execPath, [entry], {
                cwd: electron_1.app.getAppPath(),
                env: {
                    ...process.env,
                    ELECTRON_RUN_AS_NODE: '1',
                    AI_WORKSTATION_USER_DATA_DIR: electron_1.app.getPath('userData'),
                },
                stdio: 'inherit',
            });
            localCoreProcess = child;
            child.on('exit', () => {
                localCoreProcess = null;
            });
        }
        await waitForLocalCoreHealthy();
    })();
    try {
        await localCoreStartupPromise;
    }
    finally {
        localCoreStartupPromise = null;
    }
}
function stopLocalCoreProcess() {
    if (!localCoreProcess) {
        return;
    }
    localCoreProcess.kill('SIGTERM');
    localCoreProcess = null;
}
function createWindow() {
    const iconPath = appIconPath();
    mainWindow = new electron_1.BrowserWindow({
        width: 1400,
        height: 920,
        minWidth: 1100,
        minHeight: 700,
        title: 'AgentDock',
        icon: (0, node_fs_1.existsSync)(iconPath) ? iconPath : undefined,
        titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
        trafficLightPosition: { x: 12, y: 12 },
        vibrancy: process.platform === 'darwin' ? 'sidebar' : undefined,
        visualEffectState: process.platform === 'darwin' ? 'active' : undefined,
        backgroundColor: process.platform === 'darwin' ? '#00ffffff' : '#f5f5f7',
        webPreferences: {
            preload: (0, node_path_1.join)(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
        },
    });
    const devServerUrl = process.env.AI_WORKSTATION_DEV_SERVER_URL?.trim();
    if (devServerUrl) {
        void mainWindow.loadURL(devServerUrl);
        return;
    }
    const indexHtmlPath = appResourcePath('dist', 'renderer', 'index.html');
    if (!(0, node_fs_1.existsSync)(indexHtmlPath)) {
        throw new Error(`Renderer build output was not found at ${indexHtmlPath}. Run "pnpm build" first.`);
    }
    void mainWindow.loadFile(indexHtmlPath);
}
function writeSmokeResult(payload) {
    if (!smokeOutputPath) {
        return;
    }
    (0, node_fs_1.mkdirSync)((0, node_path_1.dirname)(smokeOutputPath), { recursive: true });
    (0, node_fs_1.writeFileSync)(smokeOutputPath, `${JSON.stringify(payload, null, 2)}\n`, 'utf8');
}
electron_1.app.whenReady().then(async () => {
    await ensureLocalCoreProcess();
    createWindow();
    if (smokeOutputPath) {
        const [capabilities, pluginDiagnostics] = await Promise.all([
            fetchSmokeJson('/api/local/v1/capabilities/snapshot'),
            fetchSmokeJson('/api/local/v1/plugins/diagnostics'),
        ]);
        writeSmokeResult({ ok: true, capabilities, pluginDiagnostics });
        setTimeout(() => electron_1.app.quit(), 300);
    }
    electron_1.app.on('activate', () => {
        if (electron_1.BrowserWindow.getAllWindows().length === 0) {
            createWindow();
        }
    });
});
electron_1.app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        electron_1.app.quit();
    }
});
electron_1.app.on('before-quit', () => {
    stopLocalCoreProcess();
});
