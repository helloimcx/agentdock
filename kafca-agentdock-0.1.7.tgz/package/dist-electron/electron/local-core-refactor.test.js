"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_test_1 = __importDefault(require("node:test"));
const strict_1 = __importDefault(require("node:assert/strict"));
const node_fs_1 = require("node:fs");
const node_os_1 = require("node:os");
const node_path_1 = require("node:path");
const local_core_acp_response_processor_js_1 = require("../services/local-ai-core/src/acp/local-core-acp-response-processor.js");
const scheduled_conversation_executor_js_1 = require("../services/local-ai-core/src/scheduler/scheduled-conversation-executor.js");
const scheduler_run_lifecycle_js_1 = require("../services/local-ai-core/src/scheduler/scheduler-run-lifecycle.js");
const lark_execution_policies_js_1 = require("../services/local-ai-core/src/scheduler/lark-execution-policies.js");
const local_core_weixin_gateway_js_1 = require("../services/local-ai-core/src/gateway/local-core-weixin-gateway.js");
const local_core_acp_turn_coordinator_js_1 = require("../services/local-ai-core/src/acp/local-core-acp-turn-coordinator.js");
(0, node_test_1.default)('ACP tool call update is emitted with its pending tool name', () => {
    const appended = [];
    const emitted = [];
    const coordinator = new local_core_acp_turn_coordinator_js_1.LocalCoreAcpTurnCoordinator({
        appendMessage: (_threadId, _role, content, kind) => appended.push({ content, kind }),
        emitBridge: (event) => emitted.push(event),
        updateRunStatus: () => { },
        sendRaw: () => true,
    });
    const session = {
        threadId: 'thread-1',
        bridgeSessionKey: 'session:thread-1',
        currentRunId: 'run-1',
        currentTurn: {
            runId: 'run-1',
            replyCtx: 'run-1',
            previewHandle: 'preview-1',
            assistantText: '',
            typingStarted: true,
            previewStarted: false,
            permission: null,
        },
        loadReplayMode: false,
        schedulerJobCreatedByRun: new Map(),
    };
    coordinator.handleAgentNotification(session, {
        method: 'session/update',
        params: {
            update: {
                sessionUpdate: 'tool_call',
                title: 'Terminal',
            },
        },
    });
    coordinator.handleAgentNotification(session, {
        method: 'session/update',
        params: {
            update: {
                sessionUpdate: 'tool_call_update',
                title: "ls ~/Desktop - List files on the user's desktop",
                status: 'running',
            },
        },
    });
    strict_1.default.deepEqual(appended, [
        {
            content: "🔧 Terminal: ls ~/Desktop - List files on the user's desktop - running",
            kind: 'progress',
        },
    ]);
    strict_1.default.equal(emitted.length, 1);
    strict_1.default.equal(emitted[0]?.content, appended[0]?.content);
});
(0, node_test_1.default)('ACP bare tool call is flushed before assistant text', () => {
    const appended = [];
    const emitted = [];
    const coordinator = new local_core_acp_turn_coordinator_js_1.LocalCoreAcpTurnCoordinator({
        appendMessage: (_threadId, _role, content) => appended.push(content),
        emitBridge: (event) => emitted.push(event),
        updateRunStatus: () => { },
        sendRaw: () => true,
    });
    const session = {
        threadId: 'thread-1',
        bridgeSessionKey: 'session:thread-1',
        currentRunId: 'run-1',
        currentTurn: {
            runId: 'run-1',
            replyCtx: 'run-1',
            previewHandle: 'preview-1',
            assistantText: '',
            typingStarted: true,
            previewStarted: false,
            permission: null,
        },
        loadReplayMode: false,
        schedulerJobCreatedByRun: new Map(),
    };
    coordinator.handleAgentNotification(session, {
        method: 'session/update',
        params: {
            update: {
                sessionUpdate: 'tool_call',
                title: 'Terminal',
            },
        },
    });
    coordinator.handleAgentNotification(session, {
        method: 'session/update',
        params: {
            update: {
                sessionUpdate: 'agent_message_chunk',
                content: { type: 'text', text: 'done' },
            },
        },
    });
    strict_1.default.deepEqual(appended, ['🔧 Terminal']);
    strict_1.default.equal(emitted[0]?.content, '🔧 Terminal');
    strict_1.default.equal(session.currentTurn.assistantText, 'done');
});
(0, node_test_1.default)('ACP skips empty generic running tool updates', () => {
    const appended = [];
    const emitted = [];
    const coordinator = new local_core_acp_turn_coordinator_js_1.LocalCoreAcpTurnCoordinator({
        appendMessage: (_threadId, _role, content) => appended.push(content),
        emitBridge: (event) => emitted.push(event),
        updateRunStatus: () => { },
        sendRaw: () => true,
    });
    const session = {
        threadId: 'thread-1',
        bridgeSessionKey: 'session:thread-1',
        currentRunId: 'run-1',
        currentTurn: {
            runId: 'run-1',
            replyCtx: 'run-1',
            previewHandle: 'preview-1',
            assistantText: '',
            typingStarted: true,
            previewStarted: false,
            permission: null,
        },
        loadReplayMode: false,
        schedulerJobCreatedByRun: new Map(),
    };
    coordinator.handleAgentNotification(session, {
        method: 'session/update',
        params: {
            update: {
                sessionUpdate: 'tool_call_update',
                title: 'Tool update',
                status: 'running',
            },
        },
    });
    strict_1.default.deepEqual(appended, []);
    strict_1.default.deepEqual(emitted, []);
});
(0, node_test_1.default)('ACP skips empty generic running updates even after a tool name', () => {
    const appended = [];
    const emitted = [];
    const coordinator = new local_core_acp_turn_coordinator_js_1.LocalCoreAcpTurnCoordinator({
        appendMessage: (_threadId, _role, content) => appended.push(content),
        emitBridge: (event) => emitted.push(event),
        updateRunStatus: () => { },
        sendRaw: () => true,
    });
    const session = {
        threadId: 'thread-1',
        bridgeSessionKey: 'session:thread-1',
        currentRunId: 'run-1',
        currentTurn: {
            runId: 'run-1',
            replyCtx: 'run-1',
            previewHandle: 'preview-1',
            assistantText: '',
            typingStarted: true,
            previewStarted: false,
            permission: null,
        },
        loadReplayMode: false,
        schedulerJobCreatedByRun: new Map(),
    };
    coordinator.handleAgentNotification(session, {
        method: 'session/update',
        params: {
            update: {
                sessionUpdate: 'tool_call',
                title: 'Terminal',
            },
        },
    });
    coordinator.handleAgentNotification(session, {
        method: 'session/update',
        params: {
            update: {
                sessionUpdate: 'tool_call_update',
                title: 'Tool update',
                status: 'running',
            },
        },
    });
    strict_1.default.deepEqual(appended, []);
    strict_1.default.deepEqual(emitted, []);
    strict_1.default.equal(session.currentTurn.pendingToolCallTitle, undefined);
});
(0, node_test_1.default)('response processor derives slash fallback replies and cron system responses', async () => {
    const processor = new local_core_acp_response_processor_js_1.LocalCoreAcpResponseProcessor({
        getScheduledDeliveryBinding: (threadId) => threadId === 'thread-1'
            ? {
                workspaceId: '知识库',
                platform: 'lark',
                route: {
                    type: 'channel.chat',
                    channelId: 'chat-1',
                    participantId: 'user-1',
                    threadId,
                },
            }
            : null,
        scheduler: {
            createJob: async () => ({
                id: 'job-1',
                workspaceId: '知识库',
                platform: 'lark',
                route: { type: 'channel.chat', channelId: 'chat-1', participantId: 'user-1', threadId: 'thread-1' },
                executionMode: 'same-thread',
                triggerType: 'cron',
                cronExpr: '*/2 * * * *',
                promptTemplate: 'ping',
                description: 'two-minute ping',
                enabled: true,
                concurrencyPolicy: 'skip_if_running',
                createdAt: '2026-04-22T06:00:00.000Z',
                updatedAt: '2026-04-22T06:00:00.000Z',
            }),
            listJobsForThread: async () => [],
            deleteJob: async () => { },
        },
    });
    strict_1.default.equal(processor.deriveSlashCommandReply('/mode', {}), '模式命令已执行，但当前 ACP 运行时没有返回可显示的模式菜单。请直接使用 `/mode <name>`。');
    const processed = await processor.processAssistantResponse('thread-1', '已为你创建。\n[CRON_CREATE]\nname: test\nschedule: */2 * * * *\nschedule_description: 每 2 分钟\nmessage: ping\n[/CRON_CREATE]');
    strict_1.default.equal(processed.displayContent.trim(), '已为你创建。');
    strict_1.default.match(processed.systemResponses[0] || '', /已创建定时任务/);
});
(0, node_test_1.default)('scheduled conversation executor uses execution policy hooks around a thread run', async () => {
    const calls = [];
    const job = {
        id: 'job-1',
        workspaceId: '知识库',
        platform: 'lark',
        route: { type: 'channel.chat', channelId: 'chat-1', participantId: 'user-1', threadId: 'thread-1' },
        executionMode: 'same-thread',
        triggerType: 'cron',
        cronExpr: '*/2 * * * *',
        promptTemplate: 'ping',
        description: 'two-minute ping',
        enabled: true,
        concurrencyPolicy: 'skip_if_running',
        createdAt: '2026-04-22T06:00:00.000Z',
        updatedAt: '2026-04-22T06:00:00.000Z',
    };
    const executor = new scheduled_conversation_executor_js_1.ScheduledConversationExecutor({
        store: {
            getRun: () => ({ status: 'completed' }),
        },
        workspaceRouter: {
            sendThreadMessage: async (threadId, prompt) => {
                calls.push(`send:${threadId}:${prompt}`);
                return { runId: 'run-1' };
            },
            getThread: async (threadId) => ({
                id: threadId,
                messages: [
                    { role: 'assistant', kind: 'final', content: 'done' },
                ],
            }),
        },
    });
    const result = await executor.execute(job, 'ping', {
        resolveTarget: async () => ({
            kind: 'thread',
            threadId: 'thread-1',
            workspaceId: '知识库',
            platform: 'lark',
            route: job.route,
        }),
        beforeExecute: (target) => {
            calls.push(`before:${target.threadId}`);
        },
        afterExecute: (target) => {
            calls.push(`after:${target.threadId}`);
        },
    }, 1000);
    strict_1.default.deepEqual(calls, [
        'before:thread-1',
        'send:thread-1:ping',
        'after:thread-1',
    ]);
    strict_1.default.equal(result.replyText, 'done');
});
(0, node_test_1.default)('scheduler run lifecycle updates run and job state through explicit transitions', () => {
    const emittedRuns = [];
    const emittedJobs = [];
    const job = {
        id: 'job-1',
        workspaceId: '知识库',
        platform: 'lark',
        route: { type: 'channel.chat', channelId: 'chat-1', participantId: 'user-1', threadId: 'thread-1' },
        executionMode: 'same-thread',
        triggerType: 'cron',
        cronExpr: '*/2 * * * *',
        promptTemplate: 'ping',
        description: 'two-minute ping',
        enabled: true,
        concurrencyPolicy: 'skip_if_running',
        createdAt: '2026-04-22T06:00:00.000Z',
        updatedAt: '2026-04-22T06:00:00.000Z',
    };
    const jobs = new Map([
        ['job-1', job],
    ]);
    const runs = new Map();
    let seq = 0;
    const lifecycle = new scheduler_run_lifecycle_js_1.SchedulerRunLifecycle({
        store: {
            createScheduledJobRun: (jobId, status, input) => {
                const run = { id: `run-${++seq}`, jobId, status, ...input };
                runs.set(run.id, run);
                return run;
            },
            updateScheduledJobRun: (runId, input) => {
                const next = { ...runs.get(runId), ...input };
                runs.set(runId, next);
                return next;
            },
            updateScheduledJobStatus: (jobId, input) => {
                jobs.set(jobId, { ...(jobs.get(jobId) || job), ...input });
            },
            getScheduledJob: (jobId) => jobs.get(jobId),
        },
        emitRun: (run) => emittedRuns.push(`${run.id}:${run.status}`),
        emitJob: (job) => emittedJobs.push(`${job.id}:${job.enabled}`),
    });
    const queued = lifecycle.markQueued(job, '2026-04-22T06:00:00.000Z');
    lifecycle.markRunning(queued.id);
    lifecycle.markSucceeded(job, queued.id, {
        threadId: 'thread-1',
        runId: 'run-1',
        platformMessageId: 'msg-1',
    }, true);
    strict_1.default.deepEqual(emittedRuns, [
        'run-1:queued',
        'run-1:running',
        'run-1:succeeded',
    ]);
    strict_1.default.deepEqual(emittedJobs, ['job-1:false']);
});
(0, node_test_1.default)('lark side-thread execution policy reuses a dedicated scheduled thread', async () => {
    const job = {
        id: 'job-1',
        workspaceId: '知识库',
        platform: 'lark',
        route: { type: 'channel.chat', channelId: 'chat-1', participantId: 'user-1', threadId: 'thread-origin' },
        executionMode: 'side-thread',
        triggerType: 'cron',
        cronExpr: '*/2 * * * *',
        promptTemplate: 'ping',
        description: 'two-minute ping',
        enabled: true,
        concurrencyPolicy: 'skip_if_running',
        createdAt: '2026-04-22T06:00:00.000Z',
        updatedAt: '2026-04-22T06:00:00.000Z',
    };
    const policy = (0, lark_execution_policies_js_1.createLarkExecutionPolicy)(job, {
        store: {},
        workspaceRouter: {
            listThreads: async () => [{ id: 'thread-scheduled', title: '[Scheduled] two-minute ping' }],
            createThread: async () => ({ id: 'thread-new' }),
        },
        getChannelRuntime: () => ({
            muteThreadBridge: () => { },
            unmuteThreadBridge: () => { },
        }),
    }, async () => 'thread-origin');
    const target = await policy.resolveTarget(job);
    strict_1.default.equal(target.threadId, 'thread-scheduled');
});
(0, node_test_1.default)('lark same-thread execution policy keeps the original thread target', async () => {
    const job = {
        id: 'job-1',
        workspaceId: '知识库',
        platform: 'lark',
        route: { type: 'channel.chat', channelId: 'chat-1', participantId: 'user-1', threadId: 'thread-origin' },
        executionMode: 'same-thread',
        triggerType: 'cron',
        cronExpr: '*/2 * * * *',
        promptTemplate: 'ping',
        description: 'two-minute ping',
        enabled: true,
        concurrencyPolicy: 'skip_if_running',
        createdAt: '2026-04-22T06:00:00.000Z',
        updatedAt: '2026-04-22T06:00:00.000Z',
    };
    const policy = (0, lark_execution_policies_js_1.createLarkExecutionPolicy)(job, {
        store: {},
        workspaceRouter: {},
        getChannelRuntime: () => ({
            muteThreadBridge: () => { },
            unmuteThreadBridge: () => { },
        }),
    }, async () => 'thread-origin');
    const target = await policy.resolveTarget(job);
    strict_1.default.equal(target.threadId, 'thread-origin');
});
(0, node_test_1.default)('weixin channel can request a QR code without platform options', async () => {
    const originalFetch = globalThis.fetch;
    const stateDir = (0, node_fs_1.mkdtempSync)((0, node_path_1.join)((0, node_os_1.tmpdir)(), 'weixin-channel-qr-'));
    const requests = [];
    globalThis.fetch = (async (input, init) => {
        requests.push({
            url: String(input),
            headers: new Headers(init?.headers),
        });
        return new Response(JSON.stringify({
            qrcode: 'ticket-1',
            qrcode_img_content: 'https://liteapp.weixin.qq.com/q/test?qrcode=ticket-1&bot_type=3',
            expired: 180,
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' },
        });
    });
    try {
        const gateway = new local_core_weixin_gateway_js_1.LocalCoreWeixinGateway({
            store: {},
            readConfig: async () => ({
                projects: [
                    {
                        name: 'default',
                        agent: { type: 'localcore-acp', providers: [] },
                        platforms: [{ type: 'weixin', options: { state_dir: stateDir } }],
                    },
                ],
            }),
            getWorkspaceRouter: () => ({}),
            eventBus: { emit: () => { }, on: () => () => { } },
        });
        const result = await gateway.getQrCode('default');
        strict_1.default.deepEqual(result, {
            ticket: 'ticket-1',
            expiresIn: 180,
            qrCodeUrl: 'https://liteapp.weixin.qq.com/q/test?qrcode=ticket-1&bot_type=3',
        });
        strict_1.default.equal(requests[0]?.url, 'https://ilinkai.weixin.qq.com/ilink/bot/get_bot_qrcode?bot_type=3');
        strict_1.default.equal(requests[0]?.headers.has('Authorization'), false);
        strict_1.default.equal(requests[0]?.headers.has('AuthorizationType'), false);
    }
    finally {
        globalThis.fetch = originalFetch;
        (0, node_fs_1.rmSync)(stateDir, { recursive: true, force: true });
    }
});
(0, node_test_1.default)('weixin QR confirmation persists credentials and starts authenticated polling', async () => {
    const originalFetch = globalThis.fetch;
    const stateDir = (0, node_fs_1.mkdtempSync)((0, node_path_1.join)((0, node_os_1.tmpdir)(), 'weixin-channel-'));
    const requests = [];
    globalThis.fetch = (async (input, init) => {
        const url = String(input);
        requests.push({
            url,
            headers: new Headers(init?.headers),
        });
        if (url.includes('/get_qrcode_status')) {
            return new Response(JSON.stringify({
                status: 'confirmed',
                bot_token: 'bot-token-1',
                baseurl: 'https://ilinkai.weixin.qq.com',
                ilink_bot_id: 'bot-1',
                ilink_user_id: 'user-1',
            }), {
                status: 200,
                headers: { 'Content-Type': 'application/json' },
            });
        }
        return new Promise((_resolve, reject) => {
            init?.signal?.addEventListener('abort', () => reject(new Error('aborted')), { once: true });
        });
    });
    const gateway = new local_core_weixin_gateway_js_1.LocalCoreWeixinGateway({
        store: {
            expirePendingPairings: () => { },
            listPendingPairings: () => [],
            listAuthorizedUsers: () => [],
        },
        readConfig: async () => ({
            projects: [
                {
                    name: 'default',
                    agent: { type: 'localcore-acp', providers: [] },
                    platforms: [{ type: 'weixin', options: { state_dir: stateDir } }],
                },
            ],
        }),
        getWorkspaceRouter: () => ({}),
        eventBus: { emit: () => { }, on: () => () => { } },
    });
    try {
        const result = await gateway.checkQrCodeStatus('default', 'ticket-1');
        await new Promise((resolve) => setTimeout(resolve, 0));
        strict_1.default.equal(result.status, 'confirmed');
        const pollingRequest = requests.find((request) => request.url.endsWith('/ilink/bot/getupdates'));
        strict_1.default.equal(pollingRequest?.headers.get('Authorization'), 'Bearer bot-token-1');
        strict_1.default.equal(pollingRequest?.headers.get('AuthorizationType'), 'ilink_bot_token');
    }
    finally {
        await gateway.stop();
        globalThis.fetch = originalFetch;
        (0, node_fs_1.rmSync)(stateDir, { recursive: true, force: true });
    }
});
(0, node_test_1.default)('weixin inbound message handling is idempotent by message identity', async () => {
    const sentThreadMessages = [];
    const users = new Map();
    const threadBindings = new Map();
    const bindingKey = 'default:chat-1:user-1';
    const gateway = new local_core_weixin_gateway_js_1.LocalCoreWeixinGateway({
        store: {
            expirePendingPairings: () => { },
            listPendingPairings: () => [],
            listPairingRequests: () => [],
            listAuthorizedUsers: () => [...users.values()],
            getAuthorizedUser: (_workspaceId, platformUserId) => users.get(platformUserId),
            createAuthorizedUser: (user) => users.set(user.platform_user_id, user),
            updateAuthorizedUserThread: (_workspaceId, platformUserId, threadId) => {
                users.set(platformUserId, { ...users.get(platformUserId), thread_id: threadId });
            },
            getPlatformThreadBinding: () => threadBindings.get(bindingKey),
            upsertPlatformThreadBinding: (binding) => threadBindings.set(bindingKey, binding),
            updatePlatformThreadMessageId: (_workspaceId, _chatId, _platformUserId, messageId) => {
                threadBindings.set(bindingKey, { ...threadBindings.get(bindingKey), last_platform_message_id: messageId });
            },
            getLatestRunForThread: () => null,
        },
        readConfig: async () => ({
            projects: [
                {
                    name: 'default',
                    agent: { type: 'localcore-acp', providers: [] },
                    platforms: [{ type: 'weixin', options: {} }],
                },
            ],
        }),
        getWorkspaceRouter: () => ({
            createThread: async () => ({ id: 'thread-1' }),
            getThreadSessionKey: (threadId) => `session:${threadId}`,
            sendThreadMessage: async (_threadId, text) => {
                sentThreadMessages.push(text);
                return { runId: 'run-1' };
            },
        }),
        eventBus: { emit: () => { }, on: () => () => { } },
    });
    const input = {
        workspaceId: 'default',
        platformUserId: 'user-1',
        chatId: 'chat-1',
        displayName: 'User',
        text: 'hello',
        messageId: 'msg-1',
        contextToken: 'ctx-1',
    };
    await gateway.handleInboundMessage(input);
    await gateway.handleInboundMessage(input);
    strict_1.default.equal(sentThreadMessages.length, 1);
    strict_1.default.match(sentThreadMessages[0] || '', /hello/);
});
(0, node_test_1.default)('weixin bridge skips duplicate rendered replies', async () => {
    const originalFetch = globalThis.fetch;
    const sentBodies = [];
    globalThis.fetch = (async (_input, init) => {
        sentBodies.push(JSON.parse(String(init?.body || '{}')));
        return new Response(JSON.stringify({ errcode: 0 }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' },
        });
    });
    const gateway = new local_core_weixin_gateway_js_1.LocalCoreWeixinGateway({
        store: {
            getPlatformThreadBinding: () => ({
                workspace_id: 'default',
                platform: 'weixin',
                chat_id: 'chat-1',
                platform_user_id: 'user-1',
                thread_id: 'thread-1',
                last_platform_message_id: 'ctx-1',
            }),
        },
        readConfig: async () => ({
            projects: [
                {
                    name: 'default',
                    agent: { type: 'localcore-acp', providers: [] },
                    platforms: [{ type: 'weixin', options: { token: 'bot-token-1' } }],
                },
            ],
        }),
        getWorkspaceRouter: () => ({}),
        eventBus: { emit: () => { }, on: () => () => { } },
    });
    const internals = gateway;
    internals.runtime.set('default', {
        workspaceId: 'default',
        enabled: true,
        status: 'running',
        connected: true,
        accountId: 'bot-1',
    });
    internals.threadRouting.set('session:thread-1', {
        workspaceId: 'default',
        platformUserId: 'user-1',
        chatId: 'chat-1',
        threadId: 'thread-1',
    });
    try {
        await gateway.onBridgeEvent({ type: 'update_message', sessionKey: 'session:thread-1', content: 'same reply' });
        await gateway.onBridgeEvent({ type: 'reply', sessionKey: 'session:thread-1', content: 'same reply' });
        await gateway.onBridgeEvent({ type: 'typing_stop', sessionKey: 'session:thread-1' });
        await gateway.onBridgeEvent({ type: 'reply', sessionKey: 'session:thread-1', content: 'same reply' });
        strict_1.default.equal(sentBodies.length, 1);
        strict_1.default.equal(sentBodies[0]?.msg?.item_list?.[0]?.text_item?.text, 'same reply');
    }
    finally {
        globalThis.fetch = originalFetch;
    }
});
(0, node_test_1.default)('weixin bridge keeps context replies to one truncated text message', async () => {
    const originalFetch = globalThis.fetch;
    const sentBodies = [];
    globalThis.fetch = (async (_input, init) => {
        sentBodies.push(JSON.parse(String(init?.body || '{}')));
        return new Response(JSON.stringify({ errcode: 0 }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' },
        });
    });
    const gateway = new local_core_weixin_gateway_js_1.LocalCoreWeixinGateway({
        store: {
            getPlatformThreadBinding: () => ({
                workspace_id: 'default',
                platform: 'weixin',
                chat_id: 'chat-1',
                platform_user_id: 'user-1',
                thread_id: 'thread-1',
                last_platform_message_id: 'ctx-1',
            }),
        },
        readConfig: async () => ({
            projects: [
                {
                    name: 'default',
                    agent: { type: 'localcore-acp', providers: [] },
                    platforms: [{ type: 'weixin', options: { token: 'bot-token-1' } }],
                },
            ],
        }),
        getWorkspaceRouter: () => ({}),
        eventBus: { emit: () => { }, on: () => () => { } },
    });
    const internals = gateway;
    internals.runtime.set('default', {
        workspaceId: 'default',
        enabled: true,
        status: 'running',
        connected: true,
        accountId: 'bot-1',
    });
    internals.threadRouting.set('session:thread-1', {
        workspaceId: 'default',
        platformUserId: 'user-1',
        chatId: 'chat-1',
        threadId: 'thread-1',
    });
    try {
        await gateway.onBridgeEvent({
            type: 'reply',
            sessionKey: 'session:thread-1',
            content: Array.from({ length: 80 }, (_, index) => `第 ${index + 1} 行：这是一段用于测试微信长文本切分的内容。`).join('\n\n'),
        });
        strict_1.default.equal(sentBodies.length, 1);
        strict_1.default.equal(sentBodies[0]?.msg?.context_token, 'ctx-1');
        for (const body of sentBodies) {
            const text = body?.msg?.item_list?.[0]?.text_item?.text || '';
            strict_1.default.ok(Buffer.byteLength(text, 'utf-8') <= 3500);
            strict_1.default.match(text, /内容过长，已截断以保证微信送达/);
            strict_1.default.equal(body?.base_info?.channel_version, '2.1.7');
            strict_1.default.equal(body?.msg?.from_user_id, '');
            strict_1.default.match(body?.msg?.client_id || '', /^openclaw-weixin-/);
        }
    }
    finally {
        globalThis.fetch = originalFetch;
    }
});
(0, node_test_1.default)('weixin bridge sends protocol-compatible final reply payload', async () => {
    const originalFetch = globalThis.fetch;
    const sentRequests = [];
    globalThis.fetch = (async (_input, init) => {
        const body = JSON.parse(String(init?.body || '{}'));
        sentRequests.push({ body, headers: new Headers(init?.headers) });
        return new Response(JSON.stringify({ ret: 0 }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' },
        });
    });
    const gateway = new local_core_weixin_gateway_js_1.LocalCoreWeixinGateway({
        store: {
            getPlatformThreadBinding: () => ({
                workspace_id: 'default',
                platform: 'weixin',
                chat_id: 'chat-1',
                platform_user_id: 'user-1',
                thread_id: 'thread-1',
                last_platform_message_id: 'ctx-1',
            }),
        },
        readConfig: async () => ({
            projects: [
                {
                    name: 'default',
                    agent: { type: 'localcore-acp', providers: [] },
                    platforms: [{ type: 'weixin', options: { token: 'bot-token-1' } }],
                },
            ],
        }),
        getWorkspaceRouter: () => ({}),
        eventBus: { emit: () => { }, on: () => () => { } },
    });
    const internals = gateway;
    internals.runtime.set('default', {
        workspaceId: 'default',
        enabled: true,
        status: 'running',
        connected: true,
        accountId: 'bot-1',
    });
    internals.threadRouting.set('session:thread-1', {
        workspaceId: 'default',
        platformUserId: 'user-1',
        chatId: 'chat-1',
        threadId: 'thread-1',
    });
    try {
        await gateway.onBridgeEvent({ type: 'reply', sessionKey: 'session:thread-1', content: 'final reply' });
        strict_1.default.equal(sentRequests.length, 1);
        strict_1.default.equal(sentRequests[0]?.body?.msg?.context_token, 'ctx-1');
        strict_1.default.equal(sentRequests[0]?.body?.msg?.from_user_id, '');
        strict_1.default.equal(sentRequests[0]?.body?.msg?.message_state, 2);
        strict_1.default.equal(sentRequests[0]?.body?.base_info?.channel_version, '2.1.7');
        strict_1.default.match(sentRequests[0]?.body?.msg?.client_id || '', /^openclaw-weixin-/);
        strict_1.default.equal(sentRequests[0]?.body?.msg?.item_list?.[0]?.text_item?.text, 'final reply');
        strict_1.default.equal(sentRequests[0]?.headers.get('iLink-App-Id'), 'bot');
        strict_1.default.equal(sentRequests[0]?.headers.get('iLink-App-ClientVersion'), '131335');
        strict_1.default.equal(sentRequests[0]?.headers.get('AuthorizationType'), 'ilink_bot_token');
        strict_1.default.equal(sentRequests[0]?.headers.get('Authorization'), 'Bearer bot-token-1');
    }
    finally {
        globalThis.fetch = originalFetch;
    }
});
(0, node_test_1.default)('weixin bridge sends status events in real time', async () => {
    const originalFetch = globalThis.fetch;
    const sentBodies = [];
    globalThis.fetch = (async (_input, init) => {
        sentBodies.push(JSON.parse(String(init?.body || '{}')));
        return new Response(JSON.stringify({ ret: 0 }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' },
        });
    });
    const gateway = new local_core_weixin_gateway_js_1.LocalCoreWeixinGateway({
        store: {
            getPlatformThreadBinding: () => ({
                workspace_id: 'default',
                platform: 'weixin',
                chat_id: 'chat-1',
                platform_user_id: 'user-1',
                thread_id: 'thread-1',
                last_platform_message_id: 'ctx-1',
            }),
        },
        readConfig: async () => ({
            projects: [
                {
                    name: 'default',
                    agent: { type: 'localcore-acp', providers: [] },
                    platforms: [{ type: 'weixin', options: { token: 'bot-token-1' } }],
                },
            ],
        }),
        getWorkspaceRouter: () => ({}),
        eventBus: { emit: () => { }, on: () => () => { } },
    });
    const internals = gateway;
    internals.runtime.set('default', {
        workspaceId: 'default',
        enabled: true,
        status: 'running',
        connected: true,
        accountId: 'bot-1',
    });
    internals.threadRouting.set('session:thread-1', {
        workspaceId: 'default',
        platformUserId: 'user-1',
        chatId: 'chat-1',
        threadId: 'thread-1',
    });
    try {
        await gateway.onBridgeEvent({ type: 'status', sessionKey: 'session:thread-1', content: '正在检查桌面文件' });
        strict_1.default.equal(sentBodies.length, 1);
        strict_1.default.equal(sentBodies[0]?.msg?.context_token, 'ctx-1');
        strict_1.default.equal(sentBodies[0]?.msg?.message_state, 2);
        strict_1.default.equal(sentBodies[0]?.msg?.item_list?.[0]?.text_item?.text, '正在检查桌面文件');
    }
    finally {
        globalThis.fetch = originalFetch;
    }
});
(0, node_test_1.default)('weixin bridge sends tool progress in real time before final reply', async () => {
    const originalFetch = globalThis.fetch;
    const sentBodies = [];
    globalThis.fetch = (async (_input, init) => {
        sentBodies.push(JSON.parse(String(init?.body || '{}')));
        return new Response(JSON.stringify({ ret: 0 }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' },
        });
    });
    const gateway = new local_core_weixin_gateway_js_1.LocalCoreWeixinGateway({
        store: {
            getPlatformThreadBinding: () => ({
                workspace_id: 'default',
                platform: 'weixin',
                chat_id: 'chat-1',
                platform_user_id: 'user-1',
                thread_id: 'thread-1',
                last_platform_message_id: 'ctx-1',
            }),
        },
        readConfig: async () => ({
            projects: [
                {
                    name: 'default',
                    agent: { type: 'localcore-acp', providers: [] },
                    platforms: [{ type: 'weixin', options: { token: 'bot-token-1' } }],
                },
            ],
        }),
        getWorkspaceRouter: () => ({}),
        eventBus: { emit: () => { }, on: () => () => { } },
    });
    const internals = gateway;
    internals.runtime.set('default', {
        workspaceId: 'default',
        enabled: true,
        status: 'running',
        connected: true,
        accountId: 'bot-1',
    });
    internals.threadRouting.set('session:thread-1', {
        workspaceId: 'default',
        platformUserId: 'user-1',
        chatId: 'chat-1',
        threadId: 'thread-1',
    });
    try {
        await gateway.onBridgeEvent({ type: 'reply', sessionKey: 'session:thread-1', content: '🔧 list desktop' });
        await gateway.onBridgeEvent({ type: 'reply', sessionKey: 'session:thread-1', content: 'final reply' });
        strict_1.default.equal(sentBodies.length, 2);
        strict_1.default.equal(sentBodies[0]?.msg?.message_state, 2);
        strict_1.default.equal(sentBodies[1]?.msg?.message_state, 2);
        strict_1.default.equal(sentBodies[0]?.msg?.context_token, 'ctx-1');
        strict_1.default.equal(sentBodies[1]?.msg?.context_token, 'ctx-1');
        strict_1.default.equal(sentBodies[0]?.msg?.item_list?.[0]?.text_item?.text, '🔧 list desktop');
        strict_1.default.equal(sentBodies[1]?.msg?.item_list?.[0]?.text_item?.text, 'final reply');
    }
    finally {
        globalThis.fetch = originalFetch;
    }
});
(0, node_test_1.default)('weixin bridge skips completed tool result updates but keeps final reply', async () => {
    const originalFetch = globalThis.fetch;
    const sentBodies = [];
    globalThis.fetch = (async (_input, init) => {
        sentBodies.push(JSON.parse(String(init?.body || '{}')));
        return new Response(JSON.stringify({ errcode: 0 }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' },
        });
    });
    const gateway = new local_core_weixin_gateway_js_1.LocalCoreWeixinGateway({
        store: {
            getPlatformThreadBinding: () => ({
                workspace_id: 'default',
                platform: 'weixin',
                chat_id: 'chat-1',
                platform_user_id: 'user-1',
                thread_id: 'thread-1',
                last_platform_message_id: 'ctx-1',
            }),
        },
        readConfig: async () => ({
            projects: [
                {
                    name: 'default',
                    agent: { type: 'localcore-acp', providers: [] },
                    platforms: [{ type: 'weixin', options: { token: 'bot-token-1' } }],
                },
            ],
        }),
        getWorkspaceRouter: () => ({}),
        eventBus: { emit: () => { }, on: () => () => { } },
    });
    const internals = gateway;
    internals.runtime.set('default', {
        workspaceId: 'default',
        enabled: true,
        status: 'running',
        connected: true,
        accountId: 'bot-1',
    });
    internals.threadRouting.set('session:thread-1', {
        workspaceId: 'default',
        platformUserId: 'user-1',
        chatId: 'chat-1',
        threadId: 'thread-1',
    });
    try {
        await gateway.onBridgeEvent({
            type: 'reply',
            sessionKey: 'session:thread-1',
            content: '🔧 Tool update - completed - /Users/mochuxian/Desktop has many files and this result should not be sent',
        });
        await gateway.onBridgeEvent({ type: 'reply', sessionKey: 'session:thread-1', content: 'final reply' });
        strict_1.default.equal(sentBodies.length, 1);
        strict_1.default.equal(sentBodies[0]?.msg?.message_state, 2);
        strict_1.default.equal(sentBodies[0]?.msg?.item_list?.[0]?.text_item?.text, 'final reply');
    }
    finally {
        globalThis.fetch = originalFetch;
    }
});
(0, node_test_1.default)('weixin bridge keeps failed tool update status without execution details', async () => {
    const originalFetch = globalThis.fetch;
    const sentBodies = [];
    globalThis.fetch = (async (_input, init) => {
        sentBodies.push(JSON.parse(String(init?.body || '{}')));
        return new Response(JSON.stringify({ errcode: 0 }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' },
        });
    });
    const gateway = new local_core_weixin_gateway_js_1.LocalCoreWeixinGateway({
        store: {
            getPlatformThreadBinding: () => ({
                workspace_id: 'default',
                platform: 'weixin',
                chat_id: 'chat-1',
                platform_user_id: 'user-1',
                thread_id: 'thread-1',
                last_platform_message_id: 'ctx-1',
            }),
        },
        readConfig: async () => ({
            projects: [
                {
                    name: 'default',
                    agent: { type: 'localcore-acp', providers: [] },
                    platforms: [{ type: 'weixin', options: { token: 'bot-token-1' } }],
                },
            ],
        }),
        getWorkspaceRouter: () => ({}),
        eventBus: { emit: () => { }, on: () => () => { } },
    });
    const internals = gateway;
    internals.runtime.set('default', {
        workspaceId: 'default',
        enabled: true,
        status: 'running',
        connected: true,
        accountId: 'bot-1',
    });
    internals.threadRouting.set('session:thread-1', {
        workspaceId: 'default',
        platformUserId: 'user-1',
        chatId: 'chat-1',
        threadId: 'thread-1',
    });
    try {
        await gateway.onBridgeEvent({
            type: 'reply',
            sessionKey: 'session:thread-1',
            content: '🔧 Tool update - failed - stack trace and command output should not be sent',
        });
        strict_1.default.equal(sentBodies.length, 1);
        strict_1.default.equal(sentBodies[0]?.msg?.item_list?.[0]?.text_item?.text, '🔧 Tool update - failed');
    }
    finally {
        globalThis.fetch = originalFetch;
    }
});
(0, node_test_1.default)('weixin bridge folds progress after nine context sends and preserves final reply', async () => {
    const originalFetch = globalThis.fetch;
    const sentBodies = [];
    globalThis.fetch = (async (_input, init) => {
        sentBodies.push(JSON.parse(String(init?.body || '{}')));
        return new Response(JSON.stringify({ ret: 0 }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' },
        });
    });
    const gateway = new local_core_weixin_gateway_js_1.LocalCoreWeixinGateway({
        store: {
            getPlatformThreadBinding: () => ({
                workspace_id: 'default',
                platform: 'weixin',
                chat_id: 'chat-1',
                platform_user_id: 'user-1',
                thread_id: 'thread-1',
                last_platform_message_id: 'ctx-1',
            }),
        },
        readConfig: async () => ({
            projects: [
                {
                    name: 'default',
                    agent: { type: 'localcore-acp', providers: [] },
                    platforms: [{ type: 'weixin', options: { token: 'bot-token-1' } }],
                },
            ],
        }),
        getWorkspaceRouter: () => ({}),
        eventBus: { emit: () => { }, on: () => () => { } },
    });
    const internals = gateway;
    internals.runtime.set('default', {
        workspaceId: 'default',
        enabled: true,
        status: 'running',
        connected: true,
        accountId: 'bot-1',
    });
    internals.threadRouting.set('session:thread-1', {
        workspaceId: 'default',
        platformUserId: 'user-1',
        chatId: 'chat-1',
        threadId: 'thread-1',
    });
    try {
        for (let index = 1; index <= 12; index += 1) {
            await gateway.onBridgeEvent({
                type: 'reply',
                sessionKey: 'session:thread-1',
                content: `🔧 tool ${index}`,
            });
        }
        await gateway.onBridgeEvent({ type: 'reply', sessionKey: 'session:thread-1', content: 'final reply' });
        strict_1.default.equal(sentBodies.length, 10);
        strict_1.default.equal(sentBodies[0]?.msg?.item_list?.[0]?.text_item?.text, '🔧 tool 1');
        strict_1.default.equal(sentBodies[8]?.msg?.item_list?.[0]?.text_item?.text, '🔧 tool 9');
        strict_1.default.doesNotMatch(sentBodies.map((body) => body?.msg?.item_list?.[0]?.text_item?.text || '').join('\n'), /🔧 tool 10|🔧 tool 11|🔧 tool 12/);
        strict_1.default.match(sentBodies[9]?.msg?.item_list?.[0]?.text_item?.text, /已省略 3 条过程消息/);
        strict_1.default.match(sentBodies[9]?.msg?.item_list?.[0]?.text_item?.text, /final reply/);
    }
    finally {
        globalThis.fetch = originalFetch;
    }
});
