"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_test_1 = __importDefault(require("node:test"));
const strict_1 = __importDefault(require("node:assert/strict"));
const node_fs_1 = require("node:fs");
const node_os_1 = require("node:os");
const node_path_1 = require("node:path");
const bootstrap_js_1 = require("../services/local-ai-core/src/kernel/bootstrap.js");
const bootstrap_js_2 = require("../services/local-ai-core/src/kernel/bootstrap.js");
const capability_registry_js_1 = require("../services/local-ai-core/src/kernel/capability-registry.js");
const event_bus_js_1 = require("../services/local-ai-core/src/kernel/event-bus.js");
const lifecycle_manager_js_1 = require("../services/local-ai-core/src/kernel/lifecycle-manager.js");
const plugin_registry_js_1 = require("../services/local-ai-core/src/kernel/plugin-registry.js");
const local_core_controller_js_1 = require("../services/local-ai-core/src/runtime/local-core-controller.js");
function plugin(id, dependsOn = []) {
    return {
        manifest: {
            id,
            kind: 'composite',
            version: '0.1.0',
            dependsOn,
            provides: [],
        },
    };
}
(0, node_test_1.default)('bootstrapLocalCoreKernel exposes the static built-in capability snapshot', () => {
    const kernel = (0, bootstrap_js_1.bootstrapLocalCoreKernel)();
    strict_1.default.deepEqual(kernel.getCapabilitySnapshot(), {
        adapters: {
            channels: ['localcore-acp'],
            agents: ['codex', 'cursor', 'gemini', 'qoder', 'iflow', 'localcore-acp'],
            knowledge: false,
            knowledgeProviders: [],
        },
        scheduler: {
            enabled: true,
            triggerTypes: ['cron', 'once'],
            deliveryTargets: [],
            platforms: [],
        },
        snapshot: {
            agents: [
                { id: 'agent.codex', agentType: 'codex', displayName: 'codex' },
                { id: 'agent.cursor', agentType: 'cursor', displayName: 'cursor' },
                { id: 'agent.gemini', agentType: 'gemini', displayName: 'gemini' },
                { id: 'agent.qoder', agentType: 'qoder', displayName: 'qoder' },
                { id: 'agent.iflow', agentType: 'iflow', displayName: 'iflow' },
                { id: 'agent.localcore-acp', agentType: 'localcore-acp', displayName: 'LocalCore ACP' },
            ],
            channels: [
                { id: 'channel.localcore-acp', platform: 'localcore-acp', displayName: 'LocalCore ACP' },
            ],
            knowledge: [],
            schedulers: [
                {
                    id: 'scheduler.trigger.cron',
                    triggerTypes: ['cron', 'once'],
                    deliveryTargets: [],
                    enabled: true,
                    displayName: 'Cron Trigger',
                },
            ],
            ui: [],
        },
    });
});
(0, node_test_1.default)('plugin registry preserves registration order for unrelated plugins', () => {
    const registry = new plugin_registry_js_1.LocalCorePluginRegistry();
    registry.register(plugin('plugin.first'));
    registry.register(plugin('plugin.second'));
    registry.register(plugin('plugin.third'));
    strict_1.default.deepEqual(registry.list().map((entry) => entry.manifest.id), [
        'plugin.first',
        'plugin.second',
        'plugin.third',
    ]);
});
(0, node_test_1.default)('plugin registry resolves dependencies before dependents', () => {
    const registry = new plugin_registry_js_1.LocalCorePluginRegistry();
    registry.register(plugin('plugin.scheduler', ['plugin.channel']));
    registry.register(plugin('plugin.channel'));
    registry.register(plugin('plugin.unrelated'));
    strict_1.default.deepEqual(registry.list().map((entry) => entry.manifest.id), [
        'plugin.channel',
        'plugin.scheduler',
        'plugin.unrelated',
    ]);
});
(0, node_test_1.default)('plugin registry rejects duplicate plugin ids', () => {
    const registry = new plugin_registry_js_1.LocalCorePluginRegistry();
    registry.register(plugin('plugin.duplicate'));
    strict_1.default.throws(() => registry.register(plugin('plugin.duplicate')), /Plugin already registered: plugin\.duplicate/);
});
(0, node_test_1.default)('capability registry snapshots contributions by capability type', () => {
    const capabilities = new capability_registry_js_1.LocalCoreCapabilityRegistry();
    capabilities.registerContributions({
        agents: [{ id: 'agent.test', agentType: 'test-agent' }],
        channels: [{ id: 'channel.test', platform: 'test-platform' }],
        knowledge: [{ id: 'knowledge.test', sourceType: 'test-source', enabled: true }],
        schedulers: [{ id: 'scheduler.test', triggerTypes: ['cron'], deliveryTargets: ['test-platform'] }],
        ui: [{ id: 'ui.test' }],
    });
    strict_1.default.deepEqual(capabilities.snapshot(), {
        agents: [{ id: 'agent.test', agentType: 'test-agent' }],
        channels: [{ id: 'channel.test', platform: 'test-platform' }],
        knowledge: [{ id: 'knowledge.test', sourceType: 'test-source', enabled: true }],
        schedulers: [{ id: 'scheduler.test', triggerTypes: ['cron'], deliveryTargets: ['test-platform'] }],
        ui: [{ id: 'ui.test' }],
    });
});
(0, node_test_1.default)('kernel lifecycle initializes plugins and diagnostics report health', async () => {
    const kernel = (0, bootstrap_js_1.bootstrapLocalCoreKernel)();
    await kernel.lifecycle.initAll();
    const diagnostics = await kernel.diagnostics.snapshot();
    strict_1.default.equal(diagnostics.pluginCount, 7);
    strict_1.default.equal(diagnostics.enabledPluginCount, 7);
    strict_1.default.deepEqual(diagnostics.plugins.map((plugin) => plugin.pluginId).sort(), [
        'builtin.agent-codex',
        'builtin.agent-cursor',
        'builtin.agent-gemini',
        'builtin.agent-iflow',
        'builtin.agent-localcore-acp',
        'builtin.agent-qoder',
        'builtin.scheduler-cron',
    ]);
    strict_1.default.deepEqual(diagnostics.plugins.map((plugin) => ({
        pluginId: plugin.pluginId,
        enabled: plugin.enabled,
        health: plugin.health,
    })), [
        'builtin.agent-codex',
        'builtin.agent-cursor',
        'builtin.agent-gemini',
        'builtin.agent-qoder',
        'builtin.agent-iflow',
        'builtin.agent-localcore-acp',
        'builtin.scheduler-cron',
    ].map((pluginId) => ({
        pluginId,
        enabled: true,
        health: { status: 'healthy' },
    })));
});
(0, node_test_1.default)('runtime bootstrap registers the active knowledge provider in capability snapshot', async () => {
    const userDataPath = (0, node_fs_1.mkdtempSync)((0, node_path_1.join)((0, node_os_1.tmpdir)(), 'agentdock-kernel-'));
    try {
        const runtime = (0, bootstrap_js_2.bootstrapLocalCoreRuntime)({
            userDataPath,
        });
        strict_1.default.deepEqual(runtime.kernel.getCapabilitySnapshot().adapters.agents, [
            'codex',
            'cursor',
            'gemini',
            'qoder',
            'iflow',
            'localcore-acp',
            'opencode',
            'claudecode',
        ]);
        strict_1.default.deepEqual(runtime.kernel.getCapabilitySnapshot().adapters.channels, ['localcore-acp', 'lark', 'weixin']);
        strict_1.default.deepEqual(runtime.kernel.getCapabilitySnapshot().adapters.knowledgeProviders, ['ai-vector']);
        strict_1.default.equal(runtime.kernel.getCapabilitySnapshot().adapters.knowledge, true);
        strict_1.default.deepEqual(runtime.kernel.getCapabilitySnapshot().scheduler, {
            enabled: true,
            triggerTypes: ['cron', 'once'],
            deliveryTargets: ['lark', 'weixin'],
            platforms: ['lark', 'weixin'],
        });
        await runtime.start();
        await runtime.stop();
    }
    finally {
        (0, node_fs_1.rmSync)(userDataPath, { recursive: true, force: true });
    }
});
(0, node_test_1.default)('runtime bootstrap supports a disabled knowledge plugin path', () => {
    const userDataPath = (0, node_fs_1.mkdtempSync)((0, node_path_1.join)((0, node_os_1.tmpdir)(), 'agentdock-kernel-'));
    try {
        const runtime = (0, bootstrap_js_2.bootstrapLocalCoreRuntime)({
            userDataPath,
            enableKnowledge: false,
        });
        strict_1.default.deepEqual(runtime.kernel.getCapabilitySnapshot().adapters.agents, [
            'codex',
            'cursor',
            'gemini',
            'qoder',
            'iflow',
            'localcore-acp',
            'opencode',
            'claudecode',
        ]);
        strict_1.default.deepEqual(runtime.kernel.getCapabilitySnapshot().adapters.channels, ['localcore-acp', 'lark', 'weixin']);
        strict_1.default.deepEqual(runtime.kernel.getCapabilitySnapshot().adapters.knowledgeProviders, []);
        strict_1.default.equal(runtime.kernel.getCapabilitySnapshot().adapters.knowledge, false);
        strict_1.default.deepEqual(runtime.kernel.getCapabilitySnapshot().scheduler, {
            enabled: true,
            triggerTypes: ['cron', 'once'],
            deliveryTargets: ['lark', 'weixin'],
            platforms: ['lark', 'weixin'],
        });
    }
    finally {
        (0, node_fs_1.rmSync)(userDataPath, { recursive: true, force: true });
    }
});
(0, node_test_1.default)('runtime bootstrap knowledge capabilities come from the selected provider plugin', () => {
    const enabledUserDataPath = (0, node_fs_1.mkdtempSync)((0, node_path_1.join)((0, node_os_1.tmpdir)(), 'agentdock-kernel-'));
    const disabledUserDataPath = (0, node_fs_1.mkdtempSync)((0, node_path_1.join)((0, node_os_1.tmpdir)(), 'agentdock-kernel-'));
    try {
        const enabledRuntime = (0, bootstrap_js_2.bootstrapLocalCoreRuntime)({
            userDataPath: enabledUserDataPath,
        });
        const disabledRuntime = (0, bootstrap_js_2.bootstrapLocalCoreRuntime)({
            userDataPath: disabledUserDataPath,
            enableKnowledge: false,
        });
        strict_1.default.deepEqual(enabledRuntime.kernel.getCapabilitySnapshot().snapshot.knowledge.map((capability) => capability.sourceType), ['ai-vector']);
        strict_1.default.deepEqual(disabledRuntime.kernel.getCapabilitySnapshot().snapshot.knowledge, [
            {
                id: 'knowledge.noop',
                sourceType: 'noop',
                enabled: false,
                displayName: 'Disabled Knowledge',
            },
        ]);
        strict_1.default.equal(disabledRuntime.kernel.getCapabilitySnapshot().adapters.knowledge, false);
    }
    finally {
        (0, node_fs_1.rmSync)(enabledUserDataPath, { recursive: true, force: true });
        (0, node_fs_1.rmSync)(disabledUserDataPath, { recursive: true, force: true });
    }
});
(0, node_test_1.default)('runtime bootstrap keeps disabled plugins diagnosable without contributing capabilities', async () => {
    const userDataPath = (0, node_fs_1.mkdtempSync)((0, node_path_1.join)((0, node_os_1.tmpdir)(), 'agentdock-kernel-'));
    try {
        const runtimeDir = (0, node_path_1.join)(userDataPath, 'runtime');
        (0, node_fs_1.mkdirSync)(runtimeDir, { recursive: true });
        (0, node_fs_1.writeFileSync)((0, node_path_1.join)(runtimeDir, 'local-core-settings.json'), JSON.stringify({
            configPath: (0, node_path_1.join)(runtimeDir, 'config.toml'),
            defaultProject: 'default',
            autoStartService: true,
            knowledge: {
                baseUrl: '',
                authMode: 'none',
                token: '',
                headerName: 'X-API-Key',
                defaultCollection: 'personal_knowledge',
            },
            plugins: {
                'builtin.scheduler-lark': { enabled: false },
            },
        }), 'utf8');
        const runtime = (0, bootstrap_js_2.bootstrapLocalCoreRuntime)({
            userDataPath,
        });
        const diagnostics = await runtime.kernel.diagnostics.snapshot();
        const disabledPlugin = diagnostics.plugins.find((plugin) => plugin.pluginId === 'builtin.scheduler-lark');
        strict_1.default.ok(disabledPlugin);
        strict_1.default.equal(disabledPlugin.enabled, false);
        strict_1.default.equal(disabledPlugin.health.status, 'degraded');
        strict_1.default.deepEqual(runtime.kernel.getCapabilitySnapshot().scheduler, {
            enabled: true,
            triggerTypes: ['cron', 'once'],
            deliveryTargets: ['weixin'],
            platforms: ['weixin'],
        });
    }
    finally {
        (0, node_fs_1.rmSync)(userDataPath, { recursive: true, force: true });
    }
});
(0, node_test_1.default)('LocalCoreController accepts injected bootstrap dependencies', async () => {
    const bus = new event_bus_js_1.LocalCoreEventBus();
    const capabilitySnapshot = {
        adapters: {
            channels: ['test-channel'],
            agents: ['test-agent'],
            knowledge: false,
            knowledgeProviders: [],
        },
        scheduler: {
            enabled: false,
            triggerTypes: [],
            deliveryTargets: [],
            platforms: [],
        },
        snapshot: {
            agents: [{ id: 'agent.test', agentType: 'test-agent' }],
            channels: [{ id: 'channel.test', platform: 'test-channel' }],
            knowledge: [],
            schedulers: [],
            ui: [],
        },
    };
    let started = false;
    let stopped = false;
    let channelRefreshes = 0;
    let weixinRefreshes = 0;
    const controller = new local_core_controller_js_1.LocalCoreController('/tmp/local-core-controller-injected', {
        kernel: {
            context: {
                bus,
                capabilities: new capability_registry_js_1.LocalCoreCapabilityRegistry(),
                logger: { log: () => { } },
            },
            plugins: new plugin_registry_js_1.LocalCorePluginRegistry(),
            capabilities: new capability_registry_js_1.LocalCoreCapabilityRegistry(),
            lifecycle: {},
            diagnostics: {
                snapshot: async () => ({
                    pluginCount: 0,
                    enabledPluginCount: 0,
                    plugins: [],
                }),
            },
            getCapabilitySnapshot: () => capabilitySnapshot,
        },
        state: {
            getSettings: () => ({
                binaryPath: '',
                configPath: '',
                autoStartService: true,
                defaultProject: 'default',
                managementPort: 0,
                managementToken: '',
                bridgePort: 0,
                bridgeToken: '',
                bridgePath: '',
                knowledge: {
                    baseUrl: '',
                    authMode: 'none',
                    token: '',
                    headerName: 'X-API-Key',
                    defaultCollection: 'personal_knowledge',
                },
                plugins: {},
            }),
            getLogs: () => [],
            readConfigFile: async () => ({
                path: '',
                exists: false,
                raw: '',
                parsed: null,
            }),
            saveStructuredConfigFile: async (config) => ({
                path: '',
                exists: true,
                raw: JSON.stringify(config),
                parsed: config,
            }),
        },
        store: {},
        agentRuntimes: [],
        channelRuntime: {
            platform: 'test-channel',
            routeType: 'channel.test',
            refreshBindings: async () => {
                channelRefreshes++;
            },
        },
        weixinChannelRuntime: {
            platform: 'weixin',
            routeType: 'channel.chat',
            refreshBindings: async () => {
                weixinRefreshes++;
            },
        },
        knowledgeProvider: {},
        knowledgeAttachments: {},
        workspaceRouter: {},
        scheduler: {},
        start: async () => {
            started = true;
        },
        stop: async () => {
            stopped = true;
        },
    });
    await controller.init();
    strict_1.default.equal(started, true);
    strict_1.default.deepEqual(await controller.getCapabilities(), capabilitySnapshot);
    await controller.saveStructuredConfigFile({ projects: [] });
    strict_1.default.equal(channelRefreshes, 1);
    strict_1.default.equal(weixinRefreshes, 1);
    await controller.close();
    strict_1.default.equal(stopped, true);
});
(0, node_test_1.default)('runtime logs are persisted to local-core.log', () => {
    const userDataPath = (0, node_fs_1.mkdtempSync)((0, node_path_1.join)((0, node_os_1.tmpdir)(), 'agentdock-logs-'));
    try {
        const runtime = (0, bootstrap_js_2.bootstrapLocalCoreRuntime)({
            userDataPath,
            enableKnowledge: false,
            log: () => { },
        });
        runtime.state.pushLog('localcore-weixin send failed for sessionKey=test');
        runtime.state.pushLog('second line');
        const logPath = (0, node_path_1.join)(userDataPath, 'runtime', 'local-core.log');
        const raw = (0, node_fs_1.readFileSync)(logPath, 'utf-8');
        strict_1.default.match(raw, /^\d{4}-\d{2}-\d{2}T.* localcore-weixin send failed for sessionKey=test/m);
        strict_1.default.match(raw, /^\d{4}-\d{2}-\d{2}T.* second line/m);
    }
    finally {
        (0, node_fs_1.rmSync)(userDataPath, { recursive: true, force: true });
    }
});
(0, node_test_1.default)('channel plugin lifecycle start and stop are driven by the kernel lifecycle', async () => {
    const calls = [];
    const registry = new plugin_registry_js_1.LocalCorePluginRegistry();
    registry.register({
        manifest: {
            id: 'plugin.channel-test',
            kind: 'channel',
            version: '0.1.0',
            provides: ['channel:test'],
        },
        init: () => {
            calls.push('init');
        },
        start: () => {
            calls.push('start');
        },
        stop: () => {
            calls.push('stop');
        },
    });
    const lifecycle = new lifecycle_manager_js_1.LocalCoreLifecycleManager(registry, {
        bus: new event_bus_js_1.LocalCoreEventBus(),
        capabilities: new capability_registry_js_1.LocalCoreCapabilityRegistry(),
        logger: { log: () => { } },
    });
    await lifecycle.startAll();
    await lifecycle.stopAll();
    strict_1.default.deepEqual(calls, ['init', 'start', 'stop']);
});
(0, node_test_1.default)('channel and scheduler capabilities use registry targets instead of Lark-specific routing', () => {
    const registry = new plugin_registry_js_1.LocalCorePluginRegistry();
    const capabilities = new capability_registry_js_1.LocalCoreCapabilityRegistry();
    const plugins = [
        {
            manifest: {
                id: 'plugin.channel-slack',
                kind: 'channel',
                version: '0.1.0',
                provides: ['channel:slack'],
            },
            capabilities: {
                channels: [{ id: 'channel.slack', platform: 'slack', routeType: 'channel.chat' }],
            },
        },
        {
            manifest: {
                id: 'plugin.scheduler-slack',
                kind: 'scheduler',
                version: '0.1.0',
                dependsOn: ['plugin.channel-slack'],
                provides: ['scheduler.delivery.slack'],
            },
            capabilities: {
                schedulers: [{ id: 'scheduler.delivery.slack', triggerTypes: [], deliveryTargets: ['slack'] }],
            },
        },
    ];
    for (const entry of plugins) {
        registry.register(entry);
    }
    for (const entry of registry.list()) {
        capabilities.registerContributions(entry.capabilities || {});
    }
    strict_1.default.deepEqual(capabilities.snapshot().channels.map((capability) => capability.platform), ['slack']);
    strict_1.default.deepEqual(capabilities.snapshot().schedulers.flatMap((capability) => capability.deliveryTargets), ['slack']);
});
(0, node_test_1.default)('agent runtime selection is registry-based and disabled runtimes do not route workspaces', async () => {
    const userDataPath = (0, node_fs_1.mkdtempSync)((0, node_path_1.join)((0, node_os_1.tmpdir)(), 'agentdock-kernel-'));
    try {
        const runtimeDir = (0, node_path_1.join)(userDataPath, 'runtime');
        (0, node_fs_1.mkdirSync)(runtimeDir, { recursive: true });
        (0, node_fs_1.writeFileSync)((0, node_path_1.join)(runtimeDir, 'local-core-settings.json'), JSON.stringify({
            configPath: (0, node_path_1.join)(runtimeDir, 'config.toml'),
            defaultProject: 'default',
            autoStartService: true,
            knowledge: {
                baseUrl: '',
                authMode: 'none',
                token: '',
                headerName: 'X-API-Key',
                defaultCollection: 'personal_knowledge',
            },
            plugins: {
                'builtin.agent-claudecode': { enabled: false },
            },
        }), 'utf8');
        const runtime = (0, bootstrap_js_2.bootstrapLocalCoreRuntime)({
            userDataPath,
        });
        await runtime.state.saveRawConfigFile(`
[[projects]]
name = "claude-workspace"

[projects.agent]
type = "claudecode"
`);
        strict_1.default.deepEqual(runtime.agentRuntimes.map((entry) => entry.agentType), ['localcore-acp', 'opencode']);
        strict_1.default.equal(runtime.kernel.getCapabilitySnapshot().snapshot.agents.some((capability) => capability.agentType === 'claudecode'), false);
        strict_1.default.deepEqual(await runtime.workspaceRouter.listWorkspaces(), []);
        await strict_1.default.rejects(() => runtime.workspaceRouter.listThreads('claude-workspace'), /Workspace "claude-workspace" is not configured as a Local AI Core ACP workspace/);
        await runtime.stop();
    }
    finally {
        (0, node_fs_1.rmSync)(userDataPath, { recursive: true, force: true });
    }
});
(0, node_test_1.default)('renderer route and nav rendering are sourced from the contribution registry', () => {
    const appSource = (0, node_fs_1.readFileSync)((0, node_path_1.join)(process.cwd(), 'src', 'App.tsx'), 'utf8');
    const sidebarSource = (0, node_fs_1.readFileSync)((0, node_path_1.join)(process.cwd(), 'src', 'components', 'Layout', 'Sidebar.tsx'), 'utf8');
    const headerSource = (0, node_fs_1.readFileSync)((0, node_path_1.join)(process.cwd(), 'src', 'components', 'Layout', 'Header.tsx'), 'utf8');
    strict_1.default.match(appSource, /rendererUiContributions\.listRoutes\(\)\.map/);
    strict_1.default.match(sidebarSource, /rendererUiContributions\s*\.\s*listNavItems\(\)/);
    strict_1.default.match(headerSource, /resolveRouteTitleKey/);
});
(0, node_test_1.default)('renderer feature visibility is capability-driven', () => {
    const runtimeSource = (0, node_fs_1.readFileSync)((0, node_path_1.join)(process.cwd(), 'src', 'app', 'runtime.ts'), 'utf8');
    const sidebarSource = (0, node_fs_1.readFileSync)((0, node_path_1.join)(process.cwd(), 'src', 'components', 'Layout', 'Sidebar.tsx'), 'utf8');
    const dashboardSource = (0, node_fs_1.readFileSync)((0, node_path_1.join)(process.cwd(), 'src', 'pages', 'Dashboard.tsx'), 'utf8');
    strict_1.default.match(runtimeSource, /snapshot\?\.knowledge\.some/);
    strict_1.default.match(runtimeSource, /snapshot\?\.schedulers\.some/);
    strict_1.default.match(runtimeSource, /snapshot\?\.agents\.some/);
    strict_1.default.match(sidebarSource, /useRuntimeFeatureSupport/);
    strict_1.default.match(dashboardSource, /useRuntimeFeatureSupport/);
});
